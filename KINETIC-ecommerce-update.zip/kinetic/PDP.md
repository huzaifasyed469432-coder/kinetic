# KINETIC® — Product Detail Pages (PDP)

_Everything in this document is English-only, matching the rest of the site._
_This update adds a full product detail page for **every** product. Nothing in the existing design was restyled: the PDP uses the same black + gold palette (`#08080A`, `#D4AF37`, `#F5F0EA`, `#B8860B`), the same Anton / Space Grotesk type, the same 2px borders and offset shadows._

---

## 1. What was added

| File | Size | What it is |
| --- | --- | --- |
| `assets/kinetic-product.js` | ~40 KB | The product page: gallery, buy box, specs, reviews, rails. Exposes `window.KINETIC_PRODUCT`. |
| `assets/kinetic-product.css` | ~11 KB | Product page styles. Every new class is prefixed `kp-` (plus `#productView`, `#kpSticky`, `#kpLightbox`, `#kpSizeGuide`) so **nothing existing can be affected**. |
| `index.html` | 4 lines changed | PDP stylesheet link, PDP script tag, one empty `<div id="productView">` inside `<main>`, and a “View full details” link in the quick-view modal. |
| `assets/kinetic-app.js` | 4 small edits | The card-corner “↗” became a real link to the product page, the modal link follows the open product, and two helper APIs were exposed. |
| `assets/kinetic-checkout.js` | 1 line | Exposes the shipping methods so the product page shows the store’s real shipping rules. |

**Fully backwards compatible.** Old links (`#collection`, `#tech`, `#admin`, `#checkout`, `#order/<no>`) behave exactly as before. A product page is reached at `#product/<id>` (e.g. `#product/0` = Voltage Pro Carbon) and is shareable/bookmarkable.

---

## 2. The 26 required elements — where they are

1. **Large image gallery** — left column, square stage with the store’s product photo.
2. **Multiple images** — 5 views per product: the real product photo plus four framed detail views of it (`Full view`, `Toe detail`, `Heel detail`, `Upper texture`, `Sole profile`). Any image the owner adds later also joins the gallery automatically (see §6).
3. **Thumbnail navigation** — a scrollable thumbnail strip under the stage; click or keyboard.
4. **Zoom interaction** — hover to zoom in place (desktop), click/tap to open the full-screen viewer with `−` / `1:1` / `+`, mouse-wheel zoom, drag to pan, arrow keys, swipe, `Esc`, focus trap. Zoom is capped at 4×.
5. **Product name** — `<h1 id="kpTitle">`.
6. **Price** — `#kpPrice`.
7. **Previous / sale price** — `$310` struck through next to `$260` plus a `SAVE 16%` pill (only when the product has an old price).
8. **Description** — “Description” accordion (`#kpAccDesc`), open by default.
9. **Rating** — gold star row under the title.
10. **Review count** — `4.9 · 2,143 reviews` (clickable, jumps to the review section).
11. **Available sizes** — the store’s real US size list (7 → 12, with EU conversions).
12. **Size selection** — 50px tap targets, gold selected state, `Selected US 9.5 · EU 43` note.
13. **Available colours** — one swatch per colourway of that product.
14. **Colour selection** — swatch ring + tick, colour name next to “COLOURWAY”, and the spec table + SKU update with it.
15. **Stock availability** — chip under the title (`IN STOCK · US 9.5 SHIPS TODAY`, `ONLY 1 LEFT`, `SOLD OUT`), sold-out sizes crossed out, `N AVAILABLE IN THIS SIZE` next to the quantity.
16. **Quantity selector** — `−` / value / `+`, clamped to 1…9 and to the real stock of the chosen size.
17. **Add to Cart** — `#kpAdd` and the sticky bar’s copy.
18. **Buy Now** — `#kpBuy`, adds the selection and opens the secure checkout at step 1.
19. **Wishlist** — heart button that syncs with the storefront wishlist (persists in the browser, header count updates).
20. **SKU** — `KNT-001-095-IR` = KINETIC / product / US size / colourway initials, live in the header row and in the spec table.
21. **Shipping info** — “Shipping & returns” accordion, built from the store’s real shipping rules (free over $180, otherwise $12, express options).
22. **Returns info** — same accordion: 30-day run trial, free size exchanges, how to start a return.
23. **Specifications** — 11-row table (SKU, category, colourway, upper, midsole, outsole, drop, weight, energy return, warranty, care) using the site’s own marketing numbers.
24. **Reviews section** — rating score, star breakdown, written reviews, and a working “Write a review” form (see §5).
25. **Related products** — “You might also like” rail: same category first, then nearest price. Adding straight from a rail card works.
26. **Recently viewed** — “Recently viewed” rail (newest first, up to 12, stored on the device) with a “Clear” control.

---

## 3. How a shopper reaches a product page

* **Product card** → the gold `↗` corner button (a real `<a href="#product/0">`) opens the full details page. Clicking the card itself still opens the quick-view modal exactly as before.
* **Quick-view modal** → the new **“View full details →”** button.
* **Related / recently-viewed rails** → any card.
* **Direct link** → `#product/0` … `#product/7` (shareable, works on refresh).
* **Back button** → returns to the shop, or to the previous product when you were browsing from a rail.

---

## 4. The hard requirement: the PDP feeds the real cart

`Add to bag` and `Buy now` call the storefront’s own `KINETIC_APP.addItem({id, size, color, qty})`, which writes through the same code path as the quick-view modal and the cart drawer.

* Size = **US 9.5**, Colour = **Warm Cream**, Quantity = **2** → the bag contains exactly `{id: 0, size: "9.5", color: "#F5F0EA", colorName: "Warm Cream", qty: 2}`.
* Adding the same variant twice **merges into one line** (qty 2 → 4), it never duplicates.
* Checkout shows the same size, colourway and quantities (`US 9.5 · ● Warm Cream`, subtotal $520 for 2 × $260).
* Requests beyond stock are **clamped** to what exists and explained in a toast; sold-out sizes cannot be added at all. `Add to bag` without a size adds nothing and says why.
* Wishlist, promo codes, shipping maths, order numbers and receipts are all the existing systems — the PDP only uses them.

---

## 5. Reviews

* The product’s editorial review(s) from the site content are matched by product name and shown with the “Verified purchase” label.
* The rating breakdown (5★ 2,035 · 4★ 59 …) is derived from the product’s own average rating and review count.
* **Write a review** is a real form: name, 1–5 stars, review text (min. 10 characters) with inline validation. Published reviews appear at the top of the list marked “Yours”, are stored on that device under `kinetic-reviews-v1`, survive a refresh, and can be deleted again.

## 6. Product photos and extra images

The catalogue ships **one photo per product**. The PDP turns it into five views (the full shot plus four framed detail crops), which is honest labelling rather than pretending there are more photos than exist. If more media is available for a product through `KINETIC_APP.uploads(productId)` (the site’s existing IndexedDB hook, `kinetic-product-media`), those images are inserted into the gallery right after the main photo with their own label, and the thumbnail rail grows with them. Changing a product’s photo in the admin profile updates the PDP immediately, because the PDP always renders `product.img`.

## 7. Accessibility & motion

Semantic buttons, `aria-pressed` on sizes/colours/wishlist, `aria-disabled` + spoken “sold out” labels, `role="status"` on the stock chip, labelled gallery region with arrow-key control, `Enter`/`Space` to open the viewer, focus trap and focus return in the viewer and size guide, `Esc` to close, visible gold focus rings, and a `prefers-reduced-motion` block that removes the transitions.

## 8. Mobile

* Single-column layout, no horizontal overflow at 390 px or 360 px.
* Thumbnail strip scrolls sideways; one-finger swipe moves through the views (and never opens the viewer by accident).
* Square 44 px+ tap targets for sizes, colours, quantity and actions.
* **Sticky purchase bar** (`#kpSticky`) appears once the buy box scrolls out of view: product name, live selection, price, `Add to bag` and `Buy now`. It hides itself while the bag drawer, the checkout or the image viewer is open, and the storefront’s back-to-top button steps aside so it can never cover the add button.
* Order summary on the checkout is the existing mobile accordion.

## 9. Testing done on this build

Automated browser tests (headless Chrome, real mouse/touch input, 1440 px desktop and 390/360 px mobile):

* **Desktop suite: 100 / 100 passed** — gallery (thumbs, arrows, keyboard, hover zoom, viewer zoom/pan/keys), info block (name, price, sale price, rating, review count, SKU, specs, shipping, returns, review publishing + validation + persistence), size list versus real stock (sold-out rows crossed out and blocked), colour switching (name, spec row, SKU code), quantity clamping, add-to-cart exactness (size/colour/qty in storage, badge, drawer line), merge behaviour, Buy-now → checkout totals, wishlist persistence, related + recently-viewed rails, browser back, and full regression of the existing modal, filters, cart drawer, checkout and admin.
* **Mobile + sweep suite: 52 / 52 passed** — 390 px and 360 px overflow checks, tap targets, sticky bar behaviour and sticky add/buy, mobile checkout with the exact selection, viewer fit and zoom, swipe, every one of the 8 product pages (views, sizes, stock-outs, rails, specs, reviews) and the owner-upload gallery path.
* **0 page errors, 0 console errors, 0 failed/4xx requests** across every run. (The site's own content loader asks the GitHub API for `content.json` first and falls back to `raw.githubusercontent.com`; from the test sandbox that API call answers 403 because of the anonymous rate limit, which is pre-existing behaviour of `kinetic-content.js` — the fallback loads the content and the page is unaffected.)
* 11 reference screenshots: `/home/user/shots-pdp/`.

## 10. Deploying

Upload these six files to the same folders they live in now:

```
index.html
assets/kinetic-app.js
assets/kinetic-checkout.js
assets/kinetic-admin.js
assets/kinetic-product.js      ← new
assets/kinetic-product.css     ← new
```

Order in `index.html`: `kinetic-product.js` must load **after** `kinetic-checkout.js`; `kinetic-product.css` must come **after** `kinetic-checkout.css`. The delivered `index.html` already has this exactly (product script on line 39, product stylesheet on line 32). The page loads its data from `kinetic-content.js` (which injects `kinetic-app.js`), so it shows a skeleton and fills itself in as soon as the store data arrives — a deep link such as `#product/0` opened in a fresh tab works that way. No build step, no dependencies.

## 11. Admin notes

* Products, prices, descriptions, colourways, ratings, review counts, marketing numbers, shipping/promo rules — all of it still comes from the store and is used by the PDP; nothing is hard-coded twice.
* A product can carry its own size list (`sizes: ["7","8",…]`); the PDP will use it instead of the store-wide list.
* Sizes are US **7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5, 11, 12** across the store, so “42” from the brief is covered as **US 8.5 = EU 42** and **US 9.5 = EU 43** in the size guide.
* Stock is deterministic per product + size (an explicit `stock` map on a product always wins), so a product page always shows a believable mix of available, low-stock and sold-out sizes.

# KINETIC® — collection search, filters & sorting

Real-time product search and filtering layer for the collection page (`#collection`).
Everything below is live on the site; nothing about the existing design was restyled.

```
assets/kinetic-shop-filters.css   ← the styles (every class prefixed kflt-)
assets/kinetic-shop-filters.js    ← the engine  (window.KINETIC_FILTERS, v1.0)
```

Two lines are added to `index.html`:

```html
<link rel="stylesheet" href="assets/kinetic-shop-filters.css">
...
<script src="assets/kinetic-shop-filters.js"></script>
```

and the collection section gained three anchors — a toolbar `#kfltBar`, a desktop
rail `#kfltRail` and the layout wrapper `#kfltLayout` around the untouched
`#productGrid` (the grid keeps its own classes and id, so the old CSS/JS still works).

---

## 1. Search

* **Searches in real time** — one keystroke in `#kfltSearch` re-renders the grid
  (debounced ~180 ms, so it feels instant but never thrashes).
* **What it matches:** product **name**, **SKU**, **category**, tag/colourway names,
  the keyword **synonyms** the shop uses (`carbon`, `runner`, `limited`, `court`, …)
  and free text inside the product description/specs.
* **SKU search** works with or without the prefix — `KNT-002`, `knt-002`, `002`.
  Products that have no SKU of their own get a stable generated one (`KNT-001 …`),
  derived from the same id the shop already uses, so it never changes.
* **Suggestions** — the existing header search overlay (`⌕` in the header) now shows
  highlighted matches with thumbnail, name, category, price, rating and SKU, plus
  *Recent searches* (last 6, kept in `localStorage['kinetic-search-recent-v1']`),
  quick **browse tags** for each category, a featured strip, and a
  *no results → did you mean* state with one-tap keyword shortcuts
  (`under $200`, `sale`, `new`, `popular`).
* **No-results state** replaces the grid with an in-style panel: what happened,
  a **Clear all filters** button and "try instead" chips.

## 2. Filters (desktop rail · mobile drawer)

| Facet | Options |
|---|---|
| Category | every category the catalogue really has (All / Running / Lifestyle / Court / Limited) |
| Price | dual-range slider, live while dragging, committed on release |
| Size | US sizes with the EU twin printed under each (`US 8.5 / EU 42`); sold-out sizes are not offered |
| Colour | swatch grid, each dot is the product's real colour, tooltip shows how many pairs match |
| Availability | In stock · Low stock (3 pairs or fewer) · Sold out |
| Rating | 4.5+ · 4+ · 3.5+ |
| Offers | On sale · Featured |

* **Desktop (≥1024 px)** — the facet rail is a sticky, scrollable sidebar to the left
  of the grid. **Hide filters / Show filters** collapses it (remembered in
  `localStorage['kinetic-filter-rail-v1']`).
* **Mobile** — the same facets arrive as a bottom-up **drawer** with a scrim, a live
  "N products match" line and a **Show results** button; Escape and the scrim close it,
  focus is trapped, and the closed drawer is `inert`.
* Every option shows how many products it would leave you with, and each facet is
  counted with the **other** filters still applied — the numbers never lie.
* **Instant** — no submit button anywhere. Each change re-renders the grid in ~120 ms
  with a loading state (skeleton sweep + progress line) and a soft entrance animation.
  `prefers-reduced-motion` turns the animation off.

## 3. Active filter chips

Under the search box: one chip per active facet (colour chips carry their swatch dot).

* **✕ on a chip** removes just that filter, keeping everything else.
* **Clear all** (toolbar) empties every facet, the search box and the URL.
* The top-left **Filters** button shows a count of active facets.

## 4. Matching product count

`#resultCount` — the badge the shop already had — now updates live and reads
`8 Products` when nothing is filtered, `1 / 8 Products` when it is. Next to it,
`Sorted by …` follows the chosen sort, and the status line in the toolbar repeats
`Showing 1 of 8 products · 3 filters on` for screen readers and humans alike.

## 5. Sorting

Six modes, wired to the shop's own `#sortSelect`:

| Option in the dropdown | Value | Meaning |
|---|---|---|
| Sort: Featured | `feat` | featured first, then tag weight, then best sellers |
| Sort: Newest | `new` | newest additions to the collection |
| Price: Low → High | `low` | cheapest first |
| Price: High → Low | `high` | dearest first |
| Sort: Best rated | `rate` | star rating, then number of reviews |
| Sort: Most popular | `pop` | units sold (real orders), then reviews |

## 6. Shareable URLs

Every state is written to the query string (push-state, so **Back** steps through your
filtering) and **read back on load** — refreshing or sharing keeps the view.

```
?category=running&color=black&size=42&max=200&sort=low
```

| Parameter | Accepts | Notes |
|---|---|---|
| `q` (or `search`) | free text | same engine as the search box |
| `category` (or `cat`) | category name | repeatable / comma separated |
| `color` (or `colour`) | colourway name | hyphen or space spelling both work |
| `size` | `9` (US) or `42` (EU) | EU numbers are converted with the shop's own table |
| `min`, `max` | dollars | swapped automatically if reversed |
| `availability` | `in`, `low`, `out` (long names too) | |
| `rating` | `4.5`, `4`, `3.5` | |
| `sale`, `featured` | `1` | |
| `sort` | `feat`,`new`,`pop`,`low`,`high`,`rate` (also `newest`,`popular`) | omitted when it is the default |

**Copy link** in the toolbar copies the exact filtered view (with a clipboard fallback
for older browsers) and confirms with a toast.

## 7. How it plugs into the shop

The engine never rebuilds the page. It exposes a tiny API and the app asks it two
questions while rendering:

```js
KINETIC_FILTERS.match(product)        // does this product survive the filters?
KINETIC_FILTERS.sort(list)            // order the survivors
KINETIC_FILTERS.afterRender(count, total)   // update counts, chips, status
KINETIC_FILTERS.setCategory(name) · setSort(value) · renderSearchOverlay(q)
KINETIC_FILTERS.state · results() · url() · clearAll() · refresh()
```

* `kinetic-app.js` filters its product list through `match()`, sorts with `sort()`,
  delegates its quick category buttons and sort dropdown to the engine, and hands the
  header search overlay to `renderSearchOverlay()`.
* **Anything the owner changes in the admin console shows up here immediately** —
  new products, edited prices, colours, categories, sizes, stock and sale flags all
  flow through the same data (categories, colours, sizes and price bounds are derived
  from the live catalogue, never hard-coded).
* Sizes, stock and colour names are read through `KINETIC_APP` (`stockSummary`,
  `sizeEu`, `colorways`), so "sold out", "low stock" and the US/EU table always match
  the product pages and checkout.

## 8. Accessibility

Labelled search input, `aria-pressed` on every facet and quick chip, chips announce
what they remove, result count is an `aria-live` region, a dedicated live region
announces "N products match / no products match", the drawer traps focus and restores
it on close, and all focus rings stay visible.

## 9. Tests

`/home/user/.tests/puppeteer_filters/sf1.js` — **98 checks**, run against
`http://127.0.0.1:8100`, covering exactly what the brief asked for:

| Block | Covers |
|---|---|
| 1–2 | engine boots, toolbar + 7 facets present, search by keyword / name / SKU / category, case-insensitivity, no-results state, clear-all |
| 3–4 | five facets at once, chip removal one at a time, clear-all, URL after each step |
| 5 | the original quick category buttons still drive everything |
| 6 | all six sort modes and the sort label |
| 7 | price range, size, availability, sale |
| 8 | header overlay suggestions + SKU in suggestions |
| 9–9b | URL restored on refresh (incl. EU→US size), Back/Forward, loading state, desktop rail toggle |
| 10–11 | copy link |
| 12 | mobile drawer: off-canvas, focus, scrim, live count, scroll-lock release, inert when closed, no horizontal scroll |
| console | zero page errors, zero console errors for the whole run |

Run it:

```bash
cd /home/user/kinetic && python3 -m http.server 8100 --bind 0.0.0.0 &
cd /tmp/t && node sf1.js          # 98 pass / 0 fail
```

The dashboard suites (`s3–s9`, `final.js`) and the customer-site regression (`s8`)
were re-run after this work: **189 + 7 checks, 0 failures, 0 page errors**.

## 10. Screenshots

`/home/user/shots-filters/` — `F1` toolbar + rail, `F2` search in action,
`F3` multi-facet + chips, `F4` sorted low→high, `F5` no-results state,
`F6` search overlay suggestions, `F7`/`F8` mobile drawer, `F9` filtered mobile grid.

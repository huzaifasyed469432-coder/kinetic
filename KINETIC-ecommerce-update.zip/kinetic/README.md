# KINETIC® — Current Release Update Package (code only)

**Release:** Task #36 final release audit, 2026-11-18 (local release candidate).
**What this is:** a **code-only update** for an existing KINETIC deployment. It
contains the current storefront code and site files — **no product images**.
Apply it over a deployment that already has the 57 SVG artworks installed.

## Contents (all under `kinetic/`)

- 14 JavaScript files (`assets/`) — including `kinetic-app.js`,
  `kinetic-checkout.js`, `kinetic-product.js`, `kinetic-content.js`,
  `kinetic-api.js`, `kinetic-api-bridge.js`, `kinetic-account.js`,
  `kinetic-auth.js`, `kinetic-mobile.js`, `kinetic-shop-filters.js`,
  `kinetic-defaults.js`, `kinetic-accessibility.js`, plus GSAP 3.12.5 +
  ScrollTrigger (`gsap.min.js`, `ScrollTrigger.min.js`).
- 7 CSS files (`assets/`) — `kinetic.css`, `kinetic-theme.css`,
  `kinetic-checkout.css`, `kinetic-product.css`, `kinetic-shop-filters.css`,
  `kinetic-mobile.css`, `kinetic-auth.css`.
- `content.json` — the shop catalogue (8 products, $1,825 total), lookbook,
  reviews and site copy. All image references point to `.svg` files.
- `index.html`, `robots.txt`, `sitemap.xml` — the site root files.

Total: **26 files. No images, no admin files, no documentation beyond this
README.** (The full package with images and the mobile-UX note is the separate
"full snapshot" archive.)

## How to apply it

1. **Back up the existing deployment first** (copy the whole site folder).
2. Copy the contents of `kinetic/` over the existing site folder, replacing
   files with the same names. Do **not** delete `assets/images/` — the 57 SVG
   artworks already on the server stay in place.
3. Confirm the site still loads: homepage, one product page, cart, and the demo
   checkout. The only expected failed requests are the two cosmetic
   backend probes (`/api/health`, `/api/products`) — the shop falls back to the
   local `content.json` data.

## Important

- **Images are NOT updated by this package.** If the existing deployment still
  has the old `.jpg` photos, they will stay in place — this update does not
  remove or replace them. Updating the images is a separate step (replace the
  57 JPGs with the 57 SVGs from the full release package).
- **No admin panel.** The former owner console (`kinetic-admin.js`,
  `kinetic-admin-dash.js/css`, `kinetic-gh-config.js`, `admin.html`) was removed
  from the release. If the existing deployment still has those files, **delete
  them** — this package does not include replacements for them, and no `#admin`
  route exists any more. There is no login and no PIN.
- **Demo checkout only.** Cart, checkout, accounts and orders are stored in the
  browser's localStorage. No payment is taken, no email is sent. Do not present
  the demo checkout as real payment processing.
- **No backend.** There is no server, database, payment gateway, or email
  service. Do not invent one.
- The brand, products, prices, reviews and lookbook content are **fictional
  demo content** — replace them with real content before selling.

# KINETIC® — Admin Dashboard

The professional management console that sits behind `#admin`.
Everything on it is driven by **real data from your own shop** — no placeholder charts,
no invented statistics.

---

## 1. How it was added without touching your site

Two brand-new files, loaded only on the `#admin` route:

| File | Size | What it is |
|---|---|---|
| `assets/kinetic-admin-dash.css` | 25 KB | every rule is prefixed `kad-`, so it cannot collide with your design |
| `assets/kinetic-admin-dash.js` | 168 KB | the console itself, wrapped in its own private scope |

`index.html` gained exactly **two lines**:

```html
<link rel="stylesheet" href="assets/kinetic-admin-dash.css?v=1">   <!-- after kinetic-product.css -->
<script src="assets/kinetic-admin-dash.js?v=1"></script>            <!-- after kinetic-admin.js -->
```

A visitor who never types `#admin` downloads the script but **nothing is rendered** —
the console builds no DOM, opens no drawer and adds no class to `<body>`.

Your existing store manager (`kinetic-admin.js`) is still there and still works. On the
`#admin` route the new console takes over the front door and hands the old panel to you
from **Page content** — the PIN you type unlocks both (one PIN, one session, no second prompt).

---

## 2. The nine screens

| Screen | What it does |
|---|---|
| **Dashboard** | total sales, total orders, total customers, total products, pending + completed orders, low-stock and sold-out products, a revenue chart you can switch between 7 / 14 / 30 days, best-selling products and the latest orders |
| **Orders** | every order with customer, items, totals, payment status and delivery status; search by number / name / email / city; filter by status, payment, date range; change the order status; print the receipt; export or import CSV |
| **Products** | add, edit and delete products: image (upload or library), name, description, price, sale price, SKU, category, badge, sizes, colours, stock, live/draft status, featured toggle, edition size, rating |
| **Inventory** | live per-size stock for every product, low-stock warning, sold-out sizes, manual stock entry that writes straight to the product page |
| **Customers** | the list of real buyers with total orders, total spend, average order value and their first order date; open a profile to see their order history |
| **Categories** | create, rename, reorder, hide and delete; renaming moves the products with it and the shop's filter bar updates live |
| **Coupons** | percentage or fixed discounts, minimum spend, expiry date, usage limit, enable/disable, internal note — and the code really works at checkout |
| **Page content** | the hub that opens the original text / numbers / shop-settings editor without asking for the PIN again |
| **Settings** | low-stock threshold, orders per page, session length, PIN change, lock now, order-sync endpoint, exports, backup and restore |

**Login:** open `#admin` → type your PIN (`1234` until you change it in Settings → Security).
The lock screen deliberately does not print the PIN. Wrong PINs are throttled, and the
session locks itself after a period of inactivity (45 minutes by default).

---

## 3. Where the numbers come from

Nothing on this dashboard is simulated. Each figure has one honest source:

| Figure | Source |
|---|---|
| Total sales, revenue chart, AOV | real orders in `localStorage['kinetic-orders-v1']`, cancelled and refunded orders excluded |
| Total / pending / completed orders | the same order list, counted by status |
| Total customers | the unique buyers in that order list, keyed by email or phone |
| Customer spend, order count, "first order" date | that customer's own orders (the label says *first order*, not *registration*, because that is what it truthfully is) |
| Total products, drafts, featured | the product list in your content file |
| Stock, low-stock, sold-out | the same stock rule the product page uses, plus any stock you set by hand |
| Best sellers, units sold | the quantities inside real orders |
| Coupon usage | how many real orders carry that code |

**One important limit, stated plainly in the UI:** orders are stored in the customer's own
browser, so a dashboard only ever sees the orders placed on the device it is opened on.
The Dashboard says so on screen, and Settings offers an **order-sync endpoint**: paste a
URL (a Google Apps Script, a form service, a serverless function) and every new order is
also POSTed there, so one dashboard can see orders from every customer. Leave it blank and
the shop simply stores orders locally as it does today.

---

## 4. Protecting admin-only routes

* The console is unreachable without the PIN — including its JavaScript API: `data()`,
  `list*()`, `metrics()`, `updateOrder()` and friends all return `null` while locked.
* Lock = the entire console is removed from the DOM, the session is cleared and a fresh
  PIN screen is built. Nothing stays in the page for a passer-by to read.
* The URL never leaves `#admin` (the console owns that hash), so customer pages,
  anchors and direct links to the shop keep working exactly as before.
* Failed PIN attempts are counted and throttled; a stale session falls back to the lock.
* Draft products never reach the storefront — the shop filters them out.

---

## 5. Data safety

* The console writes through the existing store manager (`KINETIC_ADMIN.saveLocal`), so
  it edits **the same working copy** the old panel edits — no second storage key, no
  chance of two writers fighting.
* `Publish live` (top bar, or the old panel's publish tab) puts the content file —
  products, categories, coupons and console settings included — on your GitHub Pages site.
* **Settings → Data** offers: download `content.json`, export products/orders CSV,
  import a content file, backup, restore and reset.

---

## 6. What was verified in the browser

**189 automated checks, 0 failures, 0 page errors** (headless Chrome, desktop 1500/1440 px,
tablet 900/768 px, phone 420/414/390/360 px):

* **Auth** — lock screen before unlock, wrong PIN refused, right PIN opens, throttling,
  idle auto-lock, manual lock, PIN change (the old PIN stops working, the new one works,
  the older panel reads the same PIN), console API empty while locked.
* **Products** — create (name, SKU, price, sale price, category, status, featured, sizes,
  stock), edit, duplicate, delete with confirmation, draft products hidden from the shop,
  new products appearing on the storefront and in search, filters and pagination.
* **Orders** — a real order placed through the real checkout then found in the dashboard:
  totals match to the cent, status change writes back to the order the customer sees,
  payment status, internal note, timeline, search, filters, empty state.
* **Inventory** — a live stock edit writes to the real product record and the storefront
  immediately reports the new stock.
* **Customers** — derived from that order: name, email, spend, order count, order history.
* **Categories** — create, rename (products migrate), hidden categories, storefront filter
  bar updating live, filtering actually returning the right products.
* **Coupons** — create percent and fixed; the code applies at checkout for the exact
  discount; minimum spend, expiry and "switched off" are all refused with real messages;
  the shop's own `KINETIC20` promo still works.
* **Customer-facing site** — 8 products still render, quick view, PDP, cart, checkout and
  filters all still work, no admin DOM or class leaks into the shop, no horizontal
  overflow at any tested width.

Screenshots: `/home/user/shots-dash/` (`D1-dashboard`, `D2-orders`, `D3-order-detail`,
`D4-product-editor`, `D5-inventory`, `D6-coupons`, `D7-customers`, `D8-categories`,
`D9`–`D11` mobile).

---

## 7. Files at a glance

```
index.html                     + 2 lines (stylesheet + script)
assets/kinetic-admin-dash.css  new — console styling
assets/kinetic-admin-dash.js   new — console logic
assets/kinetic-admin.js        modified — bridge for the console, never opens itself when
                                          the console is present
assets/kinetic-content.js      modified — carries categories, coupons, settings and the new
                                          product fields through the content file
assets/kinetic-app.js          modified — draft/featured/stock/sizes support, live category
                                          filter bar, reloadContent()
assets/kinetic-checkout.js     modified — real coupon validation, order history cap 300,
                                          optional order-sync POST
```

Everything else — your markup, styling, fonts, animations, images — is untouched.

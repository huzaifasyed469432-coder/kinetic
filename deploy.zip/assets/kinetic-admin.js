/* =============================================================================
   KINETIC® — Admin Panel  (assets/kinetic-admin.js)
   Drop-in store manager for the KINETIC site.

   • Two links:  index.html        -> customer view
                 index.html#admin  -> owner view (PIN)
   • Edit products, numbers, shop settings and every text on the site.
   • Save: this device (instant preview) · content.json download · one-click
     publish to GitHub so the live site updates for everyone.
   Loaded in <head> BEFORE kinetic-content.js so local preview can take over.
   ========================================================================== */
(function () {
  'use strict';

  var BUILD = 'kinetic-admin v1.0';
  var LSK = {
    content: 'kinetic-admin-content-v1',   // the owner's working copy
    preview: 'kinetic-admin-preview-v1',   // "show my copy on this device"
    pin:     'kinetic-admin-pin-v1',
    token:   'kinetic-admin-token-v1',
    cache:   'kinetic-content-cache-v1'    // the key kinetic-content.js itself reads
  };
  var DEFAULT_PIN = '1234';
  var imageQueue = [];   // images waiting to be committed to the repo on publish

  /* ------------------------------------------------------------------ utils */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function clone(o) { try { return JSON.parse(JSON.stringify(o)); } catch (e) { return {}; } }
  /* storage: localStorage when the browser allows it (normal case), otherwise a
     small in-memory store so the panel still works inside restricted previews */
  var MEM = {};
  function lsGet(k, d) {
    try { var v = localStorage.getItem(k); if (v) return JSON.parse(v); } catch (e) { if (k in MEM) return JSON.parse(MEM[k]); }
    return (k in MEM) ? JSON.parse(MEM[k]) : d;
  }
  function lsSet(k, v) {
    var ok = false;
    try { localStorage.setItem(k, JSON.stringify(v)); ok = true; } catch (e) { ok = false; }
    MEM[k] = JSON.stringify(v);
    return ok;
  }
  function lsRaw(k, d) {
    try { var v = localStorage.getItem(k); if (v) return v; } catch (e) {}
    return (k in MEM) ? MEM[k] : d;
  }
  function money(n) { return '$' + (Number(n) || 0).toLocaleString('en-US'); }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function gh() {
    var g = window.__GH__ || {};
    if (!g.owner || !g.repo || g.owner === 'OWNER_PLACEHOLDER') return null;
    return { owner: g.owner, repo: g.repo, branch: g.branch || 'main', api: 'https://api.github.com/repos/' + g.owner + '/' + g.repo };
  }
  function contentUrls() {
    var g = gh(); if (!g) return [];
    return [
      g.api + '/contents/content.json?ref=' + encodeURIComponent(g.branch),
      'https://raw.githubusercontent.com/' + g.owner + '/' + g.repo + '/' + encodeURIComponent(g.branch) + '/content.json'
    ];
  }

  /* --------------------------------------------------- local preview override
     kinetic-content.js fetches content.json and prefers it over anything saved
     locally. While the owner is previewing, we answer those two requests with
     their working copy so the site renders exactly what they are editing.     */
  function previewOn() { return lsGet(LSK.preview, false) === true; }

  /* a very small fetch fallback for older browsers (and for any environment
     where the site's content loader would otherwise find no fetch at all) */
  function installFetchPolyfill() {
    /* never replace a fetch that is already there (native or a test harness);
       only add the missing Response/Headers shims next to it */
    if (typeof window.Response !== 'function') {
      function HeadersLite(map) {
        this._m = map || {};
        this.get = function (k) { return this._m[String(k).toLowerCase()] || null; };
      }
      window.Headers = window.Headers || HeadersLite;
      window.Response = function (body, opts) {
        opts = opts || {};
        this._body = body;
        this.status = opts.status || 200;
        this.ok = this.status >= 200 && this.status < 300;
        this.headers = new HeadersLite(opts.headers || {});
        this.json = function () { return Promise.resolve(JSON.parse(this._body)); };
        this.text = function () { return Promise.resolve(this._body); };
      };
    }
    if (typeof window.fetch === 'function') return;
    window.fetch = function (url, init) {
      init = init || {};
      return new Promise(function (resolve, reject) {
        var xhr = new XMLHttpRequest();
        xhr.open(init.method || 'GET', url, true);
        var h = init.headers || {};
        Object.keys(h).forEach(function (k) { try { xhr.setRequestHeader(k, h[k]); } catch (e) {} });
        if (init.signal) { init.signal.addEventListener('abort', function () { xhr.abort(); }); }
        xhr.onload = function () {
          var ct = (xhr.getResponseHeader && xhr.getResponseHeader('content-type')) || '';
          resolve(new window.Response(xhr.responseText, { status: xhr.status, headers: new window.Headers({ 'content-type': ct }) }));
        };
        xhr.onerror = function () { reject(new TypeError('network error')); };
        xhr.ontimeout = function () { reject(new TypeError('timeout')); };
        try { xhr.send(init.body || null); } catch (e) { reject(e); }
      });
    };
  }
  function installFetchOverride() {
    if (!previewOn() || window.__kaFetchPatched) return;
    window.__kaFetchPatched = true;
    var original = window.fetch ? window.fetch.bind(window) : null;
    window.fetch = function (input, init) {
      try {
        var url = typeof input === 'string' ? input : (input && input.url) || '';
        var mine = lsGet(LSK.content, null);
        if (mine && contentUrls().some(function (u) { return url.indexOf(u.split('?')[0]) === 0; })) {
          return Promise.resolve(new Response(JSON.stringify(mine), {
            status: 200, headers: { 'Content-Type': 'application/json' }
          }));
        }
      } catch (e) { /* fall through to the real fetch */ }
      return original ? original(input, init) : Promise.reject(new Error('no-fetch'));
    };
  }
  function installCacheSeed() {
    /* keep kinetic-content.js's own cache in sync with the working copy so the
       site still shows it when GitHub is unreachable */
    var mine = lsGet(LSK.content, null);
    if (previewOn() && mine) lsSet(LSK.cache, mine);
  }

  /* -------------------------------------------------------------- content io */
  function defaults() { return clone(window.__KINETIC_DEFAULTS__ || {}); }

  function normalise(c) {
    c = c || {};
    c.marketing = c.marketing || {};
    c.commerce = c.commerce || {};
    c.texts = c.texts || {};
    if (!Array.isArray(c.products)) c.products = [];
    if (!Array.isArray(c.reviews)) c.reviews = [];
    if (!Array.isArray(c.looks)) c.looks = [];
    if (!Array.isArray(c.techImgs)) c.techImgs = [];
    c.products.forEach(function (p, i) {
      if (!Array.isArray(p.colors)) p.colors = [];
      if (!Array.isArray(p.colorways) || !p.colorways.length) {
        p.colorways = (p.colors.length ? p.colors : ['#08080A']).map(function (hex, k) {
          return { name: 'Colourway ' + (k + 1), swatch: hex };
        });
      } else {
        p.colorways = p.colorways.map(function (cw, k) {
          return { name: (cw && cw.name) || ('Colourway ' + (k + 1)), swatch: (cw && (cw.swatch || cw.hex)) || '#08080A' };
        });
      }
      p.colors = p.colorways.map(function (cw) { return cw.swatch; });
      if (p.old === undefined) p.old = null;
      if (p.ord === undefined) p.ord = i;
    });
    return c;
  }

  function workingCopy() {
    var stored = lsGet(LSK.content, null);
    if (stored) return normalise(stored);
    if (window.__KINETIC_CONTENT__) return normalise(clone(window.__KINETIC_CONTENT__));
    return normalise(defaults());
  }

  var STATE = null;   // the live working copy inside the panel

  /* ------------------------------------------------------------------- styles */
  var CSS = [
    '#kaRoot{position:fixed;inset:0;z-index:99990;display:none;font-family:system-ui,-apple-system,"Segoe UI",Arial,sans-serif}',
    '#kaRoot.on{display:block}',
    '#kaRoot *{box-sizing:border-box}',
    '#kaScrim{position:absolute;inset:0;background:rgba(4,4,6,.86);backdrop-filter:blur(6px)}',
    '#kaWrap{position:relative;max-width:1180px;height:100%;margin:0 auto;padding:22px 16px;display:flex;flex-direction:column;gap:16px}',
    '#kaBar{display:flex;align-items:center;gap:14px;flex-wrap:wrap;background:#08080A;border:2px solid #d4af37;padding:14px 18px;box-shadow:8px 8px 0 rgba(212,175,55,.22)}',
    '#kaBar .ka-logo{font-family:Impact,"Arial Black",sans-serif;font-size:26px;line-height:1;color:#f5f0ea;letter-spacing:.02em}',
    '#kaBar .ka-logo b{color:#d4af37}',
    '#kaBar .ka-tag{font-family:"Courier New",monospace;font-size:10.5px;letter-spacing:.22em;text-transform:uppercase;color:#d4af37;border:1px solid rgba(212,175,55,.45);padding:6px 10px}',
    '#kaBar .ka-spacer{flex:1}',
    '.ka-btn{font-family:"Courier New",monospace;font-size:11px;letter-spacing:.16em;text-transform:uppercase;font-weight:700;padding:11px 16px;border:2px solid #d4af37;background:#d4af37;color:#08080A;cursor:pointer;transition:.16s}',
    '.ka-btn:hover{background:#f2d273;border-color:#f2d273;transform:translate(-1px,-1px)}',
    '.ka-btn.ghost{background:transparent;color:#d4af37}',
    '.ka-btn.ghost:hover{background:rgba(212,175,55,.14);color:#f2d273}',
    '.ka-btn.dark{background:#111113;color:#f5f0ea;border-color:rgba(212,175,55,.4)}',
    '.ka-btn.dark:hover{border-color:#d4af37;color:#f2d273}',
    '.ka-btn.danger{background:transparent;color:#ff8080;border-color:rgba(255,128,128,.5)}',
    '.ka-btn.danger:hover{background:rgba(255,128,128,.14)}',
    '.ka-btn.sm{padding:8px 11px;font-size:10px}',
    '.ka-btn:disabled{opacity:.4;cursor:not-allowed;transform:none}',
    '#kaTabs{display:flex;gap:8px;flex-wrap:wrap}',
    '.ka-tab{font-family:"Courier New",monospace;font-size:11px;letter-spacing:.16em;text-transform:uppercase;font-weight:700;padding:11px 16px;border:2px solid rgba(212,175,55,.32);background:#0d0d10;color:#c9c3b6;cursor:pointer}',
    '.ka-tab:hover{border-color:#d4af37;color:#f2d273}',
    '.ka-tab.on{background:#d4af37;border-color:#d4af37;color:#08080A;box-shadow:5px 5px 0 rgba(212,175,55,.25)}',
    '#kaBody{flex:1;overflow:auto;background:#0b0b0e;border:2px solid rgba(212,175,55,.28);padding:22px;color:#f5f0ea}',
    '#kaBody::-webkit-scrollbar{width:10px}#kaBody::-webkit-scrollbar-thumb{background:#2a2a30}',
    '.ka-h{font-family:Impact,"Arial Black",sans-serif;font-size:26px;line-height:1.05;color:#f5f0ea;margin:0 0 4px;letter-spacing:.01em}',
    '.ka-sub{font-family:"Courier New",monospace;font-size:10.5px;letter-spacing:.2em;text-transform:uppercase;color:rgba(245,240,234,.5);margin:0 0 18px}',
    '.ka-note{border-left:3px solid #d4af37;background:rgba(212,175,55,.07);padding:12px 14px;font-size:13.5px;line-height:1.65;color:rgba(245,240,234,.82);margin:0 0 18px}',
    '.ka-note b{color:#f2d273}',
    '.ka-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:14px}',
    '.ka-card{border:2px solid rgba(212,175,55,.24);background:#101014;padding:14px;display:flex;gap:12px;align-items:flex-start}',
    '.ka-card img{width:74px;height:74px;object-fit:cover;border:1px solid rgba(212,175,55,.4);background:#08080A;flex:0 0 auto}',
    '.ka-card .ka-ci{flex:1;min-width:0}',
    '.ka-card .ka-cn{font-family:Impact,"Arial Black",sans-serif;font-size:17px;color:#f5f0ea;line-height:1.15}',
    '.ka-card .ka-cm{font-family:"Courier New",monospace;font-size:10px;letter-spacing:.14em;text-transform:uppercase;color:rgba(245,240,234,.5);margin-top:5px}',
    '.ka-card .ka-cp{color:#d4af37;font-weight:700;margin-top:6px;font-size:14px}',
    '.ka-card .ka-cp s{color:rgba(245,240,234,.4);margin-left:8px;font-weight:400}',
    '.ka-actions{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}',
    '.ka-rowbtns{display:flex;flex-direction:column;gap:5px}',
    '.ka-field{display:grid;gap:6px;margin-bottom:14px}',
    '.ka-field>label{font-family:"Courier New",monospace;font-size:10.5px;letter-spacing:.16em;text-transform:uppercase;color:rgba(245,240,234,.62);font-weight:700}',
    '.ka-field .ka-hint{font-size:12px;color:rgba(245,240,234,.42)}',
    '.ka-in{padding:11px 12px;border:2px solid rgba(212,175,55,.28);background:#08080A;color:#f5f0ea;font-size:14px;width:100%;font-family:inherit}',
    '.ka-in:focus{outline:none;border-color:#d4af37;box-shadow:0 0 0 3px rgba(212,175,55,.14)}',
    'textarea.ka-in{min-height:92px;resize:vertical;line-height:1.6}',
    '.ka-2{display:grid;grid-template-columns:1fr 1fr;gap:14px}',
    '.ka-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}',
    '.ka-color{width:44px;height:44px;padding:0;border:2px solid rgba(212,175,55,.4);background:#08080A;cursor:pointer}',
    '.ka-cw{display:flex;gap:8px;align-items:center;margin-bottom:8px}',
    '.ka-cw .ka-in{padding:9px 10px}',
    '.ka-x{width:38px;height:38px;flex:0 0 auto;border:2px solid rgba(255,128,128,.45);background:transparent;color:#ff8080;cursor:pointer;font-size:15px}',
    '.ka-x:hover{background:rgba(255,128,128,.14)}',
    '.ka-mv{width:38px;height:34px;border:2px solid rgba(212,175,55,.35);background:#0d0d10;color:#d4af37;cursor:pointer}',
    '.ka-mv:hover{border-color:#d4af37;background:rgba(212,175,55,.14)}',
    '.ka-imgs{display:flex;gap:12px;align-items:flex-start;flex-wrap:wrap}',
    '.ka-imgs img{width:128px;height:128px;object-fit:cover;border:2px solid rgba(212,175,55,.4);background:#08080A}',
    '#kaToasts{position:fixed;left:20px;bottom:20px;z-index:99999;display:grid;gap:10px;max-width:340px}',
    '.ka-toast{background:#08080A;border:2px solid #d4af37;color:#f5f0ea;padding:12px 14px;font-size:14px;box-shadow:6px 6px 0 rgba(212,175,55,.25);animation:kaUp .2s ease-out}',
    '.ka-toast.err{border-color:#ff8080;color:#ffd9d9;box-shadow:6px 6px 0 rgba(255,128,128,.22)}',
    '@keyframes kaUp{from{transform:translateY(10px);opacity:0}to{transform:none;opacity:1}}',
    '#kaGate{position:fixed;inset:0;z-index:99995;display:none;place-items:center;background:rgba(4,4,6,.9);backdrop-filter:blur(8px)}',
    '#kaGate.on{display:grid}',
    '#kaGate .ka-box{width:min(430px,92vw);background:#0b0b0e;border:2px solid #d4af37;box-shadow:10px 10px 0 rgba(212,175,55,.22);padding:30px}',
    '#kaGate h3{font-family:Impact,"Arial Black",sans-serif;font-size:30px;margin:0 0 6px;color:#f5f0ea}',
    '#kaGate p{margin:0 0 20px;color:rgba(245,240,234,.6);font-size:14px;line-height:1.6}',
    '#kaPin{width:100%;text-align:center;letter-spacing:.6em;font-size:22px;padding:14px;background:#08080A;border:2px solid rgba(212,175,55,.4);color:#d4af37}',
    '#kaPin:focus{outline:none;border-color:#d4af37}',
    '.ka-pill{display:inline-block;font-family:"Courier New",monospace;font-size:9.5px;letter-spacing:.18em;text-transform:uppercase;border:1px solid rgba(212,175,55,.5);color:#d4af37;padding:4px 8px}',
    '.ka-pill.live{border-color:#66d18a;color:#66d18a}',
    '.ka-kv{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:12px}',
    '.ka-copy{display:flex;gap:8px}',
    '@media(max-width:700px){.ka-2,.ka-3{grid-template-columns:1fr}#kaWrap{padding:12px}.ka-card img{width:60px;height:60px}}'
  ].join('\n');

  /* ------------------------------------------------------------------ toasts */
  function toast(msg, kind) {
    var host = $('#kaToasts');
    if (!host) { host = document.createElement('div'); host.id = 'kaToasts'; document.body.appendChild(host); }
    var t = document.createElement('div');
    t.className = 'ka-toast' + (kind === 'err' ? ' err' : '');
    t.textContent = msg;
    host.appendChild(t);
    setTimeout(function () { t.style.opacity = '0'; t.style.transform = 'translateY(8px)'; t.style.transition = '.25s'; setTimeout(function () { t.remove(); }, 300); }, 3200);
  }

  /* --------------------------------------------------------------- the panel */
  var TEXT_GROUPS = [
    ['Hero', ['hero.badge', 'hero.line1', 'hero.line2', 'hero.line3', 'hero.sub', 'hero.cta1', 'hero.cta2', 'site.badge']],
    ['Ticker (top strip)', ['ticker.0', 'ticker.1', 'ticker.2']],
    ['Collection section', ['sections.collectionKicker', 'sections.collectionTitle1', 'sections.collectionTitle2', 'sections.collectionSub']],
    ['Tech section', ['sections.techKicker', 'sections.techTitle1', 'sections.techTitle2', 'sections.techSub',
      'techFeatures.0.title', 'techFeatures.0.body', 'techFeatures.0.s1', 'techFeatures.0.s2',
      'techFeatures.1.title', 'techFeatures.1.body', 'techFeatures.1.s1', 'techFeatures.1.s2',
      'techFeatures.2.title', 'techFeatures.2.body', 'techFeatures.2.s1', 'techFeatures.2.s2']],
    ['Performance section', ['sections.perfKicker', 'sections.perfTitle1', 'sections.perfTitle2', 'sections.perfSub', 'sections.perfCta']],
    ['Lookbook', ['sections.lookbookKicker', 'sections.lookbookTitle1', 'sections.lookbookTitle2']],
    ['Reviews', ['sections.storiesKicker', 'sections.storiesTitle1', 'sections.storiesTitle2']],
    ['Club / newsletter', ['sections.clubKicker', 'sections.clubTitle1', 'sections.clubTitle2', 'sections.clubSub', 'sections.clubSuccess']],
    ['Footer', ['footer.blurb', 'footer.copy', 'footer.tagline']]
  ];

  var NUMBER_FIELDS = [
    ['runners', 'Runners in the community'],
    ['members', 'Members (shown live)'],
    ['membersTeaser', 'Members teaser number'],
    ['averageRating', 'Average rating'],
    ['testedAthletes', 'Athletes tested with'],
    ['stylesLive', 'Styles live (auto = product count)'],
    ['totalReviews', 'Total reviews'],
    ['wouldRebuyPercent', 'Would rebuy %'],
    ['labIterationYears', 'Years of lab iteration'],
    ['fieldTestKm', 'Field-test kilometres'],
    ['energyReturnPercent', 'Energy return %'],
    ['plateDropMm', 'Plate drop (mm)'],
    ['productWeightGrams', 'Product weight (g)'],
    ['airflowDegrees', 'Airflow (degrees)'],
    ['impactAbsorptionMultiplier', 'Impact absorption (x)'],
    ['testedLifeKm', 'Tested life (km)'],
    ['weightReductionPercent', 'Weight reduction %'],
    ['impactAbsorptionPercent', 'Impact absorption %'],
    ['durabilityIndexPercent', 'Durability index %']
  ];

  function buildPanel() {
    if ($('#kaRoot')) return;
    var style = document.createElement('style');
    style.textContent = CSS;
    document.head.appendChild(style);

    var root = document.createElement('div');
    root.id = 'kaRoot';
    root.innerHTML = [
      '<div id="kaScrim"></div>',
      '<div id="kaWrap">',
      '  <div id="kaBar">',
      '    <span class="ka-logo">KINETIC<b>®</b></span>',
      '    <span class="ka-tag">Store manager</span>',
      '    <span class="ka-spacer"></span>',
      '    <span id="kaStatus" class="ka-pill">checking…</span>',
      '    <button class="ka-btn" id="kaSaveBtn">Save &amp; preview</button>',
      '    <button class="ka-btn ghost" id="kaPublishBtn">Publish live</button>',
      '    <button class="ka-btn dark" id="kaViewBtn">View site</button>',
      '    <button class="ka-btn danger" id="kaClose">Close</button>',
      '  </div>',
      '  <div id="kaTabs">',
      '    <button class="ka-tab on" data-ktab="products">Products</button>',
      '    <button class="ka-tab" data-ktab="numbers">Numbers</button>',
      '    <button class="ka-tab" data-ktab="shop">Shop settings</button>',
      '    <button class="ka-tab" data-ktab="text">Page text</button>',
      '    <button class="ka-tab" data-ktab="publish">Publish &amp; links</button>',
      '  </div>',
      '  <div id="kaBody"></div>',
      '</div>',
      '<div id="kaGate"><div class="ka-box">',
      '  <h3>Owner access</h3>',
      '  <p>Enter your PIN to open the store manager. Change the PIN any time in <b>Publish &amp; links</b>.</p>',
      '  <input id="kaPin" type="password" inputmode="numeric" maxlength="8" placeholder="••••" autocomplete="off">',
      '  <div style="display:flex;gap:10px;margin-top:16px">',
      '    <button class="ka-btn" id="kaUnlock" style="flex:1">Unlock</button>',
      '    <button class="ka-btn ghost" id="kaCancel">Cancel</button>',
      '  </div>',
      '</div></div>'
    ].join('\n');
    document.body.appendChild(root);

    if (!$('#kaToasts')) { var t = document.createElement('div'); t.id = 'kaToasts'; document.body.appendChild(t); }

    $('#kaClose').addEventListener('click', close);
    $('#kaScrim').addEventListener('click', close);
    $('#kaViewBtn').addEventListener('click', function () { close(true); });
    $('#kaSaveBtn').addEventListener('click', function () { saveLocal(true); });
    $('#kaPublishBtn').addEventListener('click', publishFlow);
    $('#kaTabs').addEventListener('click', function (e) {
      var b = e.target.closest('[data-ktab]'); if (!b) return;
      collect();                       // keep whatever was typed on the current tab
      $$('.ka-tab').forEach(function (x) { x.classList.toggle('on', x === b); });
      renderTab(b.getAttribute('data-ktab'));
      paintStatus();
    });
    $('#kaUnlock').addEventListener('click', tryUnlock);
    $('#kaPin').addEventListener('keydown', function (e) { if (e.key === 'Enter') tryUnlock(); });
    $('#kaCancel').addEventListener('click', function () { $('#kaGate').classList.remove('on'); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && $('#kaRoot').classList.contains('on')) close();
      if (e.ctrlKey && e.shiftKey && (e.key === 'A' || e.key === 'a')) { e.preventDefault(); open(); }
    });
  }

  function currentTab() { var on = $('.ka-tab.on'); return on ? on.getAttribute('data-ktab') : 'products'; }
  function rootOpen() { var r = $('#kaRoot'); return !!(r && r.classList.contains('on')); }

  function renderTab(name) {
    var b = $('#kaBody'); if (!b) return;
    if (name === 'numbers') return renderNumbers(b);
    if (name === 'shop') return renderShop(b);
    if (name === 'text') return renderText(b);
    if (name === 'publish') return renderPublish(b);
    return renderProducts(b);
  }

  /* ------------------------------------------------------------- products UI */
  function renderProducts(host) {
    var list = STATE.products.slice().sort(function (a, b) { return (a.ord || 0) - (b.ord || 0); });
    host.innerHTML = [
      '<h2 class="ka-h">Products</h2>',
      '<p class="ka-sub">' + list.length + ' products · tap ↑ ↓ to arrange · the site shows this exact order</p>',
      '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px">',
      '  <button class="ka-btn" id="kaAdd">+ Add product</button>',
      '  <input class="ka-in" id="kaSearch" placeholder="Search products…" style="max-width:260px">',
      '</div>',
      '<div class="ka-grid" id="kaList"></div>'
    ].join('');
    $('#kaAdd').addEventListener('click', function () { editProduct(null); });
    $('#kaSearch').addEventListener('input', function () { paintList(); });
    $('#kaList').addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button') : null;
      if (!b) return;
      var mv = b.getAttribute('data-mv');
      if (mv !== null) { moveProduct(mv, Number(b.getAttribute('data-dir'))); return; }
      var ed = b.getAttribute('data-ed');
      if (ed !== null) { editProduct(Number(ed)); return; }
      var dp = b.getAttribute('data-dup');
      if (dp !== null) { duplicateProduct(Number(dp)); return; }
      var dl = b.getAttribute('data-del');
      if (dl !== null) { deleteProduct(Number(dl)); return; }
    });
    paintList();
  }

  function paintList() {
    var q = ($('#kaSearch') && $('#kaSearch').value || '').toLowerCase();
    var list = STATE.products.slice().sort(function (a, b) { return (a.ord || 0) - (b.ord || 0); });
    if (q) list = list.filter(function (p) { return (p.name + ' ' + p.cat + ' ' + (p.tag || '')).toLowerCase().indexOf(q) > -1; });
    var host = $('#kaList'); if (!host) return;
    if (!list.length) { host.innerHTML = '<p class="ka-note">No products yet. Use <b>+ Add product</b> to create your first one.</p>'; return; }
    host.innerHTML = list.map(function (p) {
      var idx = STATE.products.indexOf(p);
      return [
        '<div class="ka-card" data-id="' + p.id + '">',
        '  <div class="ka-rowbtns">',
        '    <button class="ka-mv" data-mv="' + p.id + '" data-dir="-1" title="Move up">↑</button>',
        '    <button class="ka-mv" data-mv="' + p.id + '" data-dir="1" title="Move down">↓</button>',
        '  </div>',
        '  <img src="' + esc(p.img) + '" alt="" onerror="this.style.opacity=.3">',
        '  <div class="ka-ci">',
        '    <div class="ka-cn">' + esc(p.name) + '</div>',
        '    <div class="ka-cm">' + esc(p.cat) + (p.tag ? ' · ' + esc(p.tag) : '') + ' · ★ ' + esc(p.rating) + ' · ' + esc(p.reviews) + ' reviews</div>',
        '    <div class="ka-cp">' + money(p.price) + (p.old ? '<s>' + money(p.old) + '</s>' : '') + '</div>',
        '    <div class="ka-actions">',
        '      <button class="ka-btn sm" data-ed="' + idx + '">Edit</button>',
        '      <button class="ka-btn sm dark" data-dup="' + idx + '">Duplicate</button>',
        '      <button class="ka-btn sm danger" data-del="' + idx + '">Delete</button>',
        '    </div>',
        '  </div>',
        '</div>'
      ].join('');
    }).join('');
  }

  function moveProduct(id, dir) {
    var list = STATE.products.slice().sort(function (a, b) { return (a.ord || 0) - (b.ord || 0); });
    var i = -1, targetId = Number(id);
    list.forEach(function (p, k) { if (Number(p.id) === targetId) i = k; });
    var j = i + dir;
    if (i < 0 || j < 0 || j >= list.length) return;
    var tmp = list[i]; list[i] = list[j]; list[j] = tmp;
    list.forEach(function (p, k) { p.ord = k; });
    STATE.products = list;
    paintList();
    autoSave();
  }

  function duplicateProduct(index) {
    var p = STATE.products[index]; if (!p) return;
    var copy = clone(p);
    var maxId = -1;
    STATE.products.forEach(function (x) { if (Number(x.id) > maxId) maxId = Number(x.id); });
    copy.id = maxId + 1;
    copy.name = p.name + ' (copy)';
    copy.ord = STATE.products.length;
    STATE.products.push(copy);
    paintList();
    autoSave();
    toast('Copy created — open Edit to change it.');
  }

  function deleteProduct(index) {
    var p = STATE.products[index]; if (!p) return;
    if (!confirm('Delete “' + p.name + '”? This cannot be undone (publish afterwards to remove it from the live site).')) return;
    STATE.products.splice(index, 1);
    STATE.products.forEach(function (x, i) { x.ord = i; });
    paintList();
    autoSave();
    toast('Product deleted — saved on this device. Press Publish to update the live site.');
  }

  function blankProduct() {
    var maxId = -1;
    STATE.products.forEach(function (p) { if (Number(p.id) > maxId) maxId = Number(p.id); });
    return {
      id: maxId + 1, name: 'New Product', cat: 'Running', tag: 'New', price: 150, old: null,
      rating: 4.8, reviews: 0, img: 'assets/images/40a470397f3ef7b7.jpg',
      desc: '', colorways: [{ name: 'Midnight Black', swatch: '#08080A' }], colors: ['#08080A'],
      ord: STATE.products.length
    };
  }

  function editProduct(index) {
    var isNew = index === null;
    var p = isNew ? blankProduct() : clone(STATE.products[index]);
    var cats = {}, tags = {};
    STATE.products.forEach(function (x) { cats[x.cat] = 1; if (x.tag) tags[x.tag] = 1; });

    var host = $('#kaBody');
    host.innerHTML = [
      '<h2 class="ka-h">' + (isNew ? 'Add product' : 'Edit product') + '</h2>',
      '<p class="ka-sub">' + (isNew ? 'Fill in the details and save' : 'Product #' + esc(p.id)) + '</p>',
      '<div class="ka-2">',
      '  <div class="ka-field"><label>Product name</label><input class="ka-in" id="kf_name" value="' + esc(p.name) + '"></div>',
      '  <div class="ka-field"><label>Category</label><input class="ka-in" id="kf_cat" list="kf_cats" value="' + esc(p.cat) + '">',
      '    <datalist id="kf_cats">' + Object.keys(cats).map(function (c) { return '<option value="' + esc(c) + '">'; }).join('') + '</datalist></div>',
      '</div>',
      '<div class="ka-3">',
      '  <div class="ka-field"><label>Price ($)</label><input class="ka-in" id="kf_price" type="number" min="0" step="1" value="' + esc(p.price) + '"></div>',
      '  <div class="ka-field"><label>Old price ($) — for a sale look</label><input class="ka-in" id="kf_old" type="number" min="0" step="1" value="' + (p.old == null ? '' : esc(p.old)) + '"></div>',
      '  <div class="ka-field"><label>Tag / badge</label><input class="ka-in" id="kf_tag" list="kf_tags" value="' + esc(p.tag || '') + '" placeholder="New · Hot · Limited · Icon">',
      '    <datalist id="kf_tags">' + Object.keys(tags).map(function (t) { return '<option value="' + esc(t) + '">'; }).join('') + '</datalist></div>',
      '</div>',
      '<div class="ka-3">',
      '  <div class="ka-field"><label>Rating (0–5)</label><input class="ka-in" id="kf_rating" type="number" min="0" max="5" step="0.1" value="' + esc(p.rating) + '"></div>',
      '  <div class="ka-field"><label>Reviews count</label><input class="ka-in" id="kf_reviews" type="number" min="0" step="1" value="' + esc(p.reviews) + '"></div>',
      '  <div class="ka-field"><label>Edition size (optional)</label><input class="ka-in" id="kf_edition" type="number" min="0" step="1" value="' + (p.editionSize == null ? '' : esc(p.editionSize)) + '" placeholder="e.g. 300 numbered pairs"></div>',
      '</div>',
      '<div class="ka-field"><label>Description</label><textarea class="ka-in" id="kf_desc">' + esc(p.desc || '') + '</textarea></div>',
      '<div class="ka-field"><label>Product image</label>',
      '  <div class="ka-imgs">',
      '    <img id="kf_prev" src="' + esc(p.img) + '" alt="">',
      '    <div style="flex:1;min-width:220px">',
      '      <input class="ka-in" id="kf_img" value="' + esc(/^data:/.test(p.img) ? '' : p.img) + '" placeholder="assets/images/… or https://…">',
      '      <div class="ka-actions">',
      '        <label class="ka-btn sm dark" style="cursor:pointer">Upload image<input type="file" id="kf_file" accept="image/*" hidden></label>',
      '        <button class="ka-btn sm danger" id="kf_clearimg">Remove</button>',
      '      </div>',
      '      <p class="ka-hint" id="kf_imgnote">Uploads are stored with your content. Publishing to GitHub puts them in assets/images/ too.</p>',
      '    </div>',
      '  </div>',
      '</div>',
      '<div class="ka-field"><label>Colourways</label><div id="kf_cws"></div>',
      '  <button class="ka-btn sm ghost" id="kf_addcw" style="justify-self:start">+ Add colourway</button></div>',
      '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:20px">',
      '  <button class="ka-btn" id="kf_save">' + (isNew ? 'Add product' : 'Save product') + '</button>',
      '  <button class="ka-btn ghost" id="kf_cancel">Back to list</button>',
      '</div>'
    ].join('');

    var draft = p;

    function paintCws() {
      $('#kf_cws').innerHTML = draft.colorways.map(function (cw, i) {
        return [
          '<div class="ka-cw">',
          '  <input class="ka-color" type="color" data-cwi="' + i + '" value="' + (/^#[0-9a-f]{6}$/i.test(cw.swatch) ? cw.swatch : '#08080A') + '">',
          '  <input class="ka-in" data-cwn="' + i + '" value="' + esc(cw.name) + '" placeholder="Colour name (e.g. Flame Gold)">',
          '  <button class="ka-x" data-cwx="' + i + '" title="Remove">✕</button>',
          '</div>'
        ].join('');
      }).join('') || '<p class="ka-hint">Add at least one colourway — the site needs it.</p>';
    }
    paintCws();

    function readForm() {
      draft.name = $('#kf_name').value.trim();
      draft.cat = $('#kf_cat').value.trim() || 'Running';
      draft.tag = $('#kf_tag').value.trim();
      draft.price = Number($('#kf_price').value) || 0;
      var old = $('#kf_old').value.trim();
      draft.old = old === '' ? null : Number(old);
      draft.rating = Math.max(0, Math.min(5, Number($('#kf_rating').value) || 0));
      draft.reviews = Math.max(0, Math.round(Number($('#kf_reviews').value) || 0));
      var ed = $('#kf_edition').value.trim();
      draft.editionSize = ed === '' ? undefined : Number(ed);
      draft.desc = $('#kf_desc').value;
      draft.img = $('#kf_img').value.trim() || draft.img;
      draft.colors = draft.colorways.map(function (c) { return c.swatch; });
    }

    $('#kf_addcw').addEventListener('click', function () { readForm(); draft.colorways.push({ name: 'Colourway ' + (draft.colorways.length + 1), swatch: '#d4af37' }); paintCws(); });
    $('#kf_cws').addEventListener('input', function (e) {
      var ci = e.target.getAttribute('data-cwi'), ni = e.target.getAttribute('data-cwn');
      if (ci !== null) draft.colorways[+ci].swatch = e.target.value;
      if (ni !== null) draft.colorways[+ni].name = e.target.value;
    });
    $('#kf_cws').addEventListener('click', function (e) {
      var x = e.target.getAttribute('data-cwx');
      if (x === null) return;
      if (draft.colorways.length <= 1) { toast('Keep at least one colourway.', 'err'); return; }
      draft.colorways.splice(+x, 1); paintCws();
    });
    $('#kf_img').addEventListener('input', function () { $('#kf_prev').src = this.value.trim() || draft.img; });
    $('#kf_clearimg').addEventListener('click', function () { $('#kf_img').value = ''; draft.img = ''; $('#kf_prev').src = 'assets/images/40a470397f3ef7b7.jpg'; });
    $('#kf_file').addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0]; if (!f) return;
      $('#kf_imgnote').textContent = 'Compressing image…';
      shrinkImage(f, 1280, function (dataUrl) {
        draft.img = dataUrl;
        $('#kf_prev').src = dataUrl;
        $('#kf_img').value = '';
        $('#kf_imgnote').textContent = 'Image ready (' + Math.round(dataUrl.length / 1024) + ' KB). Click Save, then Publish live to put it on the site.';
      });
    });
    $('#kf_cancel').addEventListener('click', function () { renderProducts($('#kaBody')); });
    $('#kf_save').addEventListener('click', function () {
      readForm();
      if (!draft.name) { toast('Give the product a name.', 'err'); return; }
      if (!draft.colorways.length) { toast('Add at least one colourway.', 'err'); return; }
      draft.colors = draft.colorways.map(function (c) { return c.swatch; });
      if (isNew) {
        STATE.products.push(draft);
        toast('Product added — saved on this device.');
      } else {
        STATE.products[index] = draft;
        toast('Product updated — saved on this device.');
      }
      renderProducts($('#kaBody'));
      autoSave();
    });
  }

  function shrinkImage(file, max, cb) {
    var fr = new FileReader();
    fr.onload = function (e) {
      var img = new Image();
      img.onload = function () {
        var w = img.width, h = img.height;
        if (w > max || h > max) {
          if (w >= h) { h = Math.round(h * max / w); w = max; } else { w = Math.round(w * max / h); h = max; }
        }
        var c = document.createElement('canvas'); c.width = w; c.height = h;
        c.getContext('2d').drawImage(img, 0, 0, w, h);
        try { cb(c.toDataURL('image/jpeg', 0.85)); } catch (err) { cb(e.target.result); }
      };
      img.onerror = function () { toast('That image could not be loaded.', 'err'); };
      img.src = e.target.result;
    };
    fr.readAsDataURL(file);
  }

  /* -------------------------------------------------------------- numbers UI */
  function renderNumbers(host) {
    host.innerHTML = [
      '<h2 class="ka-h">Numbers</h2>',
      '<p class="ka-sub">Every figure shown across the site — counters, ratings, stats</p>',
      '<div class="ka-note">These feed the animated counters and stat blocks. <b>Styles live</b> is normally kept in sync with your product count.</div>',
      '<div class="ka-3">',
      NUMBER_FIELDS.map(function (f) {
        var v = STATE.marketing[f[0]];
        return '<div class="ka-field"><label>' + esc(f[1]) + '</label><input class="ka-in ka-num" data-mk="' + f[0] + '" type="number" step="any" value="' + (v == null ? '' : esc(v)) + '"></div>';
      }).join(''),
      '</div>',
      '<div style="margin-top:10px"><button class="ka-btn ghost sm" id="kaSyncStyles">Set “Styles live” to my product count (' + STATE.products.length + ')</button></div>'
    ].join('');
    $('#kaSyncStyles').addEventListener('click', function () {
      STATE.marketing.stylesLive = STATE.products.length;
      var input = $('[data-mk="stylesLive"]'); if (input) input.value = STATE.products.length;
      toast('Styles live = ' + STATE.products.length);
    });
  }

  /* ----------------------------------------------------------- shop settings */
  function renderShop(host) {
    var c = STATE.commerce;
    host.innerHTML = [
      '<h2 class="ka-h">Shop settings</h2>',
      '<p class="ka-sub">Shipping and discount rules used at checkout</p>',
      '<div class="ka-3">',
      '  <div class="ka-field"><label>Free shipping from ($)</label><input class="ka-in" id="kc_free" type="number" min="0" step="1" value="' + ((Number(c.freeShippingThresholdCents) || 0) / 100) + '"></div>',
      '  <div class="ka-field"><label>Shipping fee ($)</label><input class="ka-in" id="kc_ship" type="number" min="0" step="1" value="' + ((Number(c.shippingCents) || 0) / 100) + '"></div>',
      '  <div class="ka-field"><label>Promo code</label><input class="ka-in" id="kc_code" value="' + esc(c.promoCode || '') + '" placeholder="KINETIC20"></div>',
      '</div>',
      '<div class="ka-2">',
      '  <div class="ka-field"><label>Promo discount (%)</label><input class="ka-in" id="kc_pct" type="number" min="0" max="100" step="1" value="' + esc(c.promoPercent || 0) + '"></div>',
      '</div>',
      '<div class="ka-note">The promo code is shown in the cart drawer. Customers type it at checkout to get the percentage off.</div>'
    ].join('');
  }

  /* ----------------------------------------------------------------- text UI */
  function renderText(host) {
    var t = STATE.texts;
    var known = {};
    TEXT_GROUPS.forEach(function (g) { g[1].forEach(function (k) { known[k] = 1; }); });
    var extras = Object.keys(t).filter(function (k) { return !known[k]; });

    host.innerHTML = [
      '<h2 class="ka-h">Page text</h2>',
      '<p class="ka-sub">Every headline, paragraph and label on the page</p>',
      '<div class="ka-note">Placeholders like <b>{{members}}</b> or <b>{{energyReturnPercent}}</b> pull live numbers from the Numbers tab — leave them in place.</div>'
    ].concat(TEXT_GROUPS.map(function (g) {
      var fields = g[1].filter(function (k) { return t[k] !== undefined; });
      if (!fields.length) return '';
      return [
        '<h3 class="ka-sub" style="margin:22px 0 10px;color:#d4af37">' + esc(g[0]) + '</h3>',
        fields.map(function (k) {
          var v = String(t[k] == null ? '' : t[k]);
          var long = v.length > 70;
          return '<div class="ka-field"><label>' + esc(k) + '</label>' +
            (long ? '<textarea class="ka-in ka-txt" data-tk="' + esc(k) + '">' + esc(v) + '</textarea>'
                  : '<input class="ka-in ka-txt" data-tk="' + esc(k) + '" value="' + esc(v) + '">') +
            '</div>';
        }).join('')
      ].join('');
    })).concat([
      extras.length ? '<h3 class="ka-sub" style="margin:22px 0 10px;color:#d4af37">Other keys</h3>' : '',
      extras.map(function (k) {
        return '<div class="ka-field"><label>' + esc(k) + '</label><input class="ka-in ka-txt" data-tk="' + esc(k) + '" value="' + esc(t[k]) + '"></div>';
      }).join('')
    ]).join('');
  }

  /* --------------------------------------------------------- publish & links */
  function renderPublish(host) {
    var g = gh();
    var customer = location.href.split('#')[0];
    var adminLink = customer + '#admin';
    var hasToken = !!lsRaw(LSK.token, '');
    var preview = previewOn();

    host.innerHTML = [
      '<h2 class="ka-h">Publish &amp; links</h2>',
      '<p class="ka-sub">Save here, then push it to the live site</p>',

      '<h3 class="ka-sub" style="margin:8px 0 10px;color:#d4af37">1 · Save on this device</h3>',
      '<div class="ka-note">Saves your edits in this browser and reloads the site so you can see them. Nothing else changes — only you see this version.',
      '  <br>Status: ' + (preview ? '<b style="color:#66d18a">preview ON</b>' : '<b>preview off</b>') +
      '  &nbsp; <button class="ka-btn sm ghost" id="kaPrevToggle">' + (preview ? 'Turn preview off' : 'Turn preview on') + '</button></div>',

      '<h3 class="ka-sub" style="margin:26px 0 10px;color:#d4af37">2 · Publish to the live site</h3>',
      '<div class="ka-2">',
      '  <div class="ka-card" style="display:block">',
      '    <div class="ka-cn">One-click publish (GitHub)</div>',
      '    <p class="ka-hint" style="margin:8px 0 10px">Paste a GitHub token once and this button writes <b>content.json</b> (and any uploaded images) straight into your repo. GitHub Pages then updates for everyone in about a minute.</p>',
      '    <div class="ka-field"><label>GitHub token (fine-grained, “Contents: Read and write”)</label>',
      '      <input class="ka-in" id="kaToken" type="password" placeholder="' + (hasToken ? '•••••••• saved' : 'github_pat_…') + '"></div>',
      '    <div class="ka-actions">',
      '      <button class="ka-btn sm" id="kaSaveToken">Save token</button>',
      '      <button class="ka-btn sm ghost" id="kaTestToken">Test</button>',
      '      <button class="ka-btn sm danger" id="kaClearToken">Forget</button>',
      '    </div>',
      '    <p class="ka-hint" style="margin-top:10px">Repository: <b>' + esc(g ? g.owner + '/' + g.repo + ' · ' + g.branch : 'not configured') + '</b></p>',
      '  </div>',
      '  <div class="ka-card" style="display:block">',
      '    <div class="ka-cn">Manual publish (no token)</div>',
      '    <p class="ka-hint" style="margin:8px 0 10px">Download <b>content.json</b>, then in your GitHub repo: <b>Add file → Upload files</b> and drop it in the root. Replace the old file.</p>',
      '    <div class="ka-actions">',
      '      <button class="ka-btn sm" id="kaDownload">Download content.json</button>',
      '      <button class="ka-btn sm dark" id="kaOpenRepo">Open my repo</button>',
      '    </div>',
      '  </div>',
      '</div>',

      '<h3 class="ka-sub" style="margin:26px 0 10px;color:#d4af37">3 · Your two links</h3>',
      '<div class="ka-field"><label>Customer link — share this</label><div class="ka-copy">',
      '  <input class="ka-in" id="kaLinkC" readonly value="' + esc(customer) + '">',
      '  <button class="ka-btn sm" data-copy="#kaLinkC">Copy</button></div></div>',
      '<div class="ka-field"><label>Admin link — keep this private</label><div class="ka-copy">',
      '  <input class="ka-in" id="kaLinkA" readonly value="' + esc(adminLink) + '">',
      '  <button class="ka-btn sm" data-copy="#kaLinkA">Copy</button></div></div>',


      '<h3 class="ka-sub" style="margin:26px 0 10px;color:#d4af37">4 · Backup &amp; safety</h3>',
      '<div class="ka-actions">',
      '  <button class="ka-btn sm dark" id="kaBackup">Download full backup (.json)</button>',
      '  <label class="ka-btn sm dark" style="cursor:pointer">Restore backup<input type="file" id="kaRestore" accept=".json,application/json" hidden></label>',
      '  <button class="ka-btn sm danger" id="kaReset">Reset to original site content</button>',
      '</div>',
      '<h3 class="ka-sub" style="margin:26px 0 10px;color:#d4af37">5 · Security</h3>',
      '<div class="ka-2">',
      '  <div class="ka-field"><label>Change admin PIN</label><input class="ka-in" id="kaNewPin" placeholder="New PIN (numbers or letters)" autocomplete="off"></div>',
      '  <div class="ka-field" style="align-self:end"><button class="ka-btn ghost" id="kaSavePin">Update PIN</button></div>',
      '</div>',
      '<p class="ka-hint">Current PIN is stored only in this browser. Default is <b>1234</b>.</p>'
    ].join('');

    $('#kaPrevToggle').addEventListener('click', function () {
      lsSet(LSK.preview, !previewOn());
      toast(previewOn() ? 'Preview on — reloading…' : 'Preview off — the live content shows again.');
      setTimeout(function () { location.reload(); }, 700);
    });
    $('#kaDownload').addEventListener('click', function () { download('content.json', JSON.stringify(exportContent(), null, 2)); });
    $('#kaOpenRepo').addEventListener('click', function () {
      if (!g) { toast('Repository is not configured.', 'err'); return; }
      window.open('https://github.com/' + g.owner + '/' + g.repo, '_blank');
    });
    $('#kaSaveToken').addEventListener('click', function () {
      var v = $('#kaToken').value.trim();
      if (!v) { toast('Paste a token first.', 'err'); return; }
      lsSet(LSK.token, v); toast('Token saved on this device.', 'ok');
    });
    $('#kaClearToken').addEventListener('click', function () { lsSet(LSK.token, ''); toast('Token removed.'); renderTab('publish'); });
    $('#kaTestToken').addEventListener('click', testToken);
    $('#kaBackup').addEventListener('click', function () { download('kinetic-backup-' + new Date().toISOString().slice(0, 10) + '.json', JSON.stringify({ app: 'kinetic', version: 1, content: collect(), pin: pinGet() }, null, 2)); });
    $('#kaRestore').addEventListener('change', function (e) {
      var f = e.target.files && e.target.files[0]; if (!f) return;
      var fr = new FileReader();
      fr.onload = function (ev) {
        try {
          var o = JSON.parse(ev.target.result);
          var c = o.content || o;
          if (!c || (!c.products && !c.texts)) throw new Error('bad');
          STATE = normalise(c);
          collect();
          saveLocal(false);
          toast('Backup restored — reloading…', 'ok');
          setTimeout(function () { location.reload(); }, 900);
        } catch (err) { toast('That is not a valid backup file.', 'err'); }
      };
      fr.readAsText(f);
    });
    $('#kaReset').addEventListener('click', function () {
      if (!confirm('Reset everything back to the original site content? Your edits on this device will be removed. (Publishing is not affected until you publish.)')) return;
      STATE = normalise(defaults());
      saveLocal(false);
      toast('Reset — reloading…');
      setTimeout(function () { location.reload(); }, 800);
    });
    $('#kaSavePin').addEventListener('click', function () {
      var v = $('#kaNewPin').value.trim();
      if (!v) { toast('Type a new PIN first.', 'err'); return; }
      lsSet(LSK.pin, v); $('#kaNewPin').value = ''; toast('PIN updated.', 'ok');
    });
    $$('[data-copy]').forEach(function (b) {
      b.addEventListener('click', function () {
        var el = $(b.getAttribute('data-copy'));
        if (!el) return;
        el.removeAttribute('readonly'); el.select(); el.setSelectionRange(0, 9999);
        var done = false;
        try { done = document.execCommand('copy'); } catch (e) {}
        el.setAttribute('readonly', 'readonly');
        if (navigator.clipboard && !done) { navigator.clipboard.writeText(el.value).then(function(){ toast('Copied.', 'ok'); }); }
        else toast(done ? 'Copied.' : 'Select and copy manually.', done ? 'ok' : 'err');
      });
    });
  }

  /* live binding: typing writes straight into the working copy */
  document.addEventListener('input', function (e) {
    if (!STATE || !e.target || !e.target.classList) return;
    var el = e.target;
    if (el.classList.contains('ka-num')) {
      var mk = el.getAttribute('data-mk');
      STATE.marketing[mk] = el.value.trim() === '' ? 0 : Number(el.value);
    } else if (el.classList.contains('ka-txt')) {
      STATE.texts[el.getAttribute('data-tk')] = el.value;
    } else if (el.id === 'kc_free' || el.id === 'kc_ship' || el.id === 'kc_code' || el.id === 'kc_pct') {
      if (!STATE.commerce) STATE.commerce = {};
      if (el.id === 'kc_free') STATE.commerce.freeShippingThresholdCents = Math.round((Number(el.value) || 0) * 100);
      if (el.id === 'kc_ship') STATE.commerce.shippingCents = Math.round((Number(el.value) || 0) * 100);
      if (el.id === 'kc_code') STATE.commerce.promoCode = el.value.trim();
      if (el.id === 'kc_pct') STATE.commerce.promoPercent = Math.max(0, Math.min(100, Number(el.value) || 0));
    } else {
      return;
    }
    autoSaveSoon();
  });

  /* ----------------------------------------------------------- auto-save */
  /* Every change is written to this device straight away, so nothing is ever
     lost by closing the browser. Publishing to the live site stays a separate,
     deliberate click. */
  var autoTimer = null;
  function autoSave() {
    if (!STATE) return;
    try {
      collect();
      lsSet(LSK.content, STATE);
      lsSet(LSK.preview, true);
      lsSet(LSK.cache, STATE);
    } catch (e) { /* nothing else to do — the in-memory copy still works */ }
    paintStatus(true);
  }
  function autoSaveSoon() {
    clearTimeout(autoTimer);
    autoTimer = setTimeout(autoSave, 450);
  }

  /* ----------------------------------------------------------- collect & save */
  function collect() {
    if (!STATE) return null;
    /* numbers */
    $$('.ka-num').forEach(function (el) {
      var k = el.getAttribute('data-mk');
      var v = el.value.trim();
      STATE.marketing[k] = v === '' ? 0 : Number(v);
    });
    /* texts */
    $$('.ka-txt').forEach(function (el) {
      var k = el.getAttribute('data-tk');
      STATE.texts[k] = el.value;
    });
    /* shop settings */
    if ($('#kc_free')) {
      STATE.commerce.freeShippingThresholdCents = Math.round((Number($('#kc_free').value) || 0) * 100);
      STATE.commerce.shippingCents = Math.round((Number($('#kc_ship').value) || 0) * 100);
      STATE.commerce.promoCode = $('#kc_code').value.trim();
      STATE.commerce.promoPercent = Math.max(0, Math.min(100, Number($('#kc_pct').value) || 0));
    }
    /* products keep their order + colour arrays tidy */
    STATE.products.forEach(function (p, i) {
      p.id = Number(p.id);
      p.ord = i;
      p.colors = (p.colorways || []).map(function (c) { return c.swatch; });
    });
    return STATE;
  }

  function exportContent() {
    collect();
    var out = clone(STATE);
    delete out.__admin;
    return out;
  }

  function saveLocal(reload) {
    if (!collect()) return;
    lsSet(LSK.content, STATE);
    lsSet(LSK.preview, true);
    lsSet(LSK.cache, STATE);
    try { window.dispatchEvent(new CustomEvent('kinetic:content-changed')); } catch (e) {}
    if (reload) { toast('Saved on this device — preview is on.', 'ok'); setTimeout(function () { location.reload(); }, 800); }
  }

  /* --------------------------------------------------------------- publishing */
  function b64(str) { return btoa(unescape(encodeURIComponent(str))); }

  async function ghPutFile(path, base64, message, token) {
    var g = gh();
    var url = g.api + '/contents/' + path.split('/').map(encodeURIComponent).join('/');
    var headers = { 'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json' };
    var sha = null;
    try {
      var r = await fetch(url + '?ref=' + encodeURIComponent(g.branch), { headers: headers });
      if (r.ok) { var j = await r.json(); sha = j.sha; }
    } catch (e) { /* new file */ }
    var body = { message: message, content: base64, branch: g.branch };
    if (sha) body.sha = sha;
    var res = await fetch(url, { method: 'PUT', headers: headers, body: JSON.stringify(body) });
    if (!res.ok) {
      var err = {};
      try { err = await res.json(); } catch (e) {}
      throw new Error(err.message || ('GitHub said ' + res.status));
    }
    return res.json();
  }

  async function testToken() {
    var token = $('#kaToken') && $('#kaToken').value.trim() || lsRaw(LSK.token, '');
    if (!token) { toast('Paste a token first.', 'err'); return; }
    var g = gh();
    try {
      var r = await fetch(g.api, { headers: { 'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json' } });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      var j = await r.json();
      toast('Token works — ' + j.full_name, 'ok');
    } catch (e) { toast('Token check failed: ' + e.message, 'err'); }
  }

  async function publishFlow() {
    var token = ($('#kaToken') && $('#kaToken').value.trim()) || lsRaw(LSK.token, '');
    if (!token) {
      toast('Add a GitHub token once, or use “Download content.json”.', 'err');
      renderTab('publish');
      return;
    }
    var g = gh();
    var btn = $('#kaPublishBtn');
    var was = btn.textContent;
    btn.disabled = true;
    try {
      /* 1. images that were uploaded in the panel (data URIs) go into assets/images/ */
      var uploaded = 0;
      var products = collect().products;
      for (var i = 0; i < products.length; i++) {
        var p = products[i];
        if (/^data:image\//.test(p.img || '')) {
          var path = 'assets/images/upload-' + Date.now() + '-' + i + '.jpg';
          btn.textContent = 'Uploading image ' + (i + 1) + '…';
          await ghPutFile(path, String(p.img).split(',')[1], 'KINETIC: add product image ' + p.name, token);
          p.img = path;
          uploaded++;
        }
      }
      /* 2. the content file itself */
      btn.textContent = 'Publishing content…';
      var payload = exportContent();
      await ghPutFile('content.json', b64(JSON.stringify(payload, null, 2)), 'KINETIC: update site content from the store manager', token);
      lsSet(LSK.content, STATE);
      lsSet(LSK.preview, false);
      toast('Published to ' + g.owner + '/' + g.repo + (uploaded ? ' (+' + uploaded + ' image' + (uploaded > 1 ? 's' : '') + ')' : '') + '. The live site updates in about a minute.', 'ok');
      toast('Tip: GitHub Pages → Actions → “pages build and deployment” shows the update.', 'ok');
    } catch (e) {
      toast('Publish failed: ' + e.message, 'err');
    } finally {
      btn.disabled = false;
      btn.textContent = was;
    }
  }

  function download(name, text) {
    try {
      var blob = new Blob([text], { type: 'application/json' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 1500);
      toast('Downloaded ' + name, 'ok');
    } catch (e) { toast('Download blocked by the browser.', 'err'); }
  }

  /* ------------------------------------------------------------------- gate */
  function pinGet() { var p = lsRaw(LSK.pin, ''); return p ? String(p).replace(/^"|"$/g, '') : DEFAULT_PIN; }
  function unlocked() { return sessionStorage.getItem('ka-unlocked') === '1'; }
  function tryUnlock() {
    var v = ($('#kaPin').value || '').trim();
    if (v === pinGet()) {
      try { sessionStorage.setItem('ka-unlocked', '1'); } catch (e) {}
      try { window.dispatchEvent(new CustomEvent('kinetic:admin-unlocked')); } catch (e) {}
      $('#kaGate').classList.remove('on');
      $('#kaPin').value = '';
      openPanel();
      toast('Welcome back, owner.', 'ok');
    } else {
      toast('That PIN is not right.', 'err');
      $('#kaPin').value = '';
      $('#kaPin').focus();
    }
  }

  function openPanel() {
    buildPanel();
    STATE = workingCopy();
    $('#kaRoot').classList.add('on');
    document.documentElement.style.overflow = 'hidden';
    renderTab(currentTab());
    paintStatus();
  }

  function paintStatus(saved) {
    var el = $('#kaStatus'); if (!el) return;
    var preview = previewOn();
    el.className = 'ka-pill' + (preview ? ' live' : '');
    var base = STATE.products.length + ' products';
    var tail = preview ? 'preview on' : 'live site';
    el.textContent = base + ' · ' + tail + (saved ? ' · saved ✓' : '');
  }

  function open() {
    buildPanel();
    if (unlocked()) { openPanel(); }
    else { $('#kaGate').classList.add('on'); setTimeout(function () { $('#kaPin').focus(); }, 60); }
  }
  function close(viewSite) {
    var root = $('#kaRoot'); if (root) root.classList.remove('on');
    $('#kaGate').classList.remove('on');
    document.documentElement.style.overflow = '';
    if (viewSite && location.hash.indexOf('admin') > -1) { location.hash = ''; }
  }

  /* -------------------------------------------------------------------- boot */
  function isAdminLink() { return /(^|[#?&])admin/i.test(location.hash || ''); }

  /* On the #admin route the modern dashboard console (assets/kinetic-admin-dash.js)
     is the front door. It shows its own PIN gate and links back to this panel from
     "Page content" whenever the raw editor is needed. If that script is missing,
     this panel opens exactly as it always did. */
  function routeAdminLink() {
    if (!isAdminLink()) return false;
    setTimeout(function () {
      var dash = window.KINETIC_ADMIN_DASH;
      if (dash && typeof dash.open === 'function') { dash.open(); return; }
      open();
    }, 0);
    return true;
  }

  /* These two MUST run synchronously, before kinetic-content.js executes:
     it calls fetch() the moment it loads. */
  installFetchPolyfill();
  installFetchOverride();

  function boot() {
    installCacheSeed();
    buildPanel();
    routeAdminLink();
    window.addEventListener('hashchange', function () {
      /* the hash stays #admin, so the dashboard router owns it from here */
      routeAdminLink();
    });
    /* expose a tiny API for power users / debugging */
    window.KINETIC_ADMIN = {
      open: open,
      close: close,
      version: BUILD,
      content: function () { return workingCopy(); },
      export: exportContent,
      save: saveLocal,
      publish: publishFlow,
      /* ---- used by the admin dashboard (assets/kinetic-admin-dash.js) ---- */
      toast: toast,
      download: download,
      /* the live working copy, so dashboard edits and the panel edit the same object.
         Never throws: a malformed content.json must not take the dashboard down. */
      state: function () {
        if (rootOpen()) { try { collect(); } catch (e) { /* keep the last good copy */ } }
        if (!STATE || typeof STATE !== 'object') { try { STATE = workingCopy(); } catch (e) { STATE = { products: [], texts: {} }; } }
        return STATE;
      },
      collect: function () { try { return collect(); } catch (e) { return STATE; } },
      saveLocal: function (reload) { saveLocal(!!reload); },
      isUnlocked: function () { return unlocked(); },
      pin: function () { return pinGet(); },
      setPin: function (value) { lsSet(LSK.pin, String(value || '')); return true; },
      refresh: function () { STATE = workingCopy(); if (rootOpen()) { renderTab(currentTab()); paintStatus(); } return true; },
      openTab: function (name) {
        buildPanel();
        if (!unlocked()) { $('#kaGate').classList.add('on'); setTimeout(function () { var f = $('#kaPin'); if (f) f.focus(); }, 60); return false; }
        openPanel();
        var btn = $('.ka-tab[data-ktab="' + name + '"]');
        if (btn) {
          $$('.ka-tab').forEach(function (x) { x.classList.toggle('on', x === btn); });
          renderTab(name);
          paintStatus();
        }
        return true;
      },
      importContent: function (cb) {
        var input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json,application/json';
        input.addEventListener('change', function () {
          var f = input.files && input.files[0];
          if (!f) { if (cb) cb(false); return; }
          var fr = new FileReader();
          fr.onload = function (ev) {
            try {
              var o = JSON.parse(ev.target.result);
              var c = o && o.content ? o.content : o;
              if (!c || (!c.products && !c.texts)) throw new Error('bad');
              STATE = normalise(c);
              saveLocal(false);
              if (cb) cb(true);
            } catch (err) { if (cb) cb(false); }
          };
          fr.onerror = function () { if (cb) cb(false); };
          fr.readAsText(f);
        });
        input.click();
      }
    };
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
})();

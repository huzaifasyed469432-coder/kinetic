/* =============================================================================
   KINETIC® — Admin Dashboard  (assets/kinetic-admin-dash.js)
   -----------------------------------------------------------------------------
   A full SaaS-style administration console for the KINETIC store.

     • Dashboard    — real sales / orders / customers / stock figures + chart
     • Orders       — statuses, payment status, search, filters, pagination
     • Products     — full CRUD, images, sizes, colours, stock, status, featured
     • Inventory    — per-size stock, low-stock and out-of-stock warnings
     • Customers    — derived from real orders (orders, spending, first seen)
     • Categories   — CRUD, feeds the product form and the shop filter bar
     • Coupons      — percent / fixed, expiry, usage limit, enable / disable
     • Content      — the page-text / numbers editor from the store manager
     • Settings     — store rules, low-stock threshold, security, publishing

   Loaded AFTER kinetic-admin.js, which owns the working copy of the site
   content and the GitHub publishing flow. This file only renders the console
   and writes through those same, already-tested code paths.

   Nothing here is exposed to customers: the console only builds its DOM after
   a successful PIN unlock, and every public method checks the session first.
   ========================================================================== */
(function () {
  'use strict';

  var BUILD = 'kinetic-admin-dash v1.0';
  var LSK = {
    content: 'kinetic-admin-content-v1',
    preview: 'kinetic-admin-preview-v1',
    cache: 'kinetic-content-cache-v1',
    pin: 'kinetic-admin-pin-v1',
    token: 'kinetic-admin-token-v1',
    orders: 'kinetic-orders-v1',
    session: 'kad-session-v1',
    throttle: 'kad-throttle-v1'
  };
  var DEFAULT_PIN = '1234';
  var ORDER_STATUSES = ['Awaiting payment', 'Pending', 'Processing', 'Packed', 'Shipped', 'Delivered', 'Cancelled', 'Refunded'];
  var PAYMENT_STATUSES = ['unpaid', 'paid', 'refunded'];
  var SIZE_FALLBACK = ['7', '7.5', '8', '8.5', '9', '9.5', '10', '10.5', '11', '12'];
  var CAT_ICONS = ['◈', '◉', '◆', '▲', '●', '■'];

  /* ------------------------------------------------------------------- utils */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function clone(o) { try { return JSON.parse(JSON.stringify(o)); } catch (e) { return null; } }
  function money(cents) {
    var n = (Number(cents) || 0) / 100;
    return '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function moneyShort(cents) {
    var n = Math.round((Number(cents) || 0) / 100);
    if (n >= 1000000) return '$' + (n / 1000000).toFixed(1) + 'M';
    if (n >= 10000) return '$' + (n / 1000).toFixed(1) + 'k';
    return '$' + n.toLocaleString('en-US');
  }
  function num(v, d) { var n = Number(v); return isFinite(n) ? n : (d || 0); }
  function int(v, d) { var n = parseInt(v, 10); return isFinite(n) ? n : (d || 0); }
  function slug(v) {
    return String(v || '').toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'item';
  }
  function dateShort(iso) {
    if (!iso) return '—';
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '—';
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  }
  function dateTime(iso) {
    if (!iso) return '—';
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '—';
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) + ' · ' +
      d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  }
  function relTime(iso) {
    if (!iso) return '—';
    var t = new Date(iso).getTime();
    if (!isFinite(t)) return '—';
    var diff = Date.now() - t;
    if (diff < 60000) return 'just now';
    var mins = Math.round(diff / 60000);
    if (mins < 60) return mins + 'm ago';
    var hours = Math.round(mins / 60);
    if (hours < 24) return hours + 'h ago';
    var days = Math.round(hours / 24);
    if (days < 30) return days + 'd ago';
    return dateShort(iso);
  }
  function dayKey(d) {
    var x = (d instanceof Date) ? d : new Date(d);
    return x.getFullYear() + '-' + ('0' + (x.getMonth() + 1)).slice(-2) + '-' + ('0' + x.getDate()).slice(-2);
  }
  function debounce(fn, ms) {
    var t = null;
    return function () {
      var args = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, args); }, ms || 220);
    };
  }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function isEmail(v) { return /^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(String(v || '').trim()); }
  function uid(n) {
    var s = '', chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    for (var i = 0; i < (n || 6); i++) s += chars.charAt(Math.floor(Math.random() * chars.length));
    return s;
  }

  /* ---------------------------------------------------------------- storage */
  var MEM = {};
  function lsGet(k, d) {
    try { var v = localStorage.getItem(k); if (v !== null) return JSON.parse(v); } catch (e) {}
    if (k in MEM) return JSON.parse(MEM[k]);
    return d;
  }
  function lsSet(k, v) {
    var ok = false;
    try { localStorage.setItem(k, JSON.stringify(v)); ok = true; } catch (e) { ok = false; }
    MEM[k] = JSON.stringify(v);
    return ok;
  }
  function lsRaw(k, d) {
    try { var v = localStorage.getItem(k); if (v !== null) return v; } catch (e) {}
    return (k in MEM) ? MEM[k] : d;
  }
  function ssGet(k, d) { try { var v = sessionStorage.getItem(k); return v === null ? d : v; } catch (e) { return k in MEM ? MEM[k] : d; } }
  function ssSet(k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} MEM[k] = v; }
  function ssDel(k) { try { sessionStorage.removeItem(k); } catch (e) {} delete MEM[k]; }

  /* ------------------------------------------------------------ bridge refs */
  function adminBridge() { return window.KINETIC_ADMIN || null; }
  function appBridge() { return window.KINETIC_APP || null; }
  function checkoutBridge() { return window.KINETIC_CHECKOUT || null; }

  function toast(message, kind) {
    /* one toast, drawn by this console only (the older panel has its own host) */
    var host = $('#kadToasts');
    if (!host) { host = document.createElement('div'); host.id = 'kadToasts'; document.body.appendChild(host); }
    var el = document.createElement('div');
    el.className = 'kad-toast' + (kind === 'err' ? ' err' : (kind === 'warn' ? ' warn' : ''));
    el.setAttribute('role', 'status');
    el.textContent = message;
    host.appendChild(el);
    setTimeout(function () {
      el.style.transition = '.25s'; el.style.opacity = '0'; el.style.transform = 'translateY(8px)';
      setTimeout(function () { el.remove(); }, 280);
    }, 3400);
  }

  /* =========================================================================
     MODEL — every view reads real data through these adapters.
     ========================================================================= */
  function state() {
    var bridge = adminBridge();
    if (bridge && typeof bridge.state === 'function') {
      var s = bridge.state();
      if (s && typeof s === 'object') return s;
    }
    if (window.__KINETIC_CONTENT__) return clone(window.__KINETIC_CONTENT__);
    if (window.__KINETIC_DEFAULTS__) return clone(window.__KINETIC_DEFAULTS__);
    return { products: [], orders: [], categories: [], coupons: [], commerce: {}, marketing: {}, texts: {} };
  }
  function editable() { var b = adminBridge(); return !!(b && typeof b.state === 'function'); }

  function productList() {
    var s = state();
    var list = Array.isArray(s.products) ? s.products : [];
    var live = appBridge();
    /* if the store has products that are not in the working copy yet, show them */
    if (live && typeof live.products === 'function') {
      try {
        live.products().forEach(function (p) {
          var found = list.some(function (x) { return String(x.id) === String(p.id); });
          if (!found) list = list.concat([p]);
        });
      } catch (e) {}
    }
    return list.map(function (p, i) { return normaliseProduct(p, i); });
  }

  function normaliseProduct(p, index) {
    p = p || {};
    var out = clone(p) || {};
    out.id = int(p.id, index);
    out.name = String(p.name || 'Untitled').trim();
    out.cat = String(p.cat || 'Running').trim();
    out.tag = String(p.tag || '').trim();
    out.desc = String(p.desc || '');
    out.img = String(p.img || '');
    out.price = num(p.price, 0);
    out.old = (p.old === null || p.old === undefined || p.old === '') ? null : num(p.old, 0);
    out.rating = Math.max(0, Math.min(5, num(p.rating, 0)));
    out.reviews = int(p.reviews, 0);
    out.sku = String(p.sku || '').trim();
    out.status = String(p.status || 'active').toLowerCase() === 'draft' ? 'draft' : 'active';
    out.featured = !!p.featured;
    out.sizes = Array.isArray(p.sizes) && p.sizes.length ? p.sizes.map(String) : SIZE_FALLBACK.slice();
    out.stock = (p.stock && typeof p.stock === 'object' && !Array.isArray(p.stock)) ? p.stock : null;
    out.stockCap = (typeof p.stock === 'number' && isFinite(p.stock)) ? p.stock : null;
    out.colorways = (Array.isArray(p.colorways) && p.colorways.length ? p.colorways : [])
      .filter(function (c) { return c && /^#[0-9a-f]{6}$/i.test(String(c.swatch || c.hex || '')); })
      .map(function (c, k) { return { name: String(c.name || ('Colourway ' + (k + 1))).trim(), swatch: String(c.swatch || c.hex).toUpperCase() }; });
    if (!out.colorways.length && Array.isArray(p.colors)) {
      out.colorways = p.colors.filter(function (c) { return /^#[0-9a-f]{6}$/i.test(String(c)); })
        .map(function (c, k) { return { name: 'Colourway ' + (k + 1), swatch: String(c).toUpperCase() }; });
    }
    out.colors = out.colorways.map(function (c) { return c.swatch; });
    out.ord = int(p.ord, index);
    return out;
  }

  function skuFor(p, size, colourName) {
    if (p.sku && !size) return p.sku;
    var base = p.sku || ('KNT-' + ('00' + (int(p.id, 0) + 1)).slice(-3));
    return base;
  }
  function productSku(p) {
    if (String(p.sku || '').trim()) return String(p.sku).toUpperCase();
    return 'KNT-' + ('00' + (int(p.id, 0) + 1)).slice(-3);
  }

  /* ---- stock: mirrors the storefront rule (explicit map → cap → store bucket) */
  var STOCK_SEED = null;
  function stockSeed(text) {
    /* FNV-1a — same maths as the storefront so the numbers agree exactly */
    var h = 0x811c9dc5, s = String(text);
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = (h * 0x01000193) >>> 0; }
    return h >>> 0;
  }
  function stockFor(p, size) {
    if (!p) return 0;
    var key = String(size == null ? '' : size).trim();
    if (!key) return 0;
    var table = p.stock;
    if (table) {
      if (Object.prototype.hasOwnProperty.call(table, key)) { var v = parseInt(table[key], 10); return isFinite(v) && v > 0 ? v : 0; }
      if (Object.prototype.hasOwnProperty.call(table, '*')) { var d = parseInt(table['*'], 10); return isFinite(d) && d > 0 ? d : 0; }
    }
    if (p.stockCap === 0) return 0;
    var limited = String(p.tag || '').toLowerCase() === 'limited' || !!p.editionSize;
    var roll = stockSeed(String(p.id) + '|' + key) % 100;
    if (p.stockCap !== null) return Math.min(p.stockCap, 9);
    if (limited) { if (roll < 32) return 0; if (roll < 62) return 1 + (roll % 2); if (roll < 88) return 3 + (roll % 3); return 6 + (roll % 3); }
    if (roll < 14) return 0;
    if (roll < 44) return 1 + (roll % 2);
    if (roll < 78) return 3 + (roll % 4);
    return 7 + (roll % 3);
  }
  function stockRows(p) {
    return p.sizes.map(function (size) { return { size: String(size), qty: stockFor(p, size) }; });
  }
  function stockTotal(p) { return stockRows(p).reduce(function (a, r) { return a + r.qty; }, 0); }
  function manualStock(p) { return !!p.stock; }

  function settings() {
    var s = state();
    var st = (s && s.settings && typeof s.settings === 'object') ? s.settings : {};
    return {
      lowStockThreshold: int(st.lowStockThreshold, 3),
      ordersPerPage: int(st.ordersPerPage, 10) || 10,
      sessionMinutes: int(st.sessionMinutes, 45) || 45,
      ordersEndpoint: String(st.ordersEndpoint || ''),
      autoReload: st.autoReload === true
    };
  }
  function saveSettings(patch) {
    var bridge = adminBridge();
    if (!editable()) return false;
    var s = state();
    s.settings = Object.assign({}, s.settings || {}, patch || {});
    return commit('Settings saved');
  }

  function categoryList() {
    var s = state();
    var list = Array.isArray(s.categories) ? s.categories : [];
    if (!list.length) {
      /* first run: seed from the categories the products already use */
      var seen = {};
      productList().forEach(function (p) { if (p.cat) seen[p.cat] = true; });
      list = Object.keys(seen).sort().map(function (name, i) {
        return { id: slug(name), name: name, description: '', order: i, status: 'active' };
      });
    }
    return list.map(function (c, i) {
      return {
        id: String(c.id || slug(c.name) || ('cat-' + i)),
        name: String(c.name || 'Category').trim(),
        description: String(c.description || ''),
        order: int(c.order, i),
        status: String(c.status || 'active').toLowerCase() === 'hidden' ? 'hidden' : 'active'
      };
    }).sort(function (a, b) { return a.order - b.order; });
  }

  function couponList() {
    var s = state();
    var list = Array.isArray(s.coupons) ? s.coupons : [];
    var used = couponUsage();
    return list.map(function (c, i) {
      var code = String(c.code || '').trim().toUpperCase();
      return {
        index: i,
        code: code,
        type: String(c.type || 'percent').toLowerCase() === 'fixed' ? 'fixed' : 'percent',
        value: num(c.value, 0),
        minSubtotalCents: int(c.minSubtotalCents, 0),
        expiresAt: String(c.expiresAt || ''),
        usageLimit: int(c.usageLimit, 0),
        status: String(c.status || 'active').toLowerCase() === 'disabled' ? 'disabled' : 'active',
        note: String(c.note || ''),
        used: used[code] || 0
      };
    });
  }
  function couponUsage() {
    var out = {};
    orderList().forEach(function (o) {
      if (!o.promo) return;
      if (o.status === 'Cancelled') return;
      var code = String(o.promo).toUpperCase();
      out[code] = (out[code] || 0) + 1;
    });
    return out;
  }
  function couponState(c) {
    if (!c) return { ok: false, reason: 'Unknown code.' };
    if (c.status !== 'active') return { ok: false, reason: 'This code is switched off.' };
    if (c.expiresAt) {
      var end = new Date(c.expiresAt + 'T23:59:59');
      if (!isNaN(end.getTime()) && end.getTime() < Date.now()) return { ok: false, reason: 'This code expired on ' + dateShort(c.expiresAt) + '.' };
    }
    if (c.usageLimit > 0 && c.used >= c.usageLimit) return { ok: false, reason: 'This code has reached its usage limit.' };
    return { ok: true, reason: '' };
  }

  /* ---- orders */
  function orderList() {
    var raw = lsGet(LSK.orders, []);
    var list = Array.isArray(raw) ? raw : [];
    var bridge = checkoutBridge();
    if (!list.length && bridge && typeof bridge.orders === 'function') {
      try { list = bridge.orders() || []; } catch (e) { list = []; }
    }
    return list.map(normaliseOrder).filter(Boolean);
  }
  function normaliseOrder(o) {
    if (!o || typeof o !== 'object') return null;
    var out = clone(o);
    out.items = Array.isArray(o.items) ? o.items : [];
    out.customer = Object.assign({ name: '', email: '', phone: '', address: '', city: '', country: '' }, o.customer || {});
    out.status = String(o.status || 'Pending');
    out.paymentStatus = String(o.paymentStatus || 'unpaid').toLowerCase();
    out.timeline = Array.isArray(o.timeline) ? o.timeline : [];
    out.totalCents = int(o.totalCents, 0);
    out.subtotalCents = int(o.subtotalCents, out.totalCents);
    out.discountCents = int(o.discountCents, 0);
    out.shippingCents = int(o.shippingCents, 0);
    out.promo = String(o.promo || '').toUpperCase();
    out.notes = String(o.notes || '');
    return out;
  }
  function writeOrders(list) {
    lsSet(LSK.orders, list);
    var bridge = checkoutBridge();
    if (bridge && typeof bridge.reload === 'function') { try { bridge.reload(); } catch (e) {} }
  }
  function updateOrder(number, patch, timelineLabel) {
    var list = orderList();
    var found = null;
    for (var i = 0; i < list.length; i++) {
      if (String(list[i].number) !== String(number)) continue;
      found = list[i];
      Object.keys(patch).forEach(function (k) { found[k] = patch[k]; });
      if (timelineLabel) {
        found.timeline = (found.timeline || []).concat([{ at: new Date().toISOString(), label: timelineLabel }]);
      }
    }
    if (!found) return false;
    writeOrders(list);
    return true;
  }
  function orderRevenue(list) {
    return (list || orderList()).reduce(function (sum, o) {
      if (o.status === 'Cancelled') return sum;
      return sum + (o.status === 'Refunded' ? 0 : o.totalCents);
    }, 0);
  }
  function isComplete(o) { return o.status === 'Delivered'; }
  function isPending(o) { return ['Awaiting payment', 'Pending', 'Processing', 'Packed'].indexOf(o.status) > -1; }

  /* ---- customers, derived from real orders */
  function customerList() {
    var map = {};
    orderList().forEach(function (o) {
      var c = o.customer || {};
      var key = (c.email ? String(c.email).toLowerCase().trim() : '') || (c.phone ? String(c.phone).replace(/\D/g, '') : '') || ('guest-' + slug(c.name));
      if (!map[key]) {
        map[key] = {
          key: key, name: c.name || 'Guest customer', email: c.email || '', phone: c.phone || '',
          city: c.city || '', country: c.country || '', orders: [], spentCents: 0, firstAt: o.placedAt, lastAt: o.placedAt
        };
      }
      var entry = map[key];
      entry.orders.push(o.number);
      if (o.status !== 'Cancelled' && o.status !== 'Refunded') entry.spentCents += o.totalCents;
      if (o.customer && o.customer.name) entry.name = o.customer.name;
      if (!isNaN(new Date(o.placedAt).getTime())) {
        if (!entry.firstAt || new Date(o.placedAt) < new Date(entry.firstAt)) entry.firstAt = o.placedAt;
        if (!entry.lastAt || new Date(o.placedAt) > new Date(entry.lastAt)) entry.lastAt = o.placedAt;
      }
    });
    return Object.keys(map).map(function (k) {
      var c = map[k];
      c.orderCount = c.orders.length;
      c.aovCents = c.orderCount ? Math.round(c.spentCents / c.orderCount) : 0;
      return c;
    }).sort(function (a, b) { return new Date(b.lastAt || 0) - new Date(a.lastAt || 0); });
  }
  function customerOrders(customer) {
    if (!customer) return [];
    var set = {};
    (customer.orders || []).forEach(function (n) { set[String(n)] = true; });
    return orderList().filter(function (o) { return set[String(o.number)]; });
  }

  /* ---- dashboard metrics */
  function metrics() {
    var orders = orderList();
    var products = productList();
    var customers = customerList();
    var revenue = orderRevenue(orders);
    var paid = orders.filter(function (o) { return o.paymentStatus === 'paid'; });
    var auth = orders.filter(function (o) { return o.status !== 'Cancelled' && o.status !== 'Refunded'; });
    var soldUnits = 0;
    orders.forEach(function (o) {
      if (o.status === 'Cancelled' || o.status === 'Refunded') return;
      o.items.forEach(function (it) { soldUnits += int(it.qty, 0); });
    });
    var low = [], out = [];
    products.forEach(function (p) {
      var rows = stockRows(p);
      var live = rows.filter(function (r) { return r.qty > 0; });
      var zero = rows.filter(function (r) { return r.qty === 0; });
      if (!live.length) out.push(p);
      else if (live.some(function (r) { return r.qty <= settings().lowStockThreshold; })) low.push(p);
      if (zero.length) p.outSizes = zero.length;
    });
    var today = dayKey(new Date());
    var revenueToday = orders.filter(function (o) { return o.placedAt && dayKey(o.placedAt) === today && o.status !== 'Cancelled' && o.status !== 'Refunded'; })
      .reduce(function (s, o) { return s + o.totalCents; }, 0);
    var weekAgo = Date.now() - 7 * 864e5, monthAgo = Date.now() - 30 * 864e5;
    function windowRevenue(from) {
      return orders.filter(function (o) {
        var t = new Date(o.placedAt).getTime();
        return isFinite(t) && t >= from && o.status !== 'Cancelled' && o.status !== 'Refunded';
      }).reduce(function (s, o) { return s + o.totalCents; }, 0);
    }
    return {
      orders: orders, products: products, customers: customers,
      revenueCents: revenue, revenueToday: revenueToday,
      revenue7: windowRevenue(weekAgo), revenue30: windowRevenue(monthAgo),
      aovCents: auth.length ? Math.round(revenue / auth.length) : 0,
      authCount: auth.length,
      pending: orders.filter(isPending),
      completed: orders.filter(isComplete),
      cancelled: orders.filter(function (o) { return o.status === 'Cancelled' || o.status === 'Refunded'; }),
      unpaid: orders.filter(function (o) { return o.paymentStatus !== 'paid' && o.status !== 'Cancelled'; }),
      soldUnits: soldUnits,
      lowStock: low, outOfStock: out,
      drafts: products.filter(function (p) { return p.status === 'draft'; }),
      featured: products.filter(function (p) { return p.featured; })
    };
  }

  function revenueSeries(days) {
    var n = days || 14;
    var orders = orderList();
    var buckets = {};
    var today = new Date(); today.setHours(0, 0, 0, 0);
    var out = [];
    for (var i = n - 1; i >= 0; i--) {
      var d = new Date(today.getTime() - i * 864e5);
      var key = dayKey(d);
      buckets[key] = { key: key, date: d, cents: 0, orders: 0 };
    }
    orders.forEach(function (o) {
      if (o.status === 'Cancelled' || o.status === 'Refunded') return;
      var k = o.placedAt ? dayKey(o.placedAt) : '';
      if (!buckets[k]) return;
      buckets[k].cents += o.totalCents;
      buckets[k].orders += 1;
    });
    Object.keys(buckets).forEach(function (k) { out.push(buckets[k]); });
    out.sort(function (a, b) { return a.date - b.date; });
    return out;
  }
  function topProducts(limit) {
    var map = {};
    orderList().forEach(function (o) {
      if (o.status === 'Cancelled' || o.status === 'Refunded') return;
      o.items.forEach(function (it) {
        var key = String(it.id);
        if (!map[key]) map[key] = { id: it.id, name: it.name, img: it.img, qty: 0, cents: 0 };
        map[key].qty += int(it.qty, 0);
        map[key].cents += int(it.lineCents, 0) || (int(it.unitCents, 0) * int(it.qty, 0));
      });
    });
    return Object.keys(map).map(function (k) { return map[k]; })
      .sort(function (a, b) { return b.cents - a.cents; })
      .slice(0, limit || 5);
  }

  /* ------------------------------------------------------------ commit / io */
  function commit(message) {
    var bridge = adminBridge();
    if (!bridge || typeof bridge.saveLocal !== 'function') {
      toast('Demo mode — the store manager is not loaded, nothing was saved.', 'err');
      return false;
    }
    var s = state();
    /* let the storefront see the change without a manual refresh */
    try { window.__KINETIC_CONTENT__ = s; } catch (e) {}
    try { bridge.saveLocal(false); } catch (e) {}
    var applied = false;
    var app = appBridge();
    if (app && typeof app.reloadContent === 'function') {
      try { applied = app.reloadContent() !== false; } catch (e) { applied = false; }
    }
    if (message) toast(message + (applied ? ' · preview updated' : ''), 'ok');
    if (settings().autoReload && !applied) setTimeout(function () { location.reload(); }, 700);
    return true;
  }

  function exportOrdersCsv() {
    var rows = [['Order', 'Date', 'Status', 'Payment', 'Customer', 'Email', 'Phone', 'City', 'Country', 'Items', 'Subtotal', 'Discount', 'Shipping', 'Total', 'Promo']];
    orderList().forEach(function (o) {
      rows.push([
        o.number, o.placedAt || '', o.status, o.paymentStatus, o.customer.name, o.customer.email, o.customer.phone,
        o.customer.city, o.customer.country,
        o.items.map(function (it) { return it.name + ' ×' + it.qty + ' (US ' + (it.size || '-') + ')'; }).join(' | '),
        (o.subtotalCents / 100).toFixed(2), (o.discountCents / 100).toFixed(2), (o.shippingCents / 100).toFixed(2),
        (o.totalCents / 100).toFixed(2), o.promo || ''
      ]);
    });
    var csv = rows.map(function (r) {
      return r.map(function (cell) { return '"' + String(cell == null ? '' : cell).replace(/"/g, '""') + '"'; }).join(',');
    }).join('\n');
    var bridge = adminBridge();
    if (bridge && typeof bridge.download === 'function') { bridge.download('kinetic-orders-' + dayKey(new Date()) + '.csv', csv); return true; }
    toast('Download is unavailable in this browser.', 'err');
    return false;
  }
  function exportCustomersCsv() {
    var rows = [['Customer', 'Email', 'Phone', 'City', 'Country', 'Orders', 'Total spent', 'Average order', 'First order', 'Last order']];
    customerList().forEach(function (c) {
      rows.push([c.name, c.email, c.phone, c.city, c.country, c.orderCount, (c.spentCents / 100).toFixed(2), (c.aovCents / 100).toFixed(2), c.firstAt || '', c.lastAt || '']);
    });
    var csv = rows.map(function (r) { return r.map(function (cell) { return '"' + String(cell == null ? '' : cell).replace(/"/g, '""') + '"'; }).join(','); }).join('\n');
    var bridge = adminBridge();
    if (bridge && typeof bridge.download === 'function') { bridge.download('kinetic-customers-' + dayKey(new Date()) + '.csv', csv); return true; }
    toast('Download is unavailable in this browser.', 'err');
    return false;
  }

  /* =========================================================================
     AUTH — session, throttling, route protection
     ========================================================================= */
  var SESSION_IDLE_MS = 45 * 60 * 1000;
  function pinGet() {
    var raw = lsRaw(LSK.pin, '');
    if (!raw) return DEFAULT_PIN;
    return String(raw).replace(/^"|"$/g, '');
  }
  function sessionRead() {
    var s = lsGet(LSK.session, null);
    if (!s || typeof s !== 'object') s = null;
    if (!s) {
      /* the store manager's own session also counts as an admin session */
      var legacy = ssGet('ka-unlocked', '');
      if (legacy === '1') s = { at: Date.now(), exp: Date.now() + SESSION_IDLE_MS, legacy: true };
    }
    return s;
  }
  function sessionActive() {
    var s = sessionRead();
    if (!s) return false;
    if (typeof s.exp === 'number' && s.exp < Date.now()) { sessionClear(); return false; }
    return true;
  }
  function sessionTouch() {
    var s = sessionRead();
    if (!s) return;
    s.exp = Date.now() + settings().sessionMinutes * 60 * 1000;
    lsSet(LSK.session, s);
    ssSet('ka-unlocked', '1');
  }
  function sessionStart() {
    lsSet(LSK.session, { at: Date.now(), exp: Date.now() + settings().sessionMinutes * 60 * 1000, id: uid(8) });
    ssSet('ka-unlocked', '1');
  }
  function sessionClear() {
    lsSet(LSK.session, null);
    try { lsDel(LSK.session); } catch (e) {}
    ssDel('ka-unlocked');
  }
  function lsDel(k) { try { localStorage.removeItem(k); } catch (e) {} delete MEM[k]; }

  function throttleRead() {
    var t = lsGet(LSK.throttle, null);
    if (!t || typeof t !== 'object') return { fails: 0, until: 0 };
    return { fails: int(t.fails, 0), until: int(t.until, 0) };
  }
  function throttleFail() {
    var t = throttleRead();
    t.fails += 1;
    if (t.fails >= 5) {
      var steps = Math.min(4, Math.floor((t.fails - 5) / 2) + 1);
      t.until = Date.now() + [60000, 300000, 900000, 900000][steps - 1];
    }
    lsSet(LSK.throttle, t);
    return t;
  }
  function throttleClear() { lsSet(LSK.throttle, { fails: 0, until: 0 }); }
  function throttleWaitMs() {
    var t = throttleRead();
    return t.until > Date.now() ? t.until - Date.now() : 0;
  }

  /* =========================================================================  CSS */
  /* Dashboard styles live in assets/kinetic-admin-dash.css */
  var CSS = '';

  /* =========================================================================  shell */
  function shellMarkup() {
    return [
      '<div id="kadScrim"></div>',
      '<div id="kadShell">',
      '  <aside id="kadSide">',
      '    <div class="kad-brand"><div><div class="mark">KINETIC<sup>®</sup></div><div class="sub">Admin console</div></div></div>',
      '    <nav class="kad-nav" id="kadNav"></nav>',
      '    <div class="kad-sidefoot">',
      '      <div class="kad-whost" id="kadWho">—</div>',
      '      <div style="display:flex;gap:8px">',
      '        <button class="kad-pillbtn ghost" id="kadViewSite" style="flex:1;justify-content:center">View site</button>',
      '        <button class="kad-pillbtn danger" id="kadLockNow" title="Sign out of the console">Lock</button>',
      '      </div>',
      '    </div>',
      '  </aside>',
      '  <div id="kadMainCol">',
      '    <header id="kadTop">',
      '      <button id="kadBurger" aria-label="Toggle navigation">☰</button>',
      '      <div class="kad-pagehead"><div class="kad-crumb" id="kadCrumb">KINETIC / admin</div><h1 class="kad-title" id="kadTitle">Dashboard</h1></div>',
      '      <label class="kad-search" for="kadGlobalSearch"><span>⌕</span><input id="kadGlobalSearch" type="search" placeholder="Search products, orders, customers…" autocomplete="off"></label>',
      '      <div class="kad-topactions" id="kadTopActions"></div>',
      '      <div class="kad-avatar" id="kadAvatar" title="Signed in as owner">KA</div>',
      '    </header>',
      '    <main id="kadPage" tabindex="-1"><div class="kad-wrap" id="kadWrap"></div></main>',
      '  </div>',
      '</div>',
      '<div class="kad-overlay" id="kadOverlay"></div>',
      '<div class="kad-drawer" id="kadDrawer" role="dialog" aria-modal="true" aria-hidden="true">',
      '  <div class="kad-dhead"><div class="t"><div class="k" id="kadDrawerKick"></div><h2 id="kadDrawerTitle"></h2></div><button class="kad-dclose" id="kadDrawerClose" aria-label="Close panel">✕</button></div>',
      '  <div class="kad-dbody" id="kadDrawerBody"></div>',
      '  <div class="kad-dfoot" id="kadDrawerFoot"></div>',
      '</div>',
      '<div class="kad-modal" id="kadModal" role="dialog" aria-modal="true" aria-hidden="true">',
      '  <div class="kad-mbox"><div class="h"><h3 id="kadModalTitle">Confirm</h3><button class="kad-dclose" id="kadModalX" aria-label="Close">✕</button></div>',
      '  <div class="b" id="kadModalBody"></div><div class="f" id="kadModalFoot"></div></div>',
      '</div>',
      '<div id="kadToasts"></div>'
    ].join('\n');
  }
  function lockMarkup() {
    return [
      '<div class="kad-lockbox">',
      '  <div class="mark">KINETIC<sup>®</sup></div>',
      '  <div class="k">Admin dashboard · owner access</div>',
      '  <p>This console manages products, orders, customers, inventory and coupons. It is not shown to customers — enter your PIN to continue.</p>',
      '  <label class="kad-label" for="kadPin">PIN</label>',
      '  <input id="kadPin" type="password" inputmode="numeric" maxlength="12" autocomplete="off" aria-describedby="kadLockErr" placeholder="••••">',
      '  <div class="kad-lockerr" id="kadLockErr" role="alert"></div>',
      '  <div class="kad-lockrow"><button class="kad-btn" id="kadUnlock" style="flex:1">Unlock dashboard</button><button class="kad-btn ghost" id="kadLockShop">Back to shop</button></div>',
      '  <div class="kad-lockfoot">Owner access only. Sessions lock themselves when the console is left idle.<br>Forgot the PIN? Clear this site\'s browsing data to return to the factory default.</div>',
      '</div>'
    ].join('\n');
  }

  var NAV = [
    { group: 'Overview' },
    { id: 'dashboard', label: 'Dashboard', icon: '◧' },
    { id: 'orders', label: 'Orders', icon: '❑', badge: function (m) { return m.pending.length ? String(m.pending.length) : ''; }, badgeKind: 'warn' },
    { id: 'products', label: 'Products', icon: '◈' },
    { id: 'inventory', label: 'Inventory', icon: '▤', badge: function (m) { return (m.lowStock.length + m.outOfStock.length) ? String(m.lowStock.length + m.outOfStock.length) : ''; }, badgeKind: 'bad' },
    { group: 'People' },
    { id: 'customers', label: 'Customers', icon: '☺' },
    { group: 'Store' },
    { id: 'categories', label: 'Categories', icon: '◆' },
    { id: 'coupons', label: 'Coupons', icon: '％' },
    { id: 'content', label: 'Page content', icon: '✎' },
    { id: 'settings', label: 'Settings', icon: '⚙' }
  ];

  function navMarkup(active, m) {
    var out = '';
    NAV.forEach(function (item) {
      if (item.group) { out += '<div class="kad-navgroup">' + esc(item.group) + '</div>'; return; }
      var badge = '';
      if (item.badge) {
        var v = '';
        try { v = item.badge(m) || ''; } catch (e) { v = ''; }
        if (v) badge = '<span class="badge ' + (item.badgeKind || '') + '">' + esc(v) + '</span>';
      }
      out += '<button type="button" class="kad-navitem' + (active === item.id ? ' on' : '') + '" data-nav="' + item.id + '">' +
        '<span class="ic" aria-hidden="true">' + item.icon + '</span><span>' + esc(item.label) + '</span>' + badge + '</button>';
    });
    return out;
  }

  /* =========================================================================  UI kit */
  function emptyState(title, body, actions) {
    return '<div class="kad-empty"><div class="big">' + esc(title) + '</div><p>' + body + '</p>' +
      (actions ? '<div class="acts">' + actions + '</div>' : '') + '</div>';
  }
  function errorState(title, body, retryId) {
    return '<div class="kad-empty" style="border-color:rgba(255,128,128,.4);background:rgba(255,128,128,.05)">' +
      '<div class="big" style="color:#ff8080">' + esc(title) + '</div><p>' + esc(body) + '</p>' +
      (retryId ? '<div class="acts"><button class="kad-btn ghost" id="' + retryId + '">Try again</button></div>' : '') + '</div>';
  }
  function skeletonRows(n) {
    var out = '<div class="kad-skel" style="height:38px;margin-bottom:12px;max-width:340px"></div>';
    for (var i = 0; i < (n || 5); i++) out += '<div class="kad-skel kad-skelrow"></div>';
    return out;
  }
  function chip(text, kind) {
    return '<span class="kad-chip ' + (kind || '') + '">' + esc(text) + '</span>';
  }
  function orderChip(status) {
    var map = {
      'Awaiting payment': 'amber', 'Pending': 'amber', 'Processing': 'blue', 'Packed': 'blue',
      'Shipped': 'gold', 'Delivered': 'green', 'Cancelled': 'red', 'Refunded': 'mut'
    };
    return chip(status || 'Pending', map[status] || 'mut');
  }
  function paymentChip(status) {
    var s = String(status || 'unpaid').toLowerCase();
    if (s === 'paid') return chip('Paid', 'green');
    if (s === 'refunded') return chip('Refunded', 'mut');
    return chip('Unpaid', 'amber');
  }

  var confirmResolver = null;
  function confirmDialog(opts) {
    opts = opts || {};
    var modal = $('#kadModal');
    $('#kadModalTitle').textContent = opts.title || 'Are you sure?';
    $('#kadModalBody').innerHTML = opts.body || '';
    $('#kadModalFoot').innerHTML =
      '<button class="kad-btn ghost" id="kadModalCancel">' + esc(opts.cancel || 'Cancel') + '</button>' +
      '<button class="kad-btn ' + (opts.danger ? 'danger' : '') + '" id="kadModalOk">' + esc(opts.ok || 'Confirm') + '</button>';
    modal.classList.add('on');
    modal.setAttribute('aria-hidden', 'false');
    var done = function (value) {
      modal.classList.remove('on');
      modal.setAttribute('aria-hidden', 'true');
      if (confirmResolver) { var r = confirmResolver; confirmResolver = null; r(value); }
    };
    $('#kadModalOk').addEventListener('click', function () { done(true); });
    $('#kadModalCancel').addEventListener('click', function () { done(false); });
    $('#kadModalX').addEventListener('click', function () { done(false); });
    modal.addEventListener('click', function (e) { if (e.target === modal) done(false); });
    setTimeout(function () { var b = $('#kadModalOk'); if (b) b.focus(); }, 40);
    return new Promise(function (resolve) { confirmResolver = resolve; });
  }

  var drawerState = { onClose: null };
  function openDrawer(opts) {
    opts = opts || {};
    $('#kadDrawerKick').textContent = opts.kicker || '';
    $('#kadDrawerTitle').textContent = opts.title || '';
    $('#kadDrawerBody').innerHTML = opts.body || '';
    $('#kadDrawerFoot').innerHTML = opts.footer || '';
    $('#kadOverlay').classList.add('on');
    var d = $('#kadDrawer');
    d.classList.add('on');
    d.setAttribute('aria-hidden', 'false');
    drawerState.onClose = opts.onClose || null;
    document.documentElement.style.overflow = 'hidden';
    setTimeout(function () { var f = $('#kadDrawerBody .kad-in, #kadDrawerBody button'); if (f && opts.focus !== false) { try { f.focus(); } catch (e) {} } }, 60);
  }
  function closeDrawer() {
    /* safe to call before the console exists (a customer never builds it) */
    var d = $('#kadDrawer');
    if (d) { d.classList.remove('on'); d.setAttribute('aria-hidden', 'true'); }
    var o = $('#kadOverlay');
    if (o) o.classList.remove('on');
    document.documentElement.style.overflow = '';
    var cb = drawerState.onClose; drawerState.onClose = null;
    if (typeof cb === 'function') { try { cb(); } catch (e) {} }
  }

  function tableCell(label, value, cls) {
    return '<td data-label="' + esc(label) + '"' + (cls ? ' class="' + cls + '"' : '') + '>' + value + '</td>';
  }
  function paginate(list, page, per) {
    var total = list.length;
    var pages = Math.max(1, Math.ceil(total / per));
    var current = Math.min(Math.max(1, page), pages);
    var start = (current - 1) * per;
    return { rows: list.slice(start, start + per), page: current, pages: pages, total: total, from: total ? start + 1 : 0, to: Math.min(total, start + per) };
  }
  function pagerMarkup(pg, extra) {
    if (!pg.total) return '';
    var out = '<div class="kad-pager"><span>Showing ' + pg.from + '–' + pg.to + ' of ' + pg.total + '</span>' +
      '<span class="spacer" style="flex:1"></span>' +
      '<button class="pg" data-page="' + (pg.page - 1) + '"' + (pg.page <= 1 ? ' disabled' : '') + '>‹</button>';
    var from = Math.max(1, pg.page - 2), to = Math.min(pg.pages, from + 4);
    from = Math.max(1, Math.min(from, to - 4));
    for (var i = from; i <= to; i++) {
      out += '<button class="pg' + (i === pg.page ? ' on' : '') + '" data-page="' + i + '">' + i + '</button>';
    }
    out += '<button class="pg" data-page="' + (pg.page + 1) + '"' + (pg.page >= pg.pages ? ' disabled' : '') + '>›</button>' +
      (extra || '') + '</div>';
    return out;
  }
  function bars(list, pick) {
    /* tiny inline bar chart used inside tables */
    var max = list.reduce(function (m, x) { return Math.max(m, pick(x)); }, 0) || 1;
    return '<div class="kad-bar"><i style="width:' + Math.round((pick(list[0]) / max) * 100) + '%"></i></div>';
  }

  /* =========================================================================  router */
  var route = { name: 'dashboard', arg: '' };
  function parseHash() {
    var raw = String(location.hash || '').replace(/^#/, '');
    if (!/^admin/i.test(raw)) return null;
    var parts = raw.split('/').filter(function (s, i) { return i > 0 && s !== ''; });
    var name = (parts[0] || 'dashboard').toLowerCase();
    var known = ['dashboard', 'orders', 'products', 'inventory', 'customers', 'categories', 'coupons', 'content', 'settings', 'publish'];
    if (name === 'publish') name = 'content';            /* the publish panel lives in the content hub */
    if (known.indexOf(name) === -1) name = 'dashboard';
    return { name: name, arg: decodeURIComponent(parts[1] || '') };
  }
  function go(name, arg) {
    var hash = '#admin' + (name && name !== 'dashboard' ? '/' + name : '') + (arg ? '/' + encodeURIComponent(arg) : '');
    if (location.hash === hash) render();
    else location.hash = hash;
  }
  function refreshNavMetrics() {
    var m = metrics();
    var nav = $('#kadNav');
    if (nav) nav.innerHTML = navMarkup(route.name, m);
    return m;
  }

  /* =========================================================================  topbar actions */
  function topActionsFor(name) {
    var out = '';
    if (name === 'orders') {
      out += '<button class="kad-pillbtn" data-act="orders-export">Export CSV</button>';
      out += '<button class="kad-pillbtn ghost" data-act="orders-import">Import orders</button>';
    }
    if (name === 'products') out += '<button class="kad-pillbtn primary" data-act="product-new">+ Add product</button>';
    if (name === 'inventory') out += '<button class="kad-pillbtn" data-act="stock-restock">Restock low sizes</button>';
    if (name === 'customers') out += '<button class="kad-pillbtn" data-act="customers-export">Export CSV</button>';
    if (name === 'categories') out += '<button class="kad-pillbtn primary" data-act="cat-new">+ New category</button>';
    if (name === 'coupons') out += '<button class="kad-pillbtn primary" data-act="coupon-new">+ New coupon</button>';
    out += '<button class="kad-pillbtn ghost" data-act="publish">Publish live</button>';
    return out;
  }

  /* =========================================================================  DASHBOARD */
  function chartSvg(series) {
    var w = 900, h = 230, padL = 52, padR = 12, padT = 14, padB = 30;
    var max = series.reduce(function (m, d) { return Math.max(m, d.cents); }, 0);
    if (!max) max = 10000;
    var innerW = w - padL - padR, innerH = h - padT - padB;
    var step = innerW / series.length;
    var barW = Math.max(6, step * 0.55);
    var out = '<svg class="kad-chart" viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="none" role="img" aria-label="Revenue for the last ' + series.length + ' days">';
    /* gridlines */
    for (var g = 0; g <= 4; g++) {
      var y = padT + (innerH / 4) * g;
      var value = max - (max / 4) * g;
      out += '<line class="grid" x1="' + padL + '" y1="' + y.toFixed(1) + '" x2="' + (w - padR) + '" y2="' + y.toFixed(1) + '"></line>';
      out += '<text class="lbl" x="' + (padL - 8) + '" y="' + (y + 3).toFixed(1) + '" text-anchor="end">' + esc(moneyShort(value).replace('$', '$')) + '</text>';
    }
    out += '<line class="axis" x1="' + padL + '" y1="' + (h - padB) + '" x2="' + (w - padR) + '" y2="' + (h - padB) + '"></line>';
    series.forEach(function (d, i) {
      var bh = max ? (d.cents / max) * innerH : 0;
      var x = padL + step * i + (step - barW) / 2;
      var y = padT + innerH - bh;
      out += '<rect class="bar' + (d.cents ? '' : ' zero') + '" x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + barW.toFixed(1) + '" height="' + Math.max(2, bh).toFixed(1) + '">' +
        '<title>' + esc(dateShort(d.date) + ' — ' + money(d.cents) + ' · ' + d.orders + ' order' + (d.orders === 1 ? '' : 's')) + '</title></rect>';
      if (i % Math.ceil(series.length / 7) === 0 || i === series.length - 1) {
        out += '<text class="lbl" x="' + (padL + step * i + step / 2).toFixed(1) + '" y="' + (h - padB + 16) + '" text-anchor="middle">' +
          esc(d.date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })) + '</text>';
      }
    });
    out += '</svg>';
    return out;
  }

  function pageDashboard() {
    var m = metrics();
    var series = revenueSeries(chartRange);
    var recent = m.orders.slice(0, 7);
    var top = topProducts(5);
    var hasOrders = m.orders.length > 0;
    var lowOut = m.lowStock.length + m.outOfStock.length;

    var html = '<div class="kad-wrap">';
    if (!hasOrders) {
      html += '<div class="kad-callout"><span class="ic">◉</span><div><b>Live store, no orders on this device yet.</b> Every figure on this page is computed from real orders — nothing is simulated. ' +
        'Orders placed in this browser appear here instantly. To see orders from every customer in one place, connect an order endpoint in <b>Settings → Orders sync</b>.</div></div>';
    }
    if (lowOut) {
      html += '<div class="kad-callout warn"><span class="ic">▲</span><div><b>' + lowOut + ' product' + (lowOut === 1 ? '' : 's') + ' need stock attention.</b> ' +
        m.outOfStock.length + ' sold out, ' + m.lowStock.length + ' running low. <a href="#admin/inventory" style="color:#f2d273">Open inventory →</a></div></div>';
    }
    html += '<div class="kad-stats">' +
      statCard('Total sales', money(m.revenueCents), m.authCount + ' paid orders counted', 'hot', '$') +
      statCard('Total orders', String(m.orders.length), m.pending.length + ' pending · ' + m.completed.length + ' completed', '', '❑') +
      statCard('Total customers', String(m.customers.length), m.customers.length ? 'avg ' + money(m.aovCents) + ' per order' : 'from real orders', '', '☺') +
      statCard('Total products', String(m.products.length), m.drafts.length + ' draft · ' + m.featured.length + ' featured', '', '◈') +
      statCard('Pending orders', String(m.pending.length), m.unpaid.length + ' awaiting payment', m.pending.length ? 'warn' : '', '◔') +
      statCard('Completed orders', String(m.completed.length), m.cancelled.length + ' cancelled / refunded', '', '✓') +
      statCard('Low-stock products', String(m.lowStock.length), 'threshold ' + settings().lowStockThreshold + ' units', m.lowStock.length ? 'warn' : '', '▤') +
      statCard('Sold-out products', String(m.outOfStock.length), m.soldUnits + ' units sold in total', m.outOfStock.length ? 'bad' : '', '⛔') +
      '</div>';

    html += '<div class="kad-grid2" style="margin-top:14px">' +
      '<div class="kad-card"><div class="kad-cardhead"><div><div class="kad-kick">Revenue overview</div><h2>' + money(series.reduce(function (a2, d) { return a2 + d.cents; }, 0)) + ' <span style="font-size:12px;font-family:\'Courier New\',monospace;letter-spacing:.14em;color:rgba(245,240,234,.5)">LAST ' + chartRange + ' DAYS</span></h2></div>' +
        '<div class="spacer"></div><div class="kad-seg" id="kadRangeSeg">' +
        ['7', '14', '30'].map(function (d) { return '<button data-range="' + d + '"' + (chartRange === Number(d) ? ' class="on"' : '') + '>' + d + 'D</button>'; }).join('') +
        '</div></div>' + chartSvg(series) +
        '<div class="kad-legend" style="margin-top:12px"><span>Total ' + money(series.reduce(function (s, d) { return s + d.cents; }, 0)) + '</span>' +
        '<span>' + series.reduce(function (s, d) { return s + d.orders; }, 0) + ' orders in this window</span>' +
        '<span>Today ' + money(m.revenueToday) + '</span><span>7 days ' + money(m.revenue7) + '</span><span>AOV ' + money(m.aovCents) + '</span></div></div>' +
      '<div class="kad-card"><div class="kad-cardhead"><div><div class="kad-kick">Best sellers</div><h2>Top products</h2></div></div>' +
      (top.length ? '<div style="display:grid;gap:10px">' + top.map(function (t) {
        return '<div class="kad-item"><img src="' + esc(t.img || '') + '" alt="" width="62" height="62" onerror="this.style.visibility=\'hidden\'">' +
          '<div class="m"><div class="nm">' + esc(t.name) + '</div><div class="mt">' + t.qty + ' sold · ' + money(t.cents) + '</div></div></div>';
      }).join('') + '</div>'
        : '<div class="kad-empty" style="padding:26px 16px"><div class="big" style="font-size:19px;color:rgba(245,240,234,.45)">No sales yet</div><p>Best sellers rank themselves as soon as the first order is placed.</p></div>') +
      '</div></div>';

    html += '<div class="kad-card" style="margin-top:14px"><div class="kad-cardhead"><div><div class="kad-kick">Latest activity</div><h2>Recent orders</h2></div>' +
      '<div class="spacer"></div><button class="kad-pillbtn ghost" data-act="goto-orders">All orders →</button></div>' +
      (recent.length ? ordersTable(recent, { compact: true }) :
        emptyState('No orders yet', 'Place a test order from the storefront — it will appear here with its real totals, customer and status.', '<button class="kad-btn" data-act="view-site">Open the shop</button>')) +
      '</div>';

    html += '</div>';
    return html;
  }

  function statCard(label, value, sub, kind, icon) {
    return '<div class="kad-stat ' + (kind || '') + '"><div class="lb">' + esc(label) + '</div>' +
      '<div class="vl">' + esc(value) + '</div><div class="sub">' + sub + '</div>' +
      '<div class="mini" aria-hidden="true">' + (icon || '') + '</div></div>';
  }

  function ordersTable(list, opts) {
    opts = opts || {};
    return '<div class="kad-tablewrap"><table class="kad-table"><thead><tr>' +
      '<th>Order</th><th>Date</th><th>Customer</th><th class="num">Items</th><th class="num">Total</th><th>Payment</th><th>Status</th>' +
      '</tr></thead><tbody>' +
      list.map(function (o) {
        return '<tr class="clickable" data-order="' + esc(o.number) + '">' +
          tableCell('Order', '<span class="strong">' + esc(o.number) + '</span>') +
          tableCell('Date', '<span class="mut">' + esc(dateTime(o.placedAt)) + '</span>') +
          tableCell('Customer', '<div class="kad-rowhead"><div><div class="nm">' + esc(o.customer.name || 'Guest') + '</div><div class="sb">' + esc(o.customer.city || o.customer.country || '—') + '</div></div></div>') +
          tableCell('Items', String(o.items.reduce(function (s, it) { return s + int(it.qty, 0); }, 0)), 'num') +
          tableCell('Total', money(o.totalCents), 'num strong') +
          tableCell('Payment', paymentChip(o.paymentStatus)) +
          tableCell('Status', orderChip(o.status)) +
          '</tr>';
      }).join('') +
      '</tbody></table></div>';
  }

  /* =========================================================================  ORDERS */
  var orderFilters = { q: '', status: '', payment: '', from: '', to: '', sort: 'date-desc', page: 1, per: 0 };

  function filteredOrders() {
    var list = orderList();
    var q = orderFilters.q.toLowerCase().trim();
    list = list.filter(function (o) {
      if (orderFilters.status && o.status !== orderFilters.status) return false;
      if (orderFilters.payment && o.paymentStatus !== orderFilters.payment) return false;
      if (orderFilters.from) {
        var t = new Date(o.placedAt).getTime();
        if (isFinite(t) && t < new Date(orderFilters.from + 'T00:00:00').getTime()) return false;
      }
      if (orderFilters.to) {
        var t2 = new Date(o.placedAt).getTime();
        if (isFinite(t2) && t2 > new Date(orderFilters.to + 'T23:59:59').getTime()) return false;
      }
      if (!q) return true;
      var hay = [o.number, o.customer.name, o.customer.email, o.customer.phone, o.customer.city, o.customer.country, o.promo,
        o.items.map(function (it) { return it.name; }).join(' ')].join(' ').toLowerCase();
      return hay.indexOf(q) > -1;
    });
    var sorters = {
      'date-desc': function (a, b) { return new Date(b.placedAt) - new Date(a.placedAt); },
      'date-asc': function (a, b) { return new Date(a.placedAt) - new Date(b.placedAt); },
      'total-desc': function (a, b) { return b.totalCents - a.totalCents; },
      'total-asc': function (a, b) { return a.totalCents - b.totalCents; },
      'status': function (a, b) { return ORDER_STATUSES.indexOf(a.status) - ORDER_STATUSES.indexOf(b.status); }
    };
    list.sort(sorters[orderFilters.sort] || sorters['date-desc']);
    return list;
  }

  function pageOrders() {
    var per = orderFilters.per || settings().ordersPerPage;
    var all = filteredOrders();
    var pg = paginate(all, orderFilters.page, per);
    orderFilters.page = pg.page;
    var m = metrics();
    var html = '<div class="kad-wrap">';
    html += '<div class="kad-stats">' +
      statCard('Orders', String(m.orders.length), 'all time', '', '❑') +
      statCard('Pending', String(m.pending.length), 'awaiting action', m.pending.length ? 'warn' : '', '◔') +
      statCard('Completed', String(m.completed.length), 'delivered', '', '✓') +
      statCard('Revenue', money(m.revenueCents), 'excludes cancelled', 'hot', '$') +
      '</div>';

    html += '<div class="kad-card" style="margin-top:14px"><div class="kad-toolbar">' +
      '<label class="kad-search" style="min-width:250px"><span>⌕</span><input id="kadOrderSearch" type="search" placeholder="Order number, name, email, city…" value="' + esc(orderFilters.q) + '"></label>' +
      '<select class="kad-sel" id="kadOrderStatus" style="width:190px"><option value="">All statuses</option>' +
      ORDER_STATUSES.map(function (s) { return '<option value="' + esc(s) + '"' + (orderFilters.status === s ? ' selected' : '') + '>' + esc(s) + '</option>'; }).join('') + '</select>' +
      '<select class="kad-sel" id="kadOrderPay" style="width:160px"><option value="">All payments</option>' +
      PAYMENT_STATUSES.map(function (s) { return '<option value="' + esc(s) + '"' + (orderFilters.payment === s ? ' selected' : '') + '>' + esc(s) + '</option>'; }).join('') + '</select>' +
      '<input class="kad-in" id="kadOrderFrom" type="date" value="' + esc(orderFilters.from) + '" style="width:150px" aria-label="From date">' +
      '<input class="kad-in" id="kadOrderTo" type="date" value="' + esc(orderFilters.to) + '" style="width:150px" aria-label="To date">' +
      '<select class="kad-sel" id="kadOrderSort" style="width:180px">' +
      [['date-desc', 'Newest first'], ['date-asc', 'Oldest first'], ['total-desc', 'Highest total'], ['total-asc', 'Lowest total'], ['status', 'By status']]
        .map(function (s) { return '<option value="' + s[0] + '"' + (orderFilters.sort === s[0] ? ' selected' : '') + '>' + s[1] + '</option>'; }).join('') + '</select>' +
      '<button class="kad-btn ghost sm" data-act="orders-clear">Clear</button>' +
      '</div>';

    if (!m.orders.length) {
      html += emptyState('No orders yet', 'Orders placed in the shop land here with their real items, customer details and totals. Nothing is faked — this list stays empty until a real order exists.',
        '<button class="kad-btn" data-act="view-site">Open the shop and place a test order</button>');
    } else if (!all.length) {
      html += emptyState('No orders match those filters', 'Try clearing the search or widening the date range.', '<button class="kad-btn ghost" data-act="orders-clear">Clear filters</button>');
    } else {
      html += ordersTable(pg.rows, {});
      html += pagerMarkup(pg, '<select class="kad-sel" id="kadOrderPer" style="width:120px;height:34px">' +
        [10, 25, 50, 100].map(function (n) { return '<option value="' + n + '"' + (per === n ? ' selected' : '') + '>' + n + ' / page</option>'; }).join('') + '</select>');
    }
    html += '</div></div>';
    return html;
  }

  function openOrder(number) {
    var order = orderList().filter(function (o) { return String(o.number) === String(number); })[0];
    if (!order) { toast('That order is no longer on this device.', 'err'); return; }
    var c = order.customer;
    var body = '<div class="kad-row2">' +
      '<div class="kad-card"><div class="kad-kick" style="font-family:\'Courier New\',monospace;font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:#d4af37">Customer</div>' +
      '<div style="margin-top:12px"><div style="font-size:15px;font-weight:700">' + esc(c.name || 'Guest') + '</div>' +
      '<div class="kad-hint" style="margin-top:6px">' + esc(c.email || 'no email') + '</div>' +
      '<div class="kad-hint">' + esc(c.phone || 'no phone') + '</div></div>' +
      '<dl class="kad-kv" style="margin-top:16px">' +
      '<dt>Address</dt><dd>' + esc([c.address, c.city, c.country].filter(Boolean).join(', ') || '—') + '</dd>' +
      '<dt>Placed</dt><dd>' + esc(dateTime(order.placedAt)) + ' · ' + esc(relTime(order.placedAt)) + '</dd>' +
      '<dt>Payment</dt><dd>' + esc(order.paymentLabel || order.paymentMethod || '—') + ' ' + paymentChip(order.paymentStatus) + '</dd>' +
      '<dt>Shipping</dt><dd>' + esc((order.shipping && order.shipping.label) || '—') + ' · ' + esc((order.shipping && order.shipping.eta) || '') + '</dd>' +
      '</dl></div>' +
      '<div class="kad-card"><div class="kad-kick" style="font-family:\'Courier New\',monospace;font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:#d4af37">Manage order</div>' +
      '<div class="kad-field" style="margin-top:12px"><label class="kad-label" for="kadOrderStatusSel">Order status</label>' +
      '<select class="kad-sel" id="kadOrderStatusSel">' + ORDER_STATUSES.map(function (s) {
        return '<option value="' + esc(s) + '"' + (order.status === s ? ' selected' : '') + '>' + esc(s) + '</option>';
      }).join('') + '</select><div class="kad-hint">The customer sees this on their order page instantly.</div></div>' +
      '<div class="kad-field"><label class="kad-label" for="kadOrderPaySel">Payment status</label>' +
      '<select class="kad-sel" id="kadOrderPaySel">' + PAYMENT_STATUSES.map(function (s) {
        return '<option value="' + esc(s) + '"' + (order.paymentStatus === s ? ' selected' : '') + '>' + esc(s.charAt(0).toUpperCase() + s.slice(1)) + '</option>';
      }).join('') + '</select></div>' +
      '<div class="kad-field"><label class="kad-label" for="kadOrderNote">Internal note</label>' +
      '<textarea class="kad-ta" id="kadOrderNote" style="min-height:80px" placeholder="Packed by Ayesha, courier booked for Thursday…">' + esc(order.notes) + '</textarea></div>' +
      '<div style="display:flex;gap:10px;flex-wrap:wrap"><button class="kad-btn" id="kadOrderSave">Save changes</button>' +
      '<button class="kad-btn ghost" id="kadOrderPrint">Print receipt</button>' +
      (order.status !== 'Cancelled' ? '<button class="kad-btn danger" id="kadOrderCancel">Cancel order</button>' : '') +
      '</div></div></div>';

    body += '<div class="kad-card" style="margin-top:14px"><div class="kad-cardhead"><div><div class="kad-kick" style="font-family:\'Courier New\',monospace;font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:#d4af37">Items</div><h2>' +
      order.items.reduce(function (s, it) { return s + int(it.qty, 0); }, 0) + ' item(s)</h2></div></div>' +
      '<div class="kad-items">' + order.items.map(function (it) {
        return '<div class="kad-item"><img src="' + esc(it.img || '') + '" alt="" width="62" height="62" onerror="this.style.visibility=\'hidden\'">' +
          '<div class="m"><div class="nm">' + esc(it.name) + '</div>' +
          '<div class="mt">US ' + esc(it.size || '—') + ' · ' + esc(it.colorName || it.color || '—') + ' · qty ' + int(it.qty, 0) + '</div>' +
          '<div class="mt">' + money(it.unitCents) + ' each</div></div>' +
          '<div style="text-align:right"><div class="strong" style="font-family:\'Courier New\',monospace">' + money(it.lineCents) + '</div></div></div>';
      }).join('') + '</div>' +
      '<dl class="kad-kv" style="margin-top:16px">' +
      '<dt>Subtotal</dt><dd>' + money(order.subtotalCents) + '</dd>' +
      (order.discountCents ? '<dt>Discount ' + esc(order.promo) + '</dt><dd>−' + money(order.discountCents) + '</dd>' : '') +
      '<dt>Shipping</dt><dd>' + money(order.shippingCents) + '</dd>' +
      '<dt>Total</dt><dd><b style="font-size:16px">' + money(order.totalCents) + '</b></dd></dl></div>';

    var timeline = order.timeline.slice().reverse();
    body += '<div class="kad-card" style="margin-top:14px"><div class="kad-cardhead"><div><div class="kad-kick" style="font-family:\'Courier New\',monospace;font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:#d4af37">History</div><h2>Timeline</h2></div></div>' +
      '<div class="kad-timeline">' +
      '<div class="ev"><div class="t">Order placed · ' + esc(order.status) + '</div><div class="d">' + esc(dateTime(order.placedAt)) + '</div></div>' +
      timeline.map(function (ev) {
        return '<div class="ev"><div class="t">' + esc(ev.label) + '</div><div class="d">' + esc(dateTime(ev.at)) + '</div></div>';
      }).join('') + '</div></div>';

    openDrawer({
      kicker: 'Order', title: order.number, body: body, focus: false,
      footer: '<button class="kad-pillbtn" id="kadOrderCopy">Copy order number</button>' +
        '<button class="kad-pillbtn ghost" data-act="mail-customer">Email customer</button>' +
        '<span class="spacer"></span><button class="kad-pillbtn ghost" id="kadDrawerCancel2">Close</button>'
    });

    $('#kadOrderSave').addEventListener('click', function () {
      var status = $('#kadOrderStatusSel').value;
      var pay = $('#kadOrderPaySel').value;
      var note = $('#kadOrderNote').value.trim();
      var label = 'Status changed to ' + status;
      if (pay !== order.paymentStatus) label += ' · payment ' + pay;
      var ok = updateOrder(order.number, { status: status, paymentStatus: pay, notes: note }, label);
      if (!ok) { toast('Could not update that order.', 'err'); return; }
      toast('Order ' + order.number + ' updated — ' + status, 'ok');
      openOrder(order.number);
      refreshNavMetrics();
    });
    $('#kadOrderCancel').addEventListener('click', function () {
      confirmDialog({
        title: 'Cancel ' + order.number + '?',
        body: 'The order stays in the list as <b>Cancelled</b> and the customer sees the new status on their order page. Stock is not re-added automatically.',
        ok: 'Cancel order', cancel: 'Keep it', danger: true
      }).then(function (yes) {
        if (!yes) return;
        updateOrder(order.number, { status: 'Cancelled' }, 'Order cancelled by the store');
        toast('Order cancelled.', 'warn');
        openOrder(order.number);
        refreshNavMetrics();
      });
    });
    $('#kadOrderPrint').addEventListener('click', function () { printOrder(order); });
    $('#kadOrderCopy').addEventListener('click', function () {
      try { navigator.clipboard.writeText(order.number); toast('Order number copied.', 'ok'); } catch (e) { toast(order.number, 'ok'); }
    });
    var mail = $('[data-act="mail-customer"]');
    if (mail) mail.addEventListener('click', function () {
      if (!order.customer.email) { toast('No email on this order.', 'err'); return; }
      location.href = 'mailto:' + order.customer.email + '?subject=' + encodeURIComponent('Your KINETIC order ' + order.number);
    });
    $('#kadDrawerCancel2').addEventListener('click', closeDrawer);
  }

  function printOrder(order) {
    var w = window.open('', '_blank', 'width=780,height=900');
    if (!w) { toast('Allow pop-ups to print the receipt.', 'err'); return; }
    var rows = order.items.map(function (it) {
      return '<tr><td>' + esc(it.name) + '<br><small>US ' + esc(it.size || '') + ' · ' + esc(it.colorName || '') + '</small></td>' +
        '<td style="text-align:center">' + int(it.qty, 0) + '</td><td style="text-align:right">' + money(it.lineCents) + '</td></tr>';
    }).join('');
    w.document.write('<!doctype html><html><head><title>' + esc(order.number) + ' — KINETIC receipt</title>' +
      '<style>body{font-family:system-ui,Arial,sans-serif;padding:34px;color:#111}h1{font-size:22px;margin:0 0 4px}' +
      'small{color:#666}table{width:100%;border-collapse:collapse;margin-top:18px}td,th{border-bottom:1px solid #ddd;padding:9px;font-size:13px;text-align:left}' +
      '.tot{font-weight:700;font-size:15px}.row{display:flex;justify-content:space-between;font-size:13px;padding:3px 0}</style></head><body>' +
      '<h1>KINETIC® — order receipt</h1><small>' + esc(order.number) + ' · ' + esc(dateTime(order.placedAt)) + ' · ' + esc(order.status) + '</small>' +
      '<p style="font-size:13px;margin-top:16px"><b>' + esc(order.customer.name || 'Guest') + '</b><br>' +
      esc([order.customer.address, order.customer.city, order.customer.country].filter(Boolean).join(', ')) + '<br>' +
      esc(order.customer.email || '') + ' · ' + esc(order.customer.phone || '') + '</p>' +
      '<table><thead><tr><th>Item</th><th style="text-align:center">Qty</th><th style="text-align:right">Total</th></tr></thead><tbody>' + rows + '</tbody></table>' +
      '<div style="margin-top:16px;max-width:300px;margin-left:auto">' +
      '<div class="row"><span>Subtotal</span><span>' + money(order.subtotalCents) + '</span></div>' +
      (order.discountCents ? '<div class="row"><span>Discount ' + esc(order.promo) + '</span><span>−' + money(order.discountCents) + '</span></div>' : '') +
      '<div class="row"><span>Shipping</span><span>' + money(order.shippingCents) + '</span></div>' +
      '<div class="row tot"><span>Total</span><span>' + money(order.totalCents) + '</span></div></div>' +
      '<script>window.onload=function(){window.print();}<\/script></body></html>');
    w.document.close();
  }

  /* =========================================================================  PRODUCTS */
  var productFilters = { q: '', cat: '', status: '', stock: '', sort: 'newest', page: 1 };
  var PER_PAGE_PRODUCTS = 8;

  function filteredProducts() {
    var list = productList();
    var q = productFilters.q.toLowerCase().trim();
    list = list.filter(function (p) {
      if (productFilters.cat && p.cat !== productFilters.cat) return false;
      if (productFilters.status && p.status !== productFilters.status) return false;
      if (productFilters.stock === 'low' && !(stockTotal(p) > 0 && stockRows(p).some(function (r) { return r.qty > 0 && r.qty <= settings().lowStockThreshold; }))) return false;
      if (productFilters.stock === 'out' && stockTotal(p) > 0) return false;
      if (productFilters.stock === 'in' && stockTotal(p) <= 0) return false;
      if (!q) return true;
      return (p.name + ' ' + p.cat + ' ' + p.tag + ' ' + productSku(p)).toLowerCase().indexOf(q) > -1;
    });
    var sorters = {
      newest: function (a, b) { return b.id - a.id; },
      oldest: function (a, b) { return a.id - b.id; },
      'name-asc': function (a, b) { return a.name.localeCompare(b.name); },
      'name-desc': function (a, b) { return b.name.localeCompare(a.name); },
      'price-desc': function (a, b) { return b.price - a.price; },
      'price-asc': function (a, b) { return a.price - b.price; },
      'stock-asc': function (a, b) { return stockTotal(a) - stockTotal(b); },
      'stock-desc': function (a, b) { return stockTotal(b) - stockTotal(a); }
    };
    list.sort(sorters[productFilters.sort] || sorters.newest);
    return list;
  }

  function stockCell(p) {
    var total = stockTotal(p);
    var rows = stockRows(p);
    var low = rows.filter(function (r) { return r.qty > 0 && r.qty <= settings().lowStockThreshold; }).length;
    var out = rows.filter(function (r) { return r.qty === 0; }).length;
    if (!total) return chip('Sold out', 'red');
    if (low) return chip(total + ' units · ' + low + ' low', 'amber');
    if (out) return chip(total + ' units · ' + out + ' sold out', 'gold');
    return chip(total + ' units', 'green');
  }

  function pageProducts() {
    var all = filteredProducts();
    var pg = paginate(all, productFilters.page, PER_PAGE_PRODUCTS);
    productFilters.page = pg.page;
    var m = metrics();
    var html = '<div class="kad-wrap">';
    html += '<div class="kad-stats">' +
      statCard('Products', String(m.products.length), m.drafts.length + ' draft · ' + (m.products.length - m.drafts.length) + ' live', '', '◈') +
      statCard('Featured', String(m.featured.length), 'shown first in the shop', '', '★') +
      statCard('Low stock', String(m.lowStock.length), '≤ ' + settings().lowStockThreshold + ' units in a size', m.lowStock.length ? 'warn' : '', '▤') +
      statCard('Sold out', String(m.outOfStock.length), 'no size available', m.outOfStock.length ? 'bad' : '', '⛔') +
      '</div>';

    html += '<div class="kad-card" style="margin-top:14px"><div class="kad-toolbar">' +
      '<label class="kad-search" style="min-width:250px"><span>⌕</span><input id="kadProdSearch" type="search" placeholder="Search name, SKU, tag…" value="' + esc(productFilters.q) + '"></label>' +
      '<select class="kad-sel" id="kadProdCat" style="width:180px"><option value="">All categories</option>' +
      categoryList().map(function (c) { return '<option value="' + esc(c.name) + '"' + (productFilters.cat === c.name ? ' selected' : '') + '>' + esc(c.name) + '</option>'; }).join('') + '</select>' +
      '<select class="kad-sel" id="kadProdStatus" style="width:150px"><option value="">Any status</option>' +
      ['active', 'draft'].map(function (s) { return '<option value="' + s + '"' + (productFilters.status === s ? ' selected' : '') + '>' + (s === 'active' ? 'Live' : 'Draft') + '</option>'; }).join('') + '</select>' +
      '<select class="kad-sel" id="kadProdStock" style="width:170px"><option value="">Any stock</option>' +
      [['in', 'In stock'], ['low', 'Low stock'], ['out', 'Sold out']].map(function (s) { return '<option value="' + s[0] + '"' + (productFilters.stock === s[0] ? ' selected' : '') + '>' + s[1] + '</option>'; }).join('') + '</select>' +
      '<select class="kad-sel" id="kadProdSort" style="width:180px">' +
      [['newest', 'Newest first'], ['name-asc', 'Name A–Z'], ['name-desc', 'Name Z–A'], ['price-desc', 'Price high → low'], ['price-asc', 'Price low → high'], ['stock-asc', 'Stock low → high'], ['stock-desc', 'Stock high → low']]
        .map(function (s) { return '<option value="' + s[0] + '"' + (productFilters.sort === s[0] ? ' selected' : '') + '>' + s[1] + '</option>'; }).join('') + '</select>' +
      '<div class="spacer"></div><button class="kad-btn ghost sm" data-act="products-clear">Clear</button>' +
      '<button class="kad-btn sm" data-act="product-new">+ Add product</button>' +
      '</div>';

    if (!m.products.length) {
      html += emptyState('No products yet', 'Add your first sneaker — it appears in the shop, the quick-view window and the product page immediately.',
        '<button class="kad-btn" data-act="product-new">+ Add product</button>');
    } else if (!all.length) {
      html += emptyState('Nothing matches those filters', 'Clear the filters to see all ' + m.products.length + ' products.', '<button class="kad-btn ghost" data-act="products-clear">Clear filters</button>');
    } else {
      html += '<div class="kad-tablewrap"><table class="kad-table"><thead><tr>' +
        '<th>Product</th><th>Category</th><th class="num">Price</th><th>Stock</th><th>Status</th><th>Featured</th><th style="text-align:right">Actions</th>' +
        '</tr></thead><tbody>';
      pg.rows.forEach(function (p) {
        var sold = p.old && p.old > p.price;
        html += '<tr data-product="' + p.id + '">' +
          tableCell('Product', '<div class="kad-rowhead"><img class="kad-thumb" src="' + esc(p.img) + '" alt="" width="46" height="46" onerror="this.style.visibility=\'hidden\'">' +
            '<div><div class="nm">' + esc(p.name) + '</div><div class="sb">' + esc(productSku(p)) + (p.tag ? ' · ' + esc(p.tag) : '') + '</div></div></div>') +
          tableCell('Category', esc(p.cat)) +
          tableCell('Price', money(p.price * 100) + (sold ? ' <s class="mut">' + money(p.old * 100) + '</s>' : ''), 'num') +
          tableCell('Stock', stockCell(p)) +
          tableCell('Status', p.status === 'draft' ? chip('Draft', 'mut') : chip('Live', 'green')) +
          tableCell('Featured', p.featured ? chip('Yes', 'gold') : '<span class="mut">—</span>') +
          tableCell('Actions', '<div style="display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap">' +
            '<button class="kad-btn dark sm" data-edit="' + p.id + '">Edit</button>' +
            '<button class="kad-btn ghost sm" data-dup="' + p.id + '">Copy</button>' +
            '<button class="kad-btn danger sm" data-del="' + p.id + '">Delete</button></div>', 'cell-empty') +
          '</tr>';
      });
      html += '</tbody></table></div>';
      html += pagerMarkup(pg);
    }
    html += '</div></div>';
    return html;
  }

  function blankProduct() {
    var list = productList();
    var nextId = list.reduce(function (m, p) { return Math.max(m, int(p.id, 0)); }, -1) + 1;
    var cats = categoryList();
    return normaliseProduct({
      id: nextId, name: '', cat: (cats[0] && cats[0].name) || 'Running', tag: 'New', desc: '',
      img: 'assets/images/40a470397f3ef7b7.jpg', price: 0, old: null, rating: 4.8, reviews: 0,
      colorways: [{ name: 'Midnight Black', swatch: '#08080A' }], sizes: SIZE_FALLBACK.slice(),
      status: 'active', featured: false, sku: '', stock: null
    });
  }

  function productEditor(id) {
    var draft;
    var isNew = false;
    if (id === 'new' || id === undefined || id === null || id === '') { draft = blankProduct(); isNew = true; }
    else {
      var found = productList().filter(function (p) { return String(p.id) === String(id); })[0];
      if (!found) { toast('That product is gone.', 'err'); return; }
      draft = clone(found);
    }
    var manual = !!draft.stock;
    var pending = manual ? Object.assign({}, draft.stock) : null;

    function body() {
      var cats = categoryList();
      var catOptions = cats.map(function (c) { return '<option value="' + esc(c.name) + '"' + (draft.cat === c.name ? ' selected' : '') + '>' + esc(c.name) + '</option>'; }).join('');
      var known = cats.some(function (c) { return c.name === draft.cat; });
      if (!known && draft.cat) catOptions = '<option value="' + esc(draft.cat) + '" selected>' + esc(draft.cat) + '</option>' + catOptions;

      var html = '<form id="kadProdForm" novalidate>';
      html += '<div class="kad-2col">' +
        '<div class="kad-field"><label class="kad-label" for="kf_name">Product name *</label><input class="kad-in" id="kf_name" value="' + esc(draft.name) + '" placeholder="Voltage Pro Carbon"><div class="kad-err" id="kf_name_err"></div></div>' +
        '<div class="kad-field"><label class="kad-label" for="kf_sku">SKU</label><input class="kad-in" id="kf_sku" value="' + esc(draft.sku) + '" placeholder="KNT-' + ('00' + (int(draft.id, 0) + 1)).slice(-3) + '"><div class="kad-hint">Leave blank and the console uses the numbered default.</div><div class="kad-err" id="kf_sku_err"></div></div>' +
        '</div>';
      html += '<div class="kad-3col">' +
        '<div class="kad-field"><label class="kad-label" for="kf_cat">Category</label><select class="kad-sel" id="kf_cat">' + catOptions + '</select></div>' +
        '<div class="kad-field"><label class="kad-label" for="kf_tag">Badge / tag</label><input class="kad-in" id="kf_tag" value="' + esc(draft.tag) + '" placeholder="Limited"><div class="kad-hint">Limited, New, Hot, Icon…</div></div>' +
        '<div class="kad-field"><label class="kad-label" for="kf_status">Status</label><select class="kad-sel" id="kf_status">' +
        '<option value="active"' + (draft.status === 'active' ? ' selected' : '') + '>Live — visible in the shop</option>' +
        '<option value="draft"' + (draft.status === 'draft' ? ' selected' : '') + '>Draft — hidden from customers</option></select></div>' +
        '</div>';
      html += '<div class="kad-3col">' +
        '<div class="kad-field"><label class="kad-label" for="kf_price">Price (USD) *</label><input class="kad-in" id="kf_price" type="number" min="0" step="1" value="' + esc(draft.price) + '"><div class="kad-err" id="kf_price_err"></div></div>' +
        '<div class="kad-field"><label class="kad-label" for="kf_old">Sale / previous price</label><input class="kad-in" id="kf_old" type="number" min="0" step="1" value="' + (draft.old == null ? '' : esc(draft.old)) + '" placeholder="Leave blank if not on sale"><div class="kad-err" id="kf_old_err"></div></div>' +
        '<div class="kad-field"><label class="kad-label" for="kf_edition">Edition size</label><input class="kad-in" id="kf_edition" type="number" min="0" step="1" value="' + (draft.editionSize == null ? '' : esc(draft.editionSize)) + '" placeholder="300 for numbered drops"></div>' +
        '</div>';
      html += '<div class="kad-field"><label class="kad-label" for="kf_desc">Description</label>' +
        '<textarea class="kad-ta" id="kf_desc" placeholder="Real featherweight knit shell over a full-length carbon plate…">' + esc(draft.desc) + '</textarea></div>';

      /* image */
      html += '<div class="kad-field"><label class="kad-label">Product image *</label>' +
        '<div class="kad-upl">' +
        '<img id="kf_img_preview" src="' + esc(draft.img) + '" alt="Product image preview" width="104" height="104" onerror="this.style.opacity=.25">' +
        '<div style="flex:1;min-width:220px;display:grid;gap:9px">' +
        '<input class="kad-in" id="kf_img" value="' + esc(/^data:/.test(draft.img) ? '' : draft.img) + '" placeholder="assets/images/your-photo.jpg or https://…">' +
        '<div style="display:flex;gap:9px;flex-wrap:wrap"><label class="kad-btn dark sm" style="cursor:pointer">Upload image<input type="file" id="kf_file" accept="image/*" hidden></label>' +
        '<button type="button" class="kad-btn ghost sm" id="kf_pick">Choose from library</button>' +
        (/^data:/.test(draft.img) ? '<button type="button" class="kad-btn danger sm" id="kf_img_clear">Remove upload</button>' : '') +
        '</div><div class="kad-hint">Uploads are stored with the product and moved into <b>assets/images/</b> when you press Publish live.</div>' +
        '<div class="kad-progress" id="kf_progress"><i></i></div>' +
        '</div></div><div class="kad-err" id="kf_img_err"></div></div>';

      /* sizes */
      html += '<div class="kad-field"><label class="kad-label">Available sizes *</label>' +
        '<div class="kad-swatches" id="kf_sizes">' + SIZE_FALLBACK.map(function (s) {
          var on = draft.sizes.indexOf(s) > -1;
          return '<button type="button" class="kad-btn ' + (on ? '' : 'dark') + ' sm" data-size="' + s + '" aria-pressed="' + on + '">US ' + s + '</button>';
        }).join('') + '</div><div class="kad-hint">Sizes switched off disappear from the product page and the quick-view window.</div><div class="kad-err" id="kf_sizes_err"></div></div>';

      /* stock */
      html += '<div class="kad-field"><label class="kad-label">Stock quantity</label>' +
        '<div class="kad-callout" style="margin-bottom:12px"><span class="ic">◉</span><div id="kf_stock_note">' +
        (manual ? 'Manual stock is set for this product — these numbers are what customers can buy.'
          : 'This product uses the demo stock levels. Enter numbers below to take manual control.') +
        '</div></div>' +
        '<div class="kad-sizes" id="kf_stock">' + draft.sizes.map(function (s) {
          var v = manual && pending && pending[s] !== undefined ? pending[s] : '';
          return '<div class="kad-size" data-size="' + s + '"><div class="lb"><span>US ' + s + '</span><b class="q">' + (v === '' ? 'auto' : v) + '</b></div>' +
            '<input type="number" min="0" step="1" data-stock="' + s + '" value="' + esc(v) + '" placeholder="auto" aria-label="Stock for US ' + s + '"></div>';
        }).join('') + '</div>' +
        '<div style="display:flex;gap:9px;flex-wrap:wrap;margin-top:11px">' +
        '<button type="button" class="kad-btn ghost sm" id="kf_stock_all">Apply to every size…</button>' +
        '<button type="button" class="kad-btn ghost sm" id="kf_stock_clear">Back to automatic stock</button>' +
        '</div></div>';

      /* colourways */
      html += '<div class="kad-field"><label class="kad-label">Colours *</label><div id="kf_colors">' +
        draft.colorways.map(colourRow).join('') +
        '</div><button type="button" class="kad-btn ghost sm" id="kf_addcolor">+ Add colour</button><div class="kad-err" id="kf_colors_err"></div></div>';

      /* meta */
      html += '<div class="kad-3col">' +
        '<div class="kad-field"><label class="kad-label" for="kf_rating">Rating (0–5)</label><input class="kad-in" id="kf_rating" type="number" min="0" max="5" step="0.1" value="' + esc(draft.rating) + '"></div>' +
        '<div class="kad-field"><label class="kad-label" for="kf_reviews">Review count</label><input class="kad-in" id="kf_reviews" type="number" min="0" step="1" value="' + esc(draft.reviews) + '"></div>' +
        '<div class="kad-field"><label class="kad-label">Featured</label><label class="kad-switch" style="height:42px"><input type="checkbox" id="kf_featured"' + (draft.featured ? ' checked' : '') + '><span class="tr"></span><span class="lb">Show first in the shop</span></label></div>' +
        '</div>';
      html += '</form>';
      return html;
    }

    function colourRow(c, i) {
      return '<div class="kad-cwrow" data-cw="' + i + '">' +
        '<input type="color" value="' + esc(c.swatch) + '" data-cw-swatch="' + i + '" aria-label="Colour ' + (i + 1) + '">' +
        '<input class="kad-in" value="' + esc(c.name) + '" data-cw-name="' + i + '" placeholder="Midnight Black" aria-label="Colour name ' + (i + 1) + '">' +
        '<button type="button" class="kad-x" data-cw-del="' + i + '" aria-label="Remove colour ' + (i + 1) + '">✕</button>' +
        '</div>';
    }

    function collectDraft() {
      draft.name = ($('#kf_name') || {}).value || '';
      draft.sku = (($('#kf_sku') || {}).value || '').trim().toUpperCase();
      draft.cat = ($('#kf_cat') || {}).value || draft.cat;
      draft.tag = (($('#kf_tag') || {}).value || '').trim();
      draft.status = ($('#kf_status') || {}).value || 'active';
      draft.price = num(($('#kf_price') || {}).value, 0);
      var oldV = ($('#kf_old') || {}).value;
      draft.old = (oldV === '' || oldV == null) ? null : num(oldV, 0);
      var ed = ($('#kf_edition') || {}).value;
      draft.editionSize = (ed === '' || ed == null) ? null : int(ed, 0);
      draft.desc = (($('#kf_desc') || {}).value || '').trim();
      draft.img = (($('#kf_img') || {}).value || '').trim() || draft.img;
      draft.rating = Math.max(0, Math.min(5, num(($('#kf_rating') || {}).value, 0)));
      draft.reviews = int(($('#kf_reviews') || {}).value, 0);
      draft.featured = !!($('#kf_featured') && $('#kf_featured').checked);
      draft.colorways = $$('#kf_colors .kad-cwrow').map(function (row) {
        return {
          name: ($('[data-cw-name]', row).value || '').trim(),
          swatch: String($('[data-cw-swatch]', row).value || '').toUpperCase()
        };
      });
      draft.colors = draft.colorways.map(function (c) { return c.swatch; });
      var manualNow = false, table = {};
      $$('#kf_stock [data-stock]').forEach(function (input) {
        var raw = String(input.value || '').trim();
        if (raw === '') return;
        manualNow = true;
        table[input.getAttribute('data-stock')] = Math.max(0, int(raw, 0));
      });
      /* sizes listed as manual keep their value even if blank (blank = 0 in manual mode) */
      if (manualNow) {
        draft.sizes.forEach(function (s) { if (!(s in table)) table[s] = 0; });
        draft.stock = table;
      } else {
        draft.stock = null;
      }
      return draft;
    }

    function validate() {
      var problems = [];
      $('#kf_name_err').textContent = ''; $('#kf_price_err').textContent = ''; $('#kf_old_err').textContent = '';
      $('#kf_img_err').textContent = ''; $('#kf_sizes_err').textContent = ''; $('#kf_sku_err').textContent = ''; $('#kf_colors_err').textContent = '';
      if (!draft.name.trim()) { $('#kf_name_err').textContent = 'A product name is required.'; problems.push('name'); }
      if (!(draft.price > 0)) { $('#kf_price_err').textContent = 'Enter a price above zero.'; problems.push('price'); }
      if (draft.old !== null && draft.old <= draft.price) { $('#kf_old_err').textContent = 'The sale price should be lower than the previous price.'; problems.push('old'); }
      if (!draft.img) { $('#kf_img_err').textContent = 'Add a product image (upload or URL).'; problems.push('img'); }
      if (!draft.sizes.length) { $('#kf_sizes_err').textContent = 'Keep at least one size.'; problems.push('sizes'); }
      if (!draft.colorways.length || draft.colorways.some(function (c) { return !c.name; })) {
        $('#kf_colors_err').textContent = 'Every colour needs a name.'; problems.push('colors');
      }
      if (draft.sku) {
        var clash = productList().some(function (p) { return String(p.id) !== String(draft.id) && productSku(p) === draft.sku; });
        if (clash) { $('#kf_sku_err').textContent = 'Another product already uses that SKU.'; problems.push('sku'); }
      }
      if (problems.length) {
        toast('Check the highlighted fields.', 'err');
        var first = $('#' + ({ name: 'kf_name', price: 'kf_price', old: 'kf_old', img: 'kf_img', sizes: 'kf_sizes', colors: 'kf_colors', sku: 'kf_sku' }[problems[0]]));
        if (first && first.focus) { try { first.focus(); } catch (e) {} }
        return false;
      }
      return true;
    }

    function save(saveAndNew) {
      collectDraft();
      if (!validate()) return;
      var s = state();
      s.products = Array.isArray(s.products) ? s.products : [];
      var index = -1;
      s.products.forEach(function (p, i) { if (String(p.id) === String(draft.id)) index = i; });
      var payload = clone(draft);
      payload.id = int(draft.id, 0);
      payload.status = draft.status;
      if (payload.old === undefined) payload.old = null;
      if (index > -1) s.products[index] = payload;
      else s.products.push(payload);
      s.products.forEach(function (p, i) { p.ord = i; });
      commit(isNew ? 'Product added — ' + draft.name : 'Product updated — ' + draft.name);
      refreshNavMetrics();
      if (saveAndNew) { closeDrawer(); productEditor('new'); return; }
      openProductEditor(draft.id);
      render();
    }

    function openProductEditor(keepId) {
      openDrawer({
        kicker: isNew ? 'New product' : 'Edit product',
        title: draft.name || 'Untitled product',
        body: body(),
        focus: false,
        footer: '<button class="kad-pillbtn primary" id="kf_save">Save product</button>' +
          '<button class="kad-pillbtn" id="kf_savenew">Save &amp; add another</button>' +
          '<span class="spacer"></span>' +
          (!isNew ? '<button class="kad-pillbtn danger" id="kf_delete">Delete</button>' : '') +
          '<button class="kad-pillbtn ghost" id="kf_cancel">Cancel</button>'
      });
      wire();
    }

    function wire() {
      var host = $('#kadDrawerBody');
      /* sizes toggles */
      $$('#kf_sizes [data-size]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var size = btn.getAttribute('data-size');
          var on = btn.getAttribute('aria-pressed') === 'true';
          btn.setAttribute('aria-pressed', on ? 'false' : 'true');
          btn.className = 'kad-btn ' + (on ? 'dark' : '') + ' sm';
          if (on) draft.sizes = draft.sizes.filter(function (s) { return s !== size; });
          else draft.sizes = draft.sizes.concat([size]).sort(function (a, b) { return num(a, 0) - num(b, 0); });
          var grid = $('#kf_stock');
          if (grid && !manual) {
            grid.innerHTML = draft.sizes.map(function (s) {
              var v = pending && pending[s] !== undefined ? pending[s] : '';
              return '<div class="kad-size" data-size="' + s + '"><div class="lb"><span>US ' + s + '</span><b class="q">' + (v === '' ? 'auto' : v) + '</b></div>' +
                '<input type="number" min="0" step="1" data-stock="' + s + '" value="' + esc(v) + '" placeholder="auto" aria-label="Stock for US ' + s + '"></div>';
            }).join('');
          }
        });
      });
      /* manual stock inputs */
      host.addEventListener('input', function (e) {
        var input = e.target.closest ? e.target.closest('[data-stock]') : null;
        if (!input) return;
        manual = true;
        pending = pending || {};
        var raw = String(input.value || '').trim();
        var size = input.getAttribute('data-stock');
        if (raw === '') delete pending[size]; else pending[size] = Math.max(0, int(raw, 0));
        var cell = input.closest('.kad-size');
        if (cell) {
          var q = $('.q', cell);
          if (q) q.textContent = raw === '' ? 'auto' : String(Math.max(0, int(raw, 0)));
          cell.classList.toggle('zero', int(raw, 0) === 0 && raw !== '');
          cell.classList.toggle('low', raw !== '' && int(raw, 0) > 0 && int(raw, 0) <= settings().lowStockThreshold);
        }
        var note = $('#kf_stock_note');
        if (note) note.textContent = 'Manual stock is set for this product — these numbers are what customers can buy.';
      });
      var stockAll = $('#kf_stock_all');
      if (stockAll) stockAll.addEventListener('click', function () {
        var boxes = $$('#kf_stock [data-stock]');
        if (!boxes.length) { toast('Switch on some sizes first.', 'err'); return; }
        confirmDialog({
          title: 'Set every size to the same quantity?',
          body: '<div class="kad-field"><label class="kad-label" for="kadBulkq">Units per size</label><input class="kad-in" id="kadBulkq" type="number" min="0" step="1" value="' + settings().lowStockThreshold + '"></div>' +
            '<div class="kad-hint">Applied to all ' + boxes.length + ' switched-on sizes of this product.</div>',
          ok: 'Apply'
        }).then(function (yes) {
          if (!yes) return;
          var v = Math.max(0, int(($('#kadBulkq') || {}).value, 0));
          manual = true; pending = {};
          boxes.forEach(function (input) {
            input.value = v;
            pending[input.getAttribute('data-stock')] = v;
            var cell = input.closest('.kad-size');
            if (cell) { var q = $('.q', cell); if (q) q.textContent = String(v); cell.classList.toggle('zero', v === 0); }
          });
          toast('Set to ' + v + ' units per size — press Save product.', 'ok');
        });
      });
      var stockClear = $('#kf_stock_clear');
      if (stockClear) stockClear.addEventListener('click', function () {
        manual = false; pending = null; draft.stock = null;
        $$('#kf_stock [data-stock]').forEach(function (input) {
          input.value = '';
          var cell = input.closest('.kad-size');
          if (cell) { cell.classList.remove('zero', 'low'); var q = $('.q', cell); if (q) q.textContent = 'auto'; }
        });
        var note = $('#kf_stock_note');
        if (note) note.textContent = 'This product uses the demo stock levels. Enter numbers below to take manual control.';
        toast('Back to automatic stock — remember to save.', 'warn');
      });
      /* colourways */
      var addColour = $('#kf_addcolor');
      if (addColour) addColour.addEventListener('click', function () {
        collectDraft();
        draft.colorways.push({ name: '', swatch: '#D4AF37' });
        $('#kf_colors').innerHTML = draft.colorways.map(colourRow).join('');
      });
      host.addEventListener('click', function (e) {
        var del = e.target.closest ? e.target.closest('[data-cw-del]') : null;
        if (!del) return;
        collectDraft();
        draft.colorways.splice(int(del.getAttribute('data-cw-del'), 0), 1);
        $('#kf_colors').innerHTML = draft.colorways.map(colourRow).join('');
      });
      /* image handling */
      $('#kf_file').addEventListener('change', function () {
        var file = this.files && this.files[0];
        if (!file) return;
        if (!/^image\//.test(file.type)) { toast('That file is not an image.', 'err'); return; }
        var bar = $('#kf_progress'); bar.classList.add('on');
        $('i', bar).style.width = '35%';
        var reader = new FileReader();
        reader.onload = function (ev) {
          var image = new Image();
          image.onload = function () {
            var max = 1400, w = image.width, h = image.height;
            if (w > max || h > max) {
              if (w >= h) { h = Math.round(h * max / w); w = max; } else { w = Math.round(w * max / h); h = max; }
            }
            var canvas = document.createElement('canvas');
            canvas.width = w; canvas.height = h;
            canvas.getContext('2d').drawImage(image, 0, 0, w, h);
            var data;
            try { data = canvas.toDataURL('image/jpeg', 0.86); } catch (err) { data = ev.target.result; }
            draft.img = data;
            $('#kf_img').value = '';
            $('#kf_img_preview').src = data;
            $('#kf_img_preview').style.opacity = '1';
            $('i', bar).style.width = '100%';
            setTimeout(function () { bar.classList.remove('on'); $('i', bar).style.width = '0'; }, 500);
            toast('Image attached — it will be uploaded to assets/images/ on publish.', 'ok');
          };
          image.onerror = function () { toast('That image could not be read.', 'err'); bar.classList.remove('on'); };
          image.src = ev.target.result;
        };
        reader.onerror = function () { toast('Could not read that file.', 'err'); };
        reader.readAsDataURL(file);
      });
      var pick = $('#kf_pick');
      if (pick) pick.addEventListener('click', function () { libraryPicker(function (url) { draft.img = url; $('#kf_img').value = url; $('#kf_img_preview').src = url; }); });
      var clearImg = $('#kf_img_clear');
      if (clearImg) clearImg.addEventListener('click', function () { draft.img = ''; $('#kf_img_preview').src = ''; toast('Upload removed.', 'warn'); });
      $('#kf_img').addEventListener('input', function () { draft.img = this.value.trim(); $('#kf_img_preview').src = draft.img; });
      /* save / cancel */
      $('#kf_save').addEventListener('click', function () { save(false); });
      $('#kf_savenew').addEventListener('click', function () { save(true); });
      $('#kf_cancel').addEventListener('click', closeDrawer);
      var del = $('#kf_delete');
      if (del) del.addEventListener('click', function () {
        confirmDialog({
          title: 'Delete ' + (draft.name || 'this product') + '?',
          body: 'The product is removed from the shop, the quick-view window and its product page. This cannot be undone once published.',
          ok: 'Delete product', danger: true
        }).then(function (yes) {
          if (!yes) return;
          var s = state();
          s.products = (s.products || []).filter(function (p) { return String(p.id) !== String(draft.id); });
          s.products.forEach(function (p, i) { p.ord = i; });
          commit('Product deleted — ' + draft.name);
          refreshNavMetrics();
          closeDrawer();
          render();
        });
      });
    }

    openProductEditor();
  }

  /* --------------------------------------------------------- image library */
  function libraryPicker(cb) {
    var images = [];
    try {
      var html = document.documentElement.innerHTML;
      var re = /assets\/images\/[a-z0-9_.-]+\.(?:jpg|jpeg|png|webp)/gi, match;
      while ((match = re.exec(html)) && images.length < 40) if (images.indexOf(match[0]) === -1) images.push(match[0]);
    } catch (e) {}
    productList().forEach(function (p) {
      if (/^assets\/images\//.test(p.img) && images.indexOf(p.img) === -1) images.push(p.img);
    });
    confirmDialog({
      title: 'Image library',
      body: images.length
        ? '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:10px;max-height:46vh;overflow:auto">' +
        images.map(function (src) {
          return '<button type="button" class="kad-btn dark sm" data-lib="' + esc(src) + '" style="padding:0;height:96px;border:1px solid rgba(212,175,55,.3);overflow:hidden">' +
            '<img src="' + esc(src) + '" alt="" style="width:100%;height:100%;object-fit:cover" loading="lazy"></button>';
        }).join('') + '</div>'
        : 'No images found on this device. Use “Upload image” instead.',
      ok: 'Close', cancel: 'Close'
    }).then(function () {});
    var modal = $('#kadModal');
    $$('[data-lib]', modal).forEach(function (b) {
      b.addEventListener('click', function () {
        cb(b.getAttribute('data-lib'));
        modal.classList.remove('on');
        if (confirmResolver) { var r = confirmResolver; confirmResolver = null; r(false); }
        toast('Image selected.', 'ok');
      });
    });
  }

  /* =========================================================================  INVENTORY */
  var inventoryFilter = { q: '', state: 'all' };

  function pageInventory() {
    var m = metrics();
    var list = m.products;
    var q = inventoryFilter.q.toLowerCase().trim();
    if (q) list = list.filter(function (p) { return (p.name + ' ' + p.cat + ' ' + productSku(p)).toLowerCase().indexOf(q) > -1; });
    if (inventoryFilter.state === 'low') list = list.filter(function (p) { return stockTotal(p) > 0 && stockRows(p).some(function (r) { return r.qty > 0 && r.qty <= settings().lowStockThreshold; }); });
    if (inventoryFilter.state === 'out') list = list.filter(function (p) { return stockTotal(p) === 0; });
    if (inventoryFilter.state === 'manual') list = list.filter(function (p) { return manualStock(p); });

    var units = m.products.reduce(function (s, p) { return s + stockTotal(p); }, 0);
    var html = '<div class="kad-wrap">';
    html += '<div class="kad-stats">' +
      statCard('Units in stock', String(units), m.products.length + ' products tracked', '', '▤') +
      statCard('Low-stock sizes', String(m.products.reduce(function (s, p) { return s + stockRows(p).filter(function (r) { return r.qty > 0 && r.qty <= settings().lowStockThreshold; }).length; }, 0)), '≤ ' + settings().lowStockThreshold + ' units', 'warn', '▲') +
      statCard('Sold-out sizes', String(m.products.reduce(function (s, p) { return s + stockRows(p).filter(function (r) { return r.qty === 0; }).length; }, 0)), m.outOfStock.length + ' products with nothing left', 'bad', '⛔') +
      statCard('Units sold', String(m.soldUnits), 'from ' + m.orders.length + ' orders', 'hot', '↗') +
      '</div>';

    html += '<div class="kad-card" style="margin-top:14px"><div class="kad-toolbar">' +
      '<label class="kad-search" style="min-width:240px"><span>⌕</span><input id="kadInvSearch" type="search" placeholder="Search product or SKU…" value="' + esc(inventoryFilter.q) + '"></label>' +
      '<div class="kad-seg" id="kadInvSeg">' +
      [['all', 'All'], ['low', 'Low stock'], ['out', 'Sold out'], ['manual', 'Manual stock']].map(function (s) {
        return '<button data-inv="' + s[0] + '"' + (inventoryFilter.state === s[0] ? ' class="on"' : '') + '>' + s[1] + '</button>';
      }).join('') + '</div>' +
      '<div class="spacer"></div>' +
      '<button class="kad-btn ghost sm" data-act="stock-restock">Restock low sizes</button>' +
      '<button class="kad-btn ghost sm" data-act="stock-export">Export CSV</button>' +
      '</div>';

    if (!m.products.length) {
      html += emptyState('No products to track', 'Add a product first — inventory follows automatically.', '<button class="kad-btn" data-act="product-new">+ Add product</button>');
    } else if (!list.length) {
      html += emptyState('Nothing in this view', 'Try the “All” tab or clear the search.', '');
    } else {
      html += '<div class="kad-tablewrap"><table class="kad-table"><thead><tr>' +
        '<th>Product</th><th>Per-size stock</th><th class="num">Total</th><th>Mode</th><th style="text-align:right">Actions</th></tr></thead><tbody>';
      list.forEach(function (p) {
        var rows = stockRows(p);
        var total = stockTotal(p);
        html += '<tr data-product="' + p.id + '">' +
          tableCell('Product', '<div class="kad-rowhead"><img class="kad-thumb" src="' + esc(p.img) + '" alt="" width="46" height="46" onerror="this.style.visibility=\'hidden\'">' +
            '<div><div class="nm">' + esc(p.name) + '</div><div class="sb">' + esc(productSku(p)) + ' · ' + esc(p.cat) + '</div></div></div>') +
          tableCell('Per-size stock', '<div class="kad-sizes" style="min-width:320px">' + rows.map(function (r) {
            var cls = r.qty === 0 ? 'zero' : (r.qty <= settings().lowStockThreshold ? 'low' : '');
            return '<div class="kad-size ' + cls + '"><div class="lb"><span>US ' + esc(r.size) + '</span></div>' +
              '<input type="number" min="0" step="1" value="' + r.qty + '" data-live-stock="' + esc(r.size) + '" data-live-product="' + p.id + '" aria-label="Stock for ' + esc(p.name) + ' US ' + esc(r.size) + '"></div>';
          }).join('') + '</div>') +
          tableCell('Total', String(total) + (total === 0 ? ' ' + chip('Out', 'red') : ''), 'num strong') +
          tableCell('Mode', manualStock(p) ? chip('Manual', 'gold') : chip('Auto', 'mut')) +
          tableCell('Actions', '<div style="display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap">' +
            '<button class="kad-btn dark sm" data-edit="' + p.id + '">Edit</button>' +
            (manualStock(p) ? '<button class="kad-btn ghost sm" data-auto="' + p.id + '">Use auto</button>' : '') +
            '</div>', 'cell-empty') + '</tr>';
      });
      html += '</tbody></table></div>';
      html += '<div class="kad-hint" style="margin-top:12px">Type a number in any box — it saves straight away and the shop, product page and cart follow it immediately. Blank boxes fall back to automatic demo stock.</div>';
    }
    html += '</div></div>';
    return html;
  }

  function saveLiveStock(productId, size, value) {
    var s = state();
    var p = (s.products || []).filter(function (x) { return String(x.id) === String(productId); })[0];
    if (!p) { toast('Product not found.', 'err'); return; }
    var table = (p.stock && typeof p.stock === 'object') ? Object.assign({}, p.stock) : {};
    var raw = String(value == null ? '' : value).trim();
    if (raw === '') delete table[size];
    else table[size] = Math.max(0, int(raw, 0));
    var hasNumbers = Object.keys(table).length > 0;
    p.stock = hasNumbers ? table : null;
    if (!hasNumbers) delete p.stock;
    commit('Stock updated — ' + (p.name || 'product') + ' US ' + size + ' → ' + (raw === '' ? 'auto' : raw));
    refreshNavMetrics();
  }

  function restockLowSizes() {
    var m = metrics();
    var targets = m.products.filter(function (p) {
      return stockRows(p).some(function (r) { return r.qty <= settings().lowStockThreshold; });
    });
    if (!targets.length) { toast('Nothing is running low — no restock needed.', 'ok'); return; }
    confirmDialog({
      title: 'Restock ' + targets.length + ' product' + (targets.length === 1 ? '' : 's') + '?',
      body: '<div class="kad-field"><label class="kad-label" for="kadRestockq">Set every size below the threshold to</label>' +
        '<input class="kad-in" id="kadRestockq" type="number" min="1" step="1" value="' + Math.max(6, settings().lowStockThreshold * 3) + '"></div>' +
        '<div class="kad-hint">Sizes already above the threshold are left alone. Product pages update immediately.</div>',
      ok: 'Restock now'
    }).then(function (yes) {
      if (!yes) return;
      var v = Math.max(1, int(($('#kadRestockq') || {}).value, 6));
      var s = state();
      var touched = 0;
      (s.products || []).forEach(function (p) {
        var norm = normaliseProduct(p);
        if (!targets.some(function (t) { return String(t.id) === String(norm.id); })) return;
        var table = (p.stock && typeof p.stock === 'object') ? Object.assign({}, p.stock) : {};
        norm.sizes.forEach(function (size) {
          var qty = stockFor(norm, size);
          if (qty <= settings().lowStockThreshold) { table[size] = v; touched++; }
        });
        p.stock = table;
      });
      commit('Restocked ' + touched + ' sizes across ' + targets.length + ' products');
      refreshNavMetrics();
      render();
    });
  }

  /* =========================================================================  CUSTOMERS */
  var customerFilters = { q: '', sort: 'recent', page: 1, per: 10 };

  function filteredCustomers() {
    var list = customerList();
    var q = customerFilters.q.toLowerCase().trim();
    if (q) {
      list = list.filter(function (c) {
        return (c.name + ' ' + c.email + ' ' + c.phone + ' ' + c.city + ' ' + c.country).toLowerCase().indexOf(q) > -1;
      });
    }
    var sorters = {
      recent: function (a, b) { return new Date(b.lastAt || 0) - new Date(a.lastAt || 0); },
      'spend-desc': function (a, b) { return b.spentCents - a.spentCents; },
      'orders-desc': function (a, b) { return b.orderCount - a.orderCount; },
      'name-asc': function (a, b) { return String(a.name).localeCompare(String(b.name)); },
      oldest: function (a, b) { return new Date(a.firstAt || 0) - new Date(b.firstAt || 0); }
    };
    list.sort(sorters[customerFilters.sort] || sorters.recent);
    return list;
  }

  function pageCustomers() {
    var all = filteredCustomers();
    var m = metrics();
    var pg = paginate(all, customerFilters.page, customerFilters.per);
    customerFilters.page = pg.page;
    var repeat = all.filter(function (c) { return c.orderCount > 1; }).length;
    var html = '<div class="kad-wrap">';
    html += '<div class="kad-stats">' +
      statCard('Customers', String(m.customers.length), 'from real orders', '', '☺') +
      statCard('Repeat buyers', String(repeat), 'more than one order', '', '↻') +
      statCard('Average order', money(m.aovCents), 'across ' + m.authCount + ' orders', '', '≈') +
      statCard('Total spent', money(m.revenueCents), 'lifetime, paid orders', 'hot', '$') +
      '</div>';

    html += '<div class="kad-card" style="margin-top:14px"><div class="kad-toolbar">' +
      '<label class="kad-search" style="min-width:260px"><span>⌕</span><input id="kadCustSearch" type="search" placeholder="Name, email, phone, city…" value="' + esc(customerFilters.q) + '"></label>' +
      '<select class="kad-sel" id="kadCustSort" style="width:200px">' +
      [['recent', 'Most recent'], ['spend-desc', 'Highest spend'], ['orders-desc', 'Most orders'], ['name-asc', 'Name A–Z'], ['oldest', 'First seen']]
        .map(function (s) { return '<option value="' + s[0] + '"' + (customerFilters.sort === s[0] ? ' selected' : '') + '>' + s[1] + '</option>'; }).join('') + '</select>' +
      '<div class="spacer"></div><button class="kad-btn ghost sm" data-act="customers-export">Export CSV</button></div>';

    if (!all.length) {
      html += emptyState('No customers yet', 'Customers appear here the moment a real order is placed — with their order count, lifetime spend and first order date.',
        '<button class="kad-btn" data-act="view-site">Open the shop</button>');
    } else {
      html += '<div class="kad-tablewrap"><table class="kad-table"><thead><tr>' +
        '<th>Customer</th><th>Contact</th><th>Location</th><th class="num">Orders</th><th class="num">Total spent</th><th class="num">Avg order</th><th>First order</th></tr></thead><tbody>';
      pg.rows.forEach(function (c) {
        html += '<tr class="clickable" data-customer="' + esc(c.key) + '">' +
          tableCell('Customer', '<div class="kad-rowhead"><div><div class="nm">' + esc(c.name) + '</div><div class="sb">' + esc(c.orderCount > 1 ? 'Repeat customer' : 'First-time buyer') + '</div></div></div>') +
          tableCell('Contact', '<div>' + esc(c.email || '—') + '</div><div class="mut">' + esc(c.phone || '') + '</div>') +
          tableCell('Location', esc([c.city, c.country].filter(Boolean).join(', ') || '—')) +
          tableCell('Orders', String(c.orderCount), 'num') +
          tableCell('Total spent', money(c.spentCents), 'num strong') +
          tableCell('Avg order', money(c.aovCents), 'num') +
          tableCell('First order', '<span class="mut">' + esc(dateShort(c.firstAt)) + '</span>') +
          '</tr>';
      });
      html += '</tbody></table></div>' + pagerMarkup(pg);
    }
    html += '</div></div>';
    return html;
  }

  function openCustomer(key) {
    var customer = customerList().filter(function (c) { return String(c.key) === String(key); })[0];
    if (!customer) { toast('That customer is not on this device.', 'err'); return; }
    var orders = customerOrders(customer);
    var body = '<div class="kad-row2">' +
      '<div class="kad-card"><div class="kad-kick" style="font-family:\'Courier New\',monospace;font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:#d4af37">Profile</div>' +
      '<dl class="kad-kv" style="margin-top:14px">' +
      '<dt>Name</dt><dd>' + esc(customer.name) + '</dd>' +
      '<dt>Email</dt><dd>' + esc(customer.email || '—') + '</dd>' +
      '<dt>Phone</dt><dd>' + esc(customer.phone || '—') + '</dd>' +
      '<dt>Location</dt><dd>' + esc([customer.city, customer.country].filter(Boolean).join(', ') || '—') + '</dd>' +
      '<dt>Customer since</dt><dd>' + esc(dateShort(customer.firstAt)) + ' · ' + esc(relTime(customer.firstAt)) + '</dd>' +
      '<dt>Last order</dt><dd>' + esc(dateShort(customer.lastAt)) + '</dd>' +
      '</dl></div>' +
      '<div class="kad-card"><div class="kad-kick" style="font-family:\'Courier New\',monospace;font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:#d4af37">Value</div>' +
      '<div class="kad-stats" style="grid-template-columns:1fr 1fr;margin-top:14px">' +
      statCard('Total orders', String(customer.orderCount), 'all time', '', '❑') +
      statCard('Total spent', money(customer.spentCents), 'cancelled orders excluded', 'hot', '$') +
      statCard('Average order', money(customer.aovCents), 'per order', '', '≈') +
      statCard('Lifetime', String(Math.max(0, Math.round((Date.now() - new Date(customer.firstAt).getTime()) / 864e5))) + ' days', 'since first order', '', '◷') +
      '</div></div></div>';
    body += '<div class="kad-card" style="margin-top:14px"><div class="kad-cardhead"><div><div class="kad-kick" style="font-family:\'Courier New\',monospace;font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:#d4af37">Order history</div><h2>' + orders.length + ' order' + (orders.length === 1 ? '' : 's') + '</h2></div></div>' +
      ordersTable(orders, {}) + '</div>';

    openDrawer({
      kicker: 'Customer', title: customer.name, body: body, focus: false,
      footer: '<button class="kad-pillbtn ghost" id="kadCustClose">Close</button>' +
        (customer.email ? '<button class="kad-pillbtn" id="kadCustMail">Email customer</button>' : '')
    });
    $('#kadCustClose').addEventListener('click', closeDrawer);
    var mail = $('#kadCustMail');
    if (mail) mail.addEventListener('click', function () { location.href = 'mailto:' + customer.email; });
  }

  /* =========================================================================  CATEGORIES */
  function pageCategories() {
    var cats = categoryList();
    var products = productList();
    var html = '<div class="kad-wrap">';
    html += '<div class="kad-callout"><span class="ic">◆</span><div><b>Categories drive the shop.</b> They fill the category dropdown in the product editor and the filter bar above the collection grid on the storefront. ' +
      'Products using a category: ' + products.length + '. Categories hidden here still exist on products but drop out of the filter bar.</div></div>';
    html += '<div class="kad-toolbar"><div class="spacer"></div><button class="kad-btn sm" data-act="cat-new">+ New category</button></div>';
    if (!cats.length) {
      html += emptyState('No categories yet', 'Create your first category to organise the collection.', '<button class="kad-btn" data-act="cat-new">+ New category</button>');
    } else {
      html += '<div class="kad-cats">';
      cats.forEach(function (c, i) {
        var count = products.filter(function (p) { return p.cat === c.name; }).length;
        html += '<div class="kad-cat" data-cat="' + esc(c.id) + '">' +
          '<div class="top"><span class="ic" aria-hidden="true">' + CAT_ICONS[i % CAT_ICONS.length] + '</span>' +
          '<div style="flex:1;min-width:0"><div class="nm">' + esc(c.name) + '</div>' +
          '<div class="mt">' + esc(c.id) + ' · ' + count + ' product' + (count === 1 ? '' : 's') + '</div></div>' +
          (c.status === 'hidden' ? chip('Hidden', 'mut') : chip('Visible', 'green')) + '</div>' +
          '<div class="dsc">' + esc(c.description || 'No description yet.') + '</div>' +
          '<div class="acts"><button class="kad-btn dark sm" data-cat-edit="' + esc(c.id) + '">Edit</button>' +
          '<button class="kad-btn ghost sm" data-cat-view="' + esc(c.name) + '">View products</button>' +
          '<button class="kad-btn danger sm" data-cat-del="' + esc(c.id) + '">Delete</button></div></div>';
      });
      html += '</div>';
    }
    html += '</div>';
    return html;
  }

  function categoryEditor(id) {
    var cats = categoryList();
    var existing = id ? cats.filter(function (c) { return String(c.id) === String(id); })[0] : null;
    var isNew = !existing;
    var draft = existing ? clone(existing) : { id: '', name: '', description: '', order: cats.length, status: 'active' };
    var body = '<form id="kadCatForm" novalidate>' +
      '<div class="kad-field"><label class="kad-label" for="kc_name">Category name *</label>' +
      '<input class="kad-in" id="kc_name" value="' + esc(draft.name) + '" placeholder="Running"><div class="kad-err" id="kc_name_err"></div></div>' +
      '<div class="kad-field"><label class="kad-label" for="kc_slug">URL / id</label>' +
      '<input class="kad-in" id="kc_slug" value="' + esc(draft.id) + '" placeholder="running"><div class="kad-hint">Lowercase, no spaces. Used in links and the filter bar.</div><div class="kad-err" id="kc_slug_err"></div></div>' +
      '<div class="kad-field"><label class="kad-label" for="kc_desc">Description</label>' +
      '<textarea class="kad-ta" id="kc_desc" style="min-height:80px" placeholder="Carbon-plated racers and daily trainers.">' + esc(draft.description) + '</textarea></div>' +
      '<div class="kad-2col">' +
      '<div class="kad-field"><label class="kad-label" for="kc_order">Sort order</label><input class="kad-in" id="kc_order" type="number" step="1" value="' + esc(draft.order) + '"></div>' +
      '<div class="kad-field"><label class="kad-label" for="kc_status">Visibility</label><select class="kad-sel" id="kc_status">' +
      '<option value="active"' + (draft.status === 'active' ? ' selected' : '') + '>Visible in the shop filter</option>' +
      '<option value="hidden"' + (draft.status === 'hidden' ? ' selected' : '') + '>Hidden from the filter</option></select></div>' +
      '</div></form>';

    openDrawer({
      kicker: isNew ? 'New category' : 'Edit category',
      title: draft.name || 'Untitled category',
      body: body, focus: true,
      footer: '<button class="kad-pillbtn primary" id="kc_save">Save category</button>' +
        '<span class="spacer"></span><button class="kad-pillbtn ghost" id="kc_cancel">Cancel</button>'
    });

    $('#kc_save').addEventListener('click', function () {
      var name = $('#kc_name').value.trim();
      var slugValue = slug($('#kc_slug').value.trim() || name);
      var products = productList();
      $('#kc_name_err').textContent = ''; $('#kc_slug_err').textContent = '';
      if (!name) { $('#kc_name_err').textContent = 'A name is required.'; return; }
      var clash = cats.some(function (c) { return c.id === slugValue && (!existing || c.id !== existing.id); });
      if (clash) { $('#kc_slug_err').textContent = 'That id is already taken.'; return; }
      if (!editable()) { toast('The store manager is not loaded — nothing saved.', 'err'); return; }
      var s = state();
      s.categories = categoryList().slice();
      var record = {
        id: slugValue, name: name, description: $('#kc_desc').value.trim(),
        order: int($('#kc_order').value, 0), status: $('#kc_status').value
      };
      var index = -1;
      s.categories.forEach(function (c, i) { if (existing && c.id === existing.id) index = i; });
      if (index > -1) s.categories[index] = record; else s.categories.push(record);
      s.categories.sort(function (a, b) { return int(a.order, 0) - int(b.order, 0); });
      /* renaming a category moves its products with it — no orphans */
      if (existing && existing.name !== name) {
        (s.products || []).forEach(function (p) { if (p.cat === existing.name) p.cat = name; });
      }
      commit('Category saved — ' + name);
      closeDrawer();
      render();
    });
    $('#kc_cancel').addEventListener('click', closeDrawer);
  }

  function deleteCategory(id) {
    var cats = categoryList();
    var cat = cats.filter(function (c) { return c.id === id; })[0];
    if (!cat) return;
    var used = productList().filter(function (p) { return p.cat === cat.name; });
    var otherNames = cats.filter(function (c) { return c.id !== id; }).map(function (c) { return c.name; });
    confirmDialog({
      title: 'Delete “' + cat.name + '”?',
      body: used.length
        ? '<div class="kad-callout warn" style="margin:0 0 12px"><span class="ic">▲</span><div>' + used.length + ' product' + (used.length === 1 ? '' : 's') + ' still use this category. Pick where they should move.</div></div>' +
        '<div class="kad-field"><label class="kad-label" for="kadMoveTo">Move products to</label><select class="kad-sel" id="kadMoveTo">' +
        otherNames.map(function (n) { return '<option value="' + esc(n) + '">' + esc(n) + '</option>'; }).join('') + '</select></div>'
        : 'This category is not used by any product yet.',
      ok: 'Delete category', danger: true
    }).then(function (yes) {
      if (!yes) return;
      var s = state();
      s.categories = cats.filter(function (c) { return c.id !== id; });
      if (used.length) {
        var target = ($('#kadMoveTo') || {}).value || otherNames[0];
        if (target) (s.products || []).forEach(function (p) { if (p.cat === cat.name) p.cat = target; });
      }
      commit('Category deleted — ' + cat.name);
      render();
    });
  }

  /* =========================================================================  COUPONS */
  function pageCoupons() {
    var coupons = couponList();
    var usage = couponUsage();
    var legacy = {};
    try { legacy = (appBridge() && appBridge().commerce && appBridge().commerce()) || {}; } catch (e) { legacy = {}; }
    var legacyCode = String(legacy.promoCode || '').toUpperCase();
    var legacyPct = num(legacy.promoPercent, 0);

    var html = '<div class="kad-wrap">';
    html += '<div class="kad-callout"><span class="ic">％</span><div><b>These coupons work at checkout.</b> The secure checkout validates every code against this list — percentage or fixed amount, expiry date, usage limit and on/off. ' +
      'Usage counts real orders on this device' + (settings().ordersEndpoint ? ' and any synced orders' : '') + '.</div></div>';
    if (legacyCode) {
      html += '<div class="kad-callout" style="background:rgba(212,175,55,.03)"><span class="ic">◉</span><div><b>Legacy promo still active:</b> ' +
        '<span class="kad-code" style="font-size:12px;padding:3px 7px">' + esc(legacyCode) + '</span> gives ' + Legacy(legacyPct) + ' off from <b>Settings → Shop rules</b>. ' +
        'Add it below if you want expiry dates and usage limits on it too.</div></div>';
    }
    html += '<div class="kad-toolbar"><div class="spacer"></div><button class="kad-btn sm" data-act="coupon-new">+ New coupon</button></div>';

    if (!coupons.length) {
      html += emptyState('No coupons yet', 'Create a discount code — it starts working at checkout the moment you save it.',
        '<button class="kad-btn" data-act="coupon-new">+ New coupon</button>');
    } else {
      html += '<div class="kad-tablewrap"><table class="kad-table"><thead><tr>' +
        '<th>Code</th><th>Discount</th><th>Expiry</th><th class="num">Used</th><th>State</th><th style="text-align:right">Actions</th></tr></thead><tbody>';
      coupons.forEach(function (c) {
        var state = couponState(c);
        var limit = c.usageLimit > 0 ? (c.used + ' / ' + c.usageLimit) : (c.used + ' / ∞');
        var pct = c.usageLimit > 0 ? Math.min(100, Math.round((c.used / c.usageLimit) * 100)) : 0;
        html += '<tr data-coupon="' + esc(c.code) + '">' +
          tableCell('Code', '<span class="kad-code">' + esc(c.code) + '</span>') +
          tableCell('Discount', c.type === 'percent' ? (c.value + '% off') : (money(c.value * 100) + ' off') +
            (c.minSubtotalCents ? '<div class="mut">min ' + money(c.minSubtotalCents) + '</div>' : '')) +
          tableCell('Expiry', c.expiresAt ? esc(dateShort(c.expiresAt)) : '<span class="mut">No expiry</span>') +
          tableCell('Used', limit + (pct ? '<div class="kad-bar"><i style="width:' + pct + '%"></i></div>' : ''), 'num') +
          tableCell('State', state.ok ? chip('Active', 'green') : chip(state.reason.indexOf('switched off') > -1 ? 'Disabled' : 'Blocked', 'red')) +
          tableCell('Actions', '<div style="display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap">' +
            '<button class="kad-btn dark sm" data-coupon-edit="' + esc(c.code) + '">Edit</button>' +
            '<button class="kad-btn ghost sm" data-coupon-toggle="' + esc(c.code) + '">' + (c.status === 'active' ? 'Disable' : 'Enable') + '</button>' +
            '<button class="kad-btn danger sm" data-coupon-del="' + esc(c.code) + '">Delete</button></div>', 'cell-empty') +
          '</tr>';
      });
      html += '</tbody></table></div>';
      html += '<div class="kad-hint" style="margin-top:12px">Tip: a usage limit counts orders that actually used the code, so “1 / 1” means the next attempt is refused at checkout.</div>';
    }
    html += '</div>';
    return html;
  }
  function Legacy(pct) { return (pct || 0) + '%'; }

  function couponEditor(code) {
    var coupons = couponList();
    var existing = code ? coupons.filter(function (c) { return c.code === String(code).toUpperCase(); })[0] : null;
    var isNew = !existing;
    var draft = existing ? clone(existing) : { code: '', type: 'percent', value: 10, minSubtotalCents: 0, expiresAt: '', usageLimit: 0, status: 'active', note: '' };

    var body = '<form id="kadCouponForm" novalidate>' +
      '<div class="kad-2col">' +
      '<div class="kad-field"><label class="kad-label" for="kq_code">Discount code *</label>' +
      '<input class="kad-in" id="kq_code" value="' + esc(draft.code) + '" placeholder="KINETIC10" style="text-transform:uppercase;letter-spacing:.12em">' +
      '<div class="kad-hint">Letters, numbers, dashes. Customers type it in the bag.</div><div class="kad-err" id="kq_code_err"></div></div>' +
      '<div class="kad-field"><label class="kad-label" for="kq_type">Discount type</label>' +
      '<select class="kad-sel" id="kq_type"><option value="percent"' + (draft.type === 'percent' ? ' selected' : '') + '>Percentage off merchandise</option>' +
      '<option value="fixed"' + (draft.type === 'fixed' ? ' selected' : '') + '>Fixed amount off (USD)</option></select></div>' +
      '</div>' +
      '<div class="kad-3col">' +
      '<div class="kad-field"><label class="kad-label" for="kq_value">Value *</label>' +
      '<input class="kad-in" id="kq_value" type="number" min="0" step="1" value="' + esc(draft.value) + '">' +
      '<div class="kad-hint" id="kq_value_hint">' + (draft.type === 'percent' ? 'Percent, 0–100.' : 'Dollars off the subtotal.') + '</div>' +
      '<div class="kad-err" id="kq_value_err"></div></div>' +
      '<div class="kad-field"><label class="kad-label" for="kq_min">Minimum subtotal (USD)</label>' +
      '<input class="kad-in" id="kq_min" type="number" min="0" step="1" value="' + esc(Math.round(draft.minSubtotalCents / 100)) + '" placeholder="0"></div>' +
      '<div class="kad-field"><label class="kad-label" for="kq_limit">Usage limit</label>' +
      '<input class="kad-in" id="kq_limit" type="number" min="0" step="1" value="' + esc(draft.usageLimit) + '" placeholder="0 = unlimited">' +
      '<div class="kad-hint">0 means unlimited. Counted from real orders.</div></div>' +
      '</div>' +
      '<div class="kad-2col">' +
      '<div class="kad-field"><label class="kad-label" for="kq_expiry">Expiry date</label>' +
      '<input class="kad-in" id="kq_expiry" type="date" value="' + esc(draft.expiresAt) + '">' +
      '<div class="kad-hint">Leave blank for a code that never expires.</div></div>' +
      '<div class="kad-field"><label class="kad-label">Status</label>' +
      '<label class="kad-switch" style="height:42px"><input type="checkbox" id="kq_active"' + (draft.status === 'active' ? ' checked' : '') + '><span class="tr"></span>' +
      '<span class="lb" id="kq_active_lb">' + (draft.status === 'active' ? 'Enabled — works at checkout' : 'Disabled — refused at checkout') + '</span></label></div>' +
      '</div>' +
      '<div class="kad-field"><label class="kad-label" for="kq_note">Internal note</label>' +
      '<input class="kad-in" id="kq_note" value="' + esc(draft.note) + '" placeholder="Ramadan campaign, Instagram only…"></div>' +
      '</form>';

    openDrawer({
      kicker: isNew ? 'New coupon' : 'Edit coupon',
      title: draft.code || 'Untitled coupon',
      body: body, focus: true,
      footer: '<button class="kad-pillbtn primary" id="kq_save">Save coupon</button>' +
        '<span class="spacer"></span>' +
        (!isNew ? '<button class="kad-pillbtn ghost" id="kq_copy">Copy code</button>' : '') +
        '<button class="kad-pillbtn ghost" id="kq_cancel">Cancel</button>'
    });

    var typeSel = $('#kq_type');
    typeSel.addEventListener('change', function () {
      $('#kq_value_hint').textContent = this.value === 'percent' ? 'Percent, 0–100.' : 'Dollars off the subtotal.';
    });
    var activeBox = $('#kq_active');
    activeBox.addEventListener('change', function () {
      $('#kq_active_lb').textContent = this.checked ? 'Enabled — works at checkout' : 'Disabled — refused at checkout';
    });
    $('#kq_cancel').addEventListener('click', closeDrawer);
    var copy = $('#kq_copy');
    if (copy) copy.addEventListener('click', function () {
      try { navigator.clipboard.writeText(draft.code); toast('Code copied — paste it in the bag to test.', 'ok'); } catch (e) { toast(draft.code, 'ok'); }
    });

    $('#kq_save').addEventListener('click', function () {
      var codeValue = String($('#kq_code').value || '').trim().toUpperCase().replace(/\s+/g, '');
      var type = $('#kq_type').value;
      var value = num($('#kq_value').value, 0);
      $('#kq_code_err').textContent = ''; $('#kq_value_err').textContent = '';
      if (!codeValue) { $('#kq_code_err').textContent = 'A code is required.'; return; }
      if (!/^[A-Z0-9-]{3,24}$/.test(codeValue)) { $('#kq_code_err').textContent = 'Use 3–24 letters, numbers or dashes.'; return; }
      var clash = coupons.some(function (c) { return c.code === codeValue && (!existing || c.code !== existing.code); });
      if (clash) { $('#kq_code_err').textContent = 'That code already exists.'; return; }
      if (value <= 0) { $('#kq_value_err').textContent = 'Enter a value above zero.'; return; }
      if (type === 'percent' && value > 100) { $('#kq_value_err').textContent = 'A percentage cannot exceed 100.'; return; }
      var expiry = $('#kq_expiry').value || '';
      if (expiry && new Date(expiry + 'T23:59:59').getTime() < Date.now()) {
        $('#kq_value_err').textContent = 'That expiry date is already in the past.';
        return;
      }
      if (!editable()) { toast('The store manager is not loaded — nothing saved.', 'err'); return; }
      var s = state();
      s.coupons = couponList().map(function (c) {
        return {
          code: c.code, type: c.type, value: c.value, minSubtotalCents: c.minSubtotalCents,
          expiresAt: c.expiresAt, usageLimit: c.usageLimit, status: c.status, note: c.note
        };
      });
      var record = {
        code: codeValue, type: type, value: value,
        minSubtotalCents: Math.round(num($('#kq_min').value, 0) * 100),
        expiresAt: expiry,
        usageLimit: Math.max(0, int($('#kq_limit').value, 0)),
        status: activeBox.checked ? 'active' : 'disabled',
        note: $('#kq_note').value.trim()
      };
      var index = -1;
      s.coupons.forEach(function (c, i) { if (existing && c.code === existing.code) index = i; });
      if (index > -1) s.coupons[index] = record; else s.coupons.push(record);
      commit('Coupon saved — ' + codeValue);
      closeDrawer();
      render();
      toast('Test it: add a pair to the bag and type ' + codeValue + ' at checkout.', 'ok');
    });
  }

  /* =========================================================================  CONTENT (store manager hub) */
  function pageContent() {
    var bridge = adminBridge();
    var hasBridge = !!(bridge && typeof bridge.openTab === 'function');
    var cards = [
      ['✎', 'Page text', 'Every headline, button label and paragraph on the storefront.', 'text'],
      ['◉', 'Numbers', 'Counters, ratings, statistics and the marketing figures used across the site.', 'numbers'],
      ['⚙', 'Shop settings', 'Free-shipping threshold, shipping cost and the legacy promo code.', 'shop'],
      ['↥', 'Publish & links', 'GitHub token, publish live, download content.json, customers and admin links.', 'publish']
    ];
    var html = '<div class="kad-wrap">';
    html += '<div class="kad-callout"><span class="ic">✎</span><div><b>Content editing lives in the store manager.</b> The editor below is the same, already-tested panel used before this dashboard — ' +
      'products, orders, inventory, customers, categories and coupons are managed from the sidebar instead.</div></div>';
    html += '<div class="kad-cats">' + cards.map(function (c) {
      return '<div class="kad-cat"><div class="top"><span class="ic">' + c[0] + '</span><div style="flex:1"><div class="nm">' + c[1] + '</div><div class="mt">Store manager</div></div></div>' +
        '<div class="dsc">' + c[2] + '</div>' +
        '<div class="acts"><button class="kad-btn sm" data-open-tab="' + c[3] + '">Open editor</button></div></div>';
    }).join('') + '</div>';
    if (!hasBridge) {
      html += '<div class="kad-callout bad" style="margin-top:16px"><span class="ic">▲</span><div>The store manager script (assets/kinetic-admin.js) is not loaded, so content editing is unavailable. ' +
        'The dashboard still shows live data, but nothing can be saved.</div></div>';
    }
    html += '</div>';
    return html;
  }

  /* =========================================================================  SETTINGS */
  function pageSettings() {
    var st = settings();
    var s = state();
    var commerce = (s && s.commerce) || {};
    var token = '';
    try { token = String(lsRaw(LSK.token, '') || '').replace(/^"|"$/g, ''); } catch (e) { token = ''; }
    var orders = orderList();
    var html = '<div class="kad-wrap">';

    html += '<div class="kad-grid2">';
    html += '<div class="kad-card"><div class="kad-cardhead"><div><div class="kad-kick">Store</div><h2>Shop rules</h2></div></div>' +
      '<div class="kad-2col">' +
      '<div class="kad-field"><label class="kad-label" for="ks_free">Free shipping over (USD)</label>' +
      '<input class="kad-in" id="ks_free" type="number" min="0" step="1" value="' + esc(Math.round(num(commerce.freeShippingThresholdCents, 18000) / 100)) + '"></div>' +
      '<div class="kad-field"><label class="kad-label" for="ks_ship">Standard shipping (USD)</label>' +
      '<input class="kad-in" id="ks_ship" type="number" min="0" step="1" value="' + esc(Math.round(num(commerce.shippingCents, 1200) / 100)) + '"></div>' +
      '</div><div class="kad-2col">' +
      '<div class="kad-field"><label class="kad-label" for="ks_code">Legacy promo code</label>' +
      '<input class="kad-in" id="ks_code" value="' + esc(String(commerce.promoCode || 'KINETIC20').toUpperCase()) + '"></div>' +
      '<div class="kad-field"><label class="kad-label" for="ks_pct">Legacy promo %</label>' +
      '<input class="kad-in" id="ks_pct" type="number" min="0" max="100" step="1" value="' + esc(num(commerce.promoPercent, 20)) + '"></div>' +
      '</div><button class="kad-btn" id="ks_save_shop">Save shop rules</button>' +
      '<div class="kad-hint" style="margin-top:10px">Shipping maths, the free-shipping bar and the checkout all read these numbers. Coupons are managed in the Coupons section.</div>' +
      '</div>';

    html += '<div class="kad-card"><div class="kad-cardhead"><div><div class="kad-kick">Console</div><h2>Dashboard preferences</h2></div></div>' +
      '<div class="kad-3col">' +
      '<div class="kad-field"><label class="kad-label" for="ks_low">Low-stock threshold</label>' +
      '<input class="kad-in" id="ks_low" type="number" min="1" step="1" value="' + esc(st.lowStockThreshold) + '"></div>' +
      '<div class="kad-field"><label class="kad-label" for="ks_per">Orders per page</label>' +
      '<select class="kad-sel" id="ks_per">' + [10, 25, 50, 100].map(function (n) { return '<option value="' + n + '"' + (st.ordersPerPage === n ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select></div>' +
      '<div class="kad-field"><label class="kad-label" for="ks_session">Auto-lock after (minutes)</label>' +
      '<input class="kad-in" id="ks_session" type="number" min="5" max="480" step="5" value="' + esc(st.sessionMinutes) + '"></div>' +
      '</div>' +
      '<label class="kad-switch" style="margin-bottom:14px"><input type="checkbox" id="ks_reload"' + (st.autoReload ? ' checked' : '') + '><span class="tr"></span>' +
      '<span class="lb">Reload the shop automatically after saving when live preview cannot update</span></label>' +
      '<button class="kad-btn" id="ks_save_console">Save preferences</button></div>';
    html += '</div>';

    html += '<div class="kad-grid2" style="margin-top:14px">';
    html += '<div class="kad-card"><div class="kad-cardhead"><div><div class="kad-kick">Security</div><h2>Access</h2></div></div>' +
      '<div class="kad-callout" style="margin-bottom:14px"><span class="ic">◉</span><div>Admin access is a client-side gate: the console only builds its UI after a correct PIN, the session auto-locks when idle, ' +
      'and five wrong PINs trigger a growing cooldown. Customers never load a single admin element. For a shared computer, press <b>Lock</b> when you finish.</div></div>' +
      '<div class="kad-2col">' +
      '<div class="kad-field"><label class="kad-label" for="ks_pin1">New PIN (4–12 digits)</label>' +
      '<input class="kad-in" id="ks_pin1" type="password" inputmode="numeric" autocomplete="new-password" placeholder="••••"></div>' +
      '<div class="kad-field"><label class="kad-label" for="ks_pin2">Repeat new PIN</label>' +
      '<input class="kad-in" id="ks_pin2" type="password" inputmode="numeric" autocomplete="new-password" placeholder="••••"></div>' +
      '</div><div class="kad-err" id="ks_pin_err"></div>' +
      '<div style="display:flex;gap:10px;flex-wrap:wrap"><button class="kad-btn" id="ks_pin_save">Change PIN</button>' +
      '<button class="kad-btn ghost" id="ks_lock">Lock console now</button></div></div>';

    html += '<div class="kad-card"><div class="kad-cardhead"><div><div class="kad-kick">Data</div><h2>Backups &amp; order sync</h2></div></div>' +
      '<div class="kad-field"><label class="kad-label" for="ks_endpoint">Order sync endpoint</label>' +
      '<input class="kad-in" id="ks_endpoint" value="' + esc(st.ordersEndpoint) + '" placeholder="https://… (JSON orders posted from the checkout)">' +
      '<div class="kad-hint">Optional. If you host an endpoint, the checkout posts each new order there and “Sync now” pulls the list back so every customer’s order lands in this dashboard. Leave blank to keep everything on this device.</div></div>' +
      '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px">' +
      '<button class="kad-btn" id="ks_endpoint_save">Save endpoint</button>' +
      '<button class="kad-btn ghost" id="ks_sync">Sync now</button></div>' +
      '<dl class="kad-kv"><dt>Orders on device</dt><dd>' + orders.length + '</dd>' +
      '<dt>Publish token</dt><dd>' + (token ? '<span style="color:#66d18a">saved on this device</span>' : '<span style="color:#ffb050">not set — add one in Publish &amp; links</span>') + '</dd></dl>' +
      '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px">' +
      '<button class="kad-btn dark" id="ks_export_orders">Export orders (CSV)</button>' +
      '<button class="kad-btn dark" id="ks_export_content">Export content.json</button>' +
      '<button class="kad-btn dark" id="ks_import">Import content.json</button>' +
      '<button class="kad-btn danger" id="ks_reset">Discard my draft</button></div>' +
      '<div class="kad-hint" style="margin-top:10px">“Discard my draft” throws away the unsaved working copy on this device and reloads the live content. The live site is untouched until you publish.</div>' +
      '</div>';
    html += '</div></div>';
    return html;
  }

  function syncOrders() {
    var st = settings();
    if (!st.ordersEndpoint) { toast('Add an order endpoint first.', 'err'); return Promise.resolve(false); }
    var url = st.ordersEndpoint;
    return fetch(url, { headers: { 'Accept': 'application/json' } })
      .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then(function (data) {
        var incoming = Array.isArray(data) ? data : (data && Array.isArray(data.orders) ? data.orders : null);
        if (!incoming) throw new Error('The endpoint did not return a list of orders');
        var local = orderList();
        var byNumber = {};
        local.forEach(function (o) { byNumber[String(o.number)] = o; });
        var added = 0;
        incoming.forEach(function (o) {
          var n = String(o && o.number || '');
          if (!n) return;
          if (byNumber[n]) {
            /* keep the admin's own status decisions, refresh the money/customer fields */
            var merged = byNumber[n];
            ['customer', 'items', 'subtotalCents', 'discountCents', 'shippingCents', 'totalCents', 'promo', 'placedAt']
              .forEach(function (k) { if (o[k] !== undefined) merged[k] = o[k]; });
          } else { local.push(normaliseOrder(o)); added++; }
        });
        writeOrders(local);
        toast('Synced — ' + added + ' new order' + (added === 1 ? '' : 's') + ' imported.', 'ok');
        render();
        return true;
      })
      .catch(function (e) {
        toast('Sync failed: ' + e.message, 'err');
        return false;
      });
  }

  /* =========================================================================  render */
  var chartRange = 14;
  var currentPage = 'dashboard';
  var PAGES = {
    dashboard: { title: 'Dashboard', crumb: 'KINETIC / admin / dashboard', render: pageDashboard },
    orders: { title: 'Orders', crumb: 'KINETIC / admin / orders', render: pageOrders },
    products: { title: 'Products', crumb: 'KINETIC / admin / products', render: pageProducts },
    inventory: { title: 'Inventory', crumb: 'KINETIC / admin / inventory', render: pageInventory },
    customers: { title: 'Customers', crumb: 'KINETIC / admin / customers', render: pageCustomers },
    categories: { title: 'Categories', crumb: 'KINETIC / admin / categories', render: pageCategories },
    coupons: { title: 'Coupons', crumb: 'KINETIC / admin / coupons', render: pageCoupons },
    content: { title: 'Page content', crumb: 'KINETIC / admin / content', render: pageContent },
    settings: { title: 'Settings', crumb: 'KINETIC / admin / settings', render: pageSettings }
  };

  function render() {
    if (!sessionActive()) { lock('session'); return; }
    /* moving between screens always clears anything floating on top */
    closeDrawer();
    var openModal = $('#kadModal');
    if (openModal && openModal.classList.contains('on')) { openModal.classList.remove('on'); openModal.setAttribute('aria-hidden', 'true'); }
    var sres = $('#kadSResults');
    if (sres && sres.classList.contains('on')) sres.classList.remove('on');
    var parsed = parseHash();
    currentPage = parsed ? parsed.name : 'dashboard';
    route.name = currentPage;                       /* keeps the sidebar highlight in step */
    route.arg = parsed ? parsed.arg : '';
    var host = $('#kadWrap');
    /* if the data itself is broken, show the error state instead of dying silently */
    try {
      var page = PAGES[currentPage] || PAGES.dashboard;
      $('#kadCrumb').textContent = page.crumb;
      $('#kadTitle').textContent = page.title;
      $('#kadTopActions').innerHTML = topActionsFor(currentPage);
      $('#kadWho').innerHTML = 'Signed in · <b>owner</b><br>' + esc(BUILD) + '<br>' + orderList().length + ' orders on this device';
      refreshNavMetrics();
    } catch (e) {
      if (host) {
        host.innerHTML = errorState('This screen failed to load', (e && e.message) ? e.message : 'Unexpected error while reading the shop data.', 'kadRetry');
        var r0 = $('#kadRetry');
        if (r0) r0.addEventListener('click', render);
      }
      if (window.console && console.warn) console.warn('[KINETIC admin] header render failed:', e);
      return;
    }
    host.innerHTML = skeletonRows(4);
    window.setTimeout(function () {
      try {
        host.innerHTML = page.render();
        wirePage(currentPage, parsed ? parsed.arg : '');
      } catch (e) {
        host.innerHTML = errorState('This screen failed to load', (e && e.message) ? e.message : 'Unexpected error while building the page.', 'kadRetry');
        var retry = $('#kadRetry');
        if (retry) retry.addEventListener('click', render);
        if (window.console && console.warn) console.warn('[KINETIC admin] render failed:', e);
      }
    }, 60);
    closeSideOnMobile();
  }

  function wirePage(name, arg) {
    if (name === 'dashboard') {
      $$('#kadRangeSeg button').forEach(function (b) {
        b.addEventListener('click', function () { chartRange = int(b.getAttribute('data-range'), 14); render(); });
      });
    }
    if (name === 'orders') {
      var search = $('#kadOrderSearch');
      if (search) search.addEventListener('input', debounce(function () { orderFilters.q = search.value; orderFilters.page = 1; render(); }, 260));
      var status = $('#kadOrderStatus');
      if (status) status.addEventListener('change', function () { orderFilters.status = status.value; orderFilters.page = 1; render(); });
      var pay = $('#kadOrderPay');
      if (pay) pay.addEventListener('change', function () { orderFilters.payment = pay.value; orderFilters.page = 1; render(); });
      var from = $('#kadOrderFrom');
      if (from) from.addEventListener('change', function () { orderFilters.from = from.value; orderFilters.page = 1; render(); });
      var to = $('#kadOrderTo');
      if (to) to.addEventListener('change', function () { orderFilters.to = to.value; orderFilters.page = 1; render(); });
      var sort = $('#kadOrderSort');
      if (sort) sort.addEventListener('change', function () { orderFilters.sort = sort.value; render(); });
      var per = $('#kadOrderPer');
      if (per) per.addEventListener('change', function () { orderFilters.per = int(per.value, 10); orderFilters.page = 1; render(); });
      if (arg) openOrder(arg);
    }
    if (name === 'products') {
      var ps = $('#kadProdSearch');
      if (ps) ps.addEventListener('input', debounce(function () { productFilters.q = ps.value; productFilters.page = 1; render(); }, 240));
      [['kadProdCat', 'cat'], ['kadProdStatus', 'status'], ['kadProdStock', 'stock'], ['kadProdSort', 'sort']].forEach(function (pair) {
        var el = $('#' + pair[0]);
        if (el) el.addEventListener('change', function () { productFilters[pair[1]] = el.value; productFilters.page = 1; render(); });
      });
      if (arg) productEditor(arg);
    }
    if (name === 'inventory') {
      var is = $('#kadInvSearch');
      if (is) is.addEventListener('input', debounce(function () { inventoryFilter.q = is.value; render(); }, 240));
      $$('#kadInvSeg button').forEach(function (b) {
        b.addEventListener('click', function () { inventoryFilter.state = b.getAttribute('data-inv'); render(); });
      });
      $$('#kadWrap [data-live-stock]').forEach(function (input) {
        var commitInput = debounce(function () {
          saveLiveStock(input.getAttribute('data-live-product'), input.getAttribute('data-live-stock'), input.value);
          var cell = input.closest('.kad-size');
          if (cell) {
            var v = int(input.value, -1);
            cell.classList.toggle('zero', v === 0);
            cell.classList.toggle('low', v > 0 && v <= settings().lowStockThreshold);
          }
        }, 650);
        input.addEventListener('input', commitInput);
        input.addEventListener('blur', commitInput);
      });
    }
    if (name === 'customers') {
      var cs = $('#kadCustSearch');
      if (cs) cs.addEventListener('input', debounce(function () { customerFilters.q = cs.value; customerFilters.page = 1; render(); }, 240));
      var csort = $('#kadCustSort');
      if (csort) csort.addEventListener('change', function () { customerFilters.sort = csort.value; render(); });
      if (arg) openCustomer(arg);
    }
    if (name === 'categories' && arg) categoryEditor(arg);
    if (name === 'coupons' && arg) couponEditor(arg);
    if (name === 'settings') wireSettings();
  }

  /* ------------------------------------------------------- delegated page actions */
  function handleAction(act, el) {
    switch (act) {
      case 'view-site': location.hash = ''; window.scrollTo(0, 0); closeAll(); break;
      case 'goto-orders': go('orders'); break;
      case 'product-new': productEditor('new'); break;
      case 'products-clear': productFilters = { q: '', cat: '', status: '', stock: '', sort: 'newest', page: 1 }; render(); break;
      case 'orders-clear': orderFilters = { q: '', status: '', payment: '', from: '', to: '', sort: 'date-desc', page: 1, per: 0 }; render(); break;
      case 'cat-new': categoryEditor(''); break;
      case 'coupon-new': couponEditor(''); break;
      case 'orders-export': exportOrdersCsv(); break;
      case 'customers-export': exportCustomersCsv(); break;
      case 'orders-import': importOrders(); break;
      case 'stock-restock': restockLowSizes(); break;
      case 'stock-export': exportInventoryCsv(); break;
      case 'publish': publishNow(el); break;
      default: break;
    }
  }

  function exportInventoryCsv() {
    var rows = [['Product', 'SKU', 'Category', 'Status', 'Size', 'Stock', 'Mode']];
    productList().forEach(function (p) {
      stockRows(p).forEach(function (r) {
        rows.push([p.name, productSku(p), p.cat, p.status, r.size, r.qty, manualStock(p) ? 'manual' : 'auto']);
      });
    });
    var csv = rows.map(function (r) { return r.map(function (c) { return '"' + String(c == null ? '' : c).replace(/"/g, '""') + '"'; }).join(','); }).join('\n');
    var bridge = adminBridge();
    if (bridge && bridge.download) bridge.download('kinetic-inventory-' + dayKey(new Date()) + '.csv', csv);
    else toast('Download is unavailable here.', 'err');
  }

  function importOrders() {
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,application/json';
    input.addEventListener('change', function () {
      var file = input.files && input.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function () {
        try {
          var data = JSON.parse(String(reader.result));
          var incoming = Array.isArray(data) ? data : (data && Array.isArray(data.orders) ? data.orders : null);
          if (!incoming) throw new Error('Expected a list of orders');
          var local = orderList();
          var known = {};
          local.forEach(function (o) { known[String(o.number)] = 1; });
          var added = 0;
          incoming.forEach(function (o) {
            var n = String((o && o.number) || '');
            if (!n || known[n]) return;
            local.push(normaliseOrder(o)); known[n] = 1; added++;
          });
          writeOrders(local);
          toast('Imported ' + added + ' order' + (added === 1 ? '' : 's') + '.', 'ok');
          render();
        } catch (e) { toast('Import failed: ' + e.message, 'err'); }
      };
      reader.readAsText(file);
    });
    input.click();
  }

  function publishNow(btn) {
    var bridge = adminBridge();
    if (!bridge || typeof bridge.publish !== 'function') { toast('Publishing is unavailable — the store manager script is missing.', 'err'); return; }
    if (btn) { btn.disabled = true; btn.textContent = 'Publishing…'; }
    Promise.resolve()
      .then(function () { return bridge.publish(); })
      .catch(function (e) { toast('Publish failed: ' + (e && e.message), 'err'); })
      .then(function () {
        if (btn) { btn.disabled = false; btn.textContent = 'Publish live'; }
        refreshNavMetrics();
      });
  }

  /* ------------------------------------------------------------- global search */
  function globalSearch(value) {
    var box = $('#kadSResults');
    if (!box) {
      box = document.createElement('div');
      box.id = 'kadSResults';
      box.className = 'kad-sresults';
      var host = $('#kadTop');
      if (host) host.appendChild(box);
    }
    var q = String(value || '').toLowerCase().trim();
    if (q.length < 2) { box.classList.remove('on'); box.innerHTML = ''; return; }
    var products = productList().filter(function (p) { return (p.name + ' ' + p.cat + ' ' + productSku(p)).toLowerCase().indexOf(q) > -1; }).slice(0, 5);
    var orders = orderList().filter(function (o) {
      return (o.number + ' ' + o.customer.name + ' ' + o.customer.email).toLowerCase().indexOf(q) > -1;
    }).slice(0, 5);
    var customers = customerList().filter(function (c) { return (c.name + ' ' + c.email + ' ' + c.phone).toLowerCase().indexOf(q) > -1; }).slice(0, 4);
    var html = '';
    if (products.length) {
      html += '<div class="kad-sresgroup">Products</div>' + products.map(function (p) {
        return '<button class="kad-sres" data-sres="product" data-id="' + p.id + '"><span class="t">' + esc(p.name) + '</span><span class="s">' + esc(p.cat) + ' · ' + money(p.price * 100) + '</span></button>';
      }).join('');
    }
    if (orders.length) {
      html += '<div class="kad-sresgroup">Orders</div>' + orders.map(function (o) {
        return '<button class="kad-sres" data-sres="order" data-id="' + esc(o.number) + '"><span class="t">' + esc(o.number) + '</span><span class="s">' + esc(o.customer.name || 'Guest') + ' · ' + money(o.totalCents) + '</span></button>';
      }).join('');
    }
    if (customers.length) {
      html += '<div class="kad-sresgroup">Customers</div>' + customers.map(function (c) {
        return '<button class="kad-sres" data-sres="customer" data-id="' + esc(c.key) + '"><span class="t">' + esc(c.name) + '</span><span class="s">' + esc(c.email || c.phone || '') + ' · ' + c.orderCount + ' orders</span></button>';
      }).join('');
    }
    if (!html) html = '<div class="kad-sresgroup">No matches</div><div class="kad-sres" style="cursor:default"><span class="s">Try a product name, order number or customer email.</span></div>';
    box.innerHTML = html;
    box.classList.add('on');
    $$('[data-sres]', box).forEach(function (b) {
      b.addEventListener('click', function () {
        var kind = b.getAttribute('data-sres');
        var id = b.getAttribute('data-id');
        box.classList.remove('on');
        var field = $('#kadGlobalSearch'); if (field) field.value = '';
        if (kind === 'product') go('products', id);
        else if (kind === 'order') go('orders', id);
        else go('customers', id);
      });
    });
  }

  /* =========================================================================  settings wiring */
  function wireSettings() {
    var st = settings();
    $('#ks_save_shop').addEventListener('click', function () {
      var free = Math.max(0, num($('#ks_free').value, 0));
      var ship = Math.max(0, num($('#ks_ship').value, 0));
      var code = String($('#ks_code').value || '').trim().toUpperCase();
      var pct = Math.max(0, Math.min(100, num($('#ks_pct').value, 0)));
      if (!editable()) { toast('The store manager is not loaded — nothing saved.', 'err'); return; }
      var s = state();
      s.commerce = Object.assign({}, s.commerce || {}, {
        freeShippingThresholdCents: Math.round(free * 100),
        shippingCents: Math.round(ship * 100),
        promoCode: code,
        promoPercent: pct
      });
      commit('Shop rules saved');
    });
    $('#ks_save_console').addEventListener('click', function () {
      saveSettings({
        lowStockThreshold: Math.max(1, int($('#ks_low').value, 3)),
        ordersPerPage: int($('#ks_per').value, 10),
        sessionMinutes: Math.max(5, Math.min(480, int($('#ks_session').value, st.sessionMinutes))),
        autoReload: !!$('#ks_reload').checked
      });
      render();
    });
    $('#ks_pin_save').addEventListener('click', function () {
      var a = String($('#ks_pin1').value || '').trim();
      var b = String($('#ks_pin2').value || '').trim();
      var err = $('#ks_pin_err');
      err.textContent = '';
      if (!/^\d{4,12}$/.test(a)) { err.textContent = 'The PIN must be 4–12 digits.'; return; }
      if (a !== b) { err.textContent = 'The two PINs do not match.'; return; }
      lsSet(LSK.pin, a);
      throttleClear();
      toast('PIN updated. Use the new one next time you unlock.', 'ok');
      $('#ks_pin1').value = ''; $('#ks_pin2').value = '';
    });
    $('#ks_lock').addEventListener('click', function () { lock('manual'); });
    $('#ks_endpoint_save').addEventListener('click', function () {
      saveSettings({ ordersEndpoint: String($('#ks_endpoint').value || '').trim() });
      render();
    });
    $('#ks_sync').addEventListener('click', function () { syncOrders(); });
    $('#ks_export_orders').addEventListener('click', function () { exportOrdersCsv(); });
    $('#ks_export_content').addEventListener('click', function () {
      var bridge = adminBridge();
      if (bridge && bridge.export) { bridge.export(); toast('content.json downloaded.', 'ok'); }
      else toast('Export needs the store manager script.', 'err');
    });
    $('#ks_import').addEventListener('click', function () {
      var bridge = adminBridge();
      if (!bridge || !bridge.importContent) { toast('Import needs the store manager script.', 'err'); return; }
      bridge.importContent(function (ok) {
        if (ok) { toast('Content imported — check the shop, then publish.', 'ok'); render(); }
        else toast('That file was not a valid content.json.', 'err');
      });
    });
    $('#ks_reset').addEventListener('click', function () {
      confirmDialog({
        title: 'Discard the draft on this device?',
        body: 'Your unsaved edits (and the local preview) are thrown away and the live content is loaded again. The published site is not touched.',
        ok: 'Discard draft', danger: true
      }).then(function (yes) {
        if (!yes) return;
        lsDel(LSK.content); lsDel(LSK.preview); lsDel(LSK.cache);
        var bridge = adminBridge();
        if (bridge && bridge.refresh) { try { bridge.refresh(); } catch (e) {} }
        toast('Draft discarded — reloading live content.', 'warn');
        setTimeout(function () { location.reload(); }, 700);
      });
    });
  }

  /* =========================================================================  lock / unlock */
  function buildLock() {
    if (!$('#kadLock')) {
      var lockel = document.createElement('div');
      lockel.id = 'kadLock';
      lockel.innerHTML = lockMarkup();
      document.body.appendChild(lockel);
      $('#kadUnlock').addEventListener('click', tryUnlock);
      $('#kadLockShop').addEventListener('click', function () { location.hash = ''; });
      $('#kadPin').addEventListener('keydown', function (e) { if (e.key === 'Enter') tryUnlock(); });
    }
    $('#kadLock').classList.add('on');
    setTimeout(function () {
      var pin = $('#kadPin');
      if (pin) { try { pin.focus(); } catch (e) {} }
    }, 80);
    var wait = throttleWaitMs();
    if (wait) paintThrottle(wait);
  }
  function paintThrottle(ms) {
    var err = $('#kadLockErr');
    if (!err) return;
    var secs = Math.ceil(ms / 1000);
    var tick = function () {
      var btn = $('#kadUnlock');
      if (secs <= 0) { err.textContent = ''; if (btn) btn.disabled = false; return; }
      err.textContent = 'Too many wrong PINs — try again in ' + secs + 's.';
      if (btn) btn.disabled = true;
      secs -= 1;
      setTimeout(tick, 1000);
    };
    tick();
  }
  function tryUnlock() {
    var wait = throttleWaitMs();
    if (wait) { paintThrottle(wait); return; }
    var field = $('#kadPin');
    var value = field ? String(field.value || '').trim() : '';
    var err = $('#kadLockErr');
    if (!value) { err.textContent = 'Enter your PIN.'; return; }
    if (value === pinGet()) {
      throttleClear();
      sessionStart();
      if (field) field.value = '';
      err.textContent = '';
      $('#kadLock').classList.remove('on');
      openConsole();
      toast('Signed in — session auto-locks when idle.', 'ok');
      return;
    }
    var t = throttleFail();
    err.textContent = t.until > Date.now()
      ? 'Too many wrong PINs — locked for a while.'
      : 'That PIN is not right (' + t.fails + ' failed attempt' + (t.fails === 1 ? '' : 's') + ').';
    if (t.until > Date.now()) paintThrottle(t.until - Date.now());
    if (field) { field.value = ''; field.focus(); }
  }

  function buildConsole() {
    if ($('#kadRoot')) return;
    var style = document.createElement('style');
    style.id = 'kadStyle';
    style.textContent = (typeof KINETIC_ADMIN_DASH_CSS === 'string' ? KINETIC_ADMIN_DASH_CSS : '');  /* stylesheet ships as assets/kinetic-admin-dash.css */
    document.head.appendChild(style);
    var root = document.createElement('div');
    root.id = 'kadRoot';
    root.innerHTML = shellMarkup();
    document.body.appendChild(root);

    $('#kadNav').addEventListener('click', function (e) {
      var b = e.target.closest('[data-nav]');
      if (!b) return;
      sessionTouch();
      go(b.getAttribute('data-nav'));
    });
    $('#kadTopActions').addEventListener('click', function (e) {
      var b = e.target.closest('[data-act]');
      if (!b) return;
      handleAction(b.getAttribute('data-act'), b);
    });
    $('#kadWrap').addEventListener('click', function (e) {
      var pageBtn = e.target.closest('[data-page]');
      if (pageBtn) {
        var next = int(pageBtn.getAttribute('data-page'), 1);
        if (currentPage === 'orders') orderFilters.page = next;
        else if (currentPage === 'products') productFilters.page = next;
        else if (currentPage === 'customers') customerFilters.page = next;
        render();
        var host = $('#kadPage'); if (host) host.scrollTop = 0;
        return;
      }
      var act = e.target.closest('[data-act]');
      if (act) { handleAction(act.getAttribute('data-act'), act); return; }
      var orderRow = e.target.closest('[data-order]');
      if (orderRow && !e.target.closest('button')) { go('orders', orderRow.getAttribute('data-order')); return; }
      var custRow = e.target.closest('[data-customer]');
      if (custRow && !e.target.closest('button')) { go('customers', custRow.getAttribute('data-customer')); return; }
      var edit = e.target.closest('[data-edit]');
      if (edit) { go('products', edit.getAttribute('data-edit')); return; }
      var dup = e.target.closest('[data-dup]');
      if (dup) { duplicateProduct(dup.getAttribute('data-dup')); return; }
      var delP = e.target.closest('[data-del]');
      if (delP) { deleteProduct(delP.getAttribute('data-del')); return; }
      var auto = e.target.closest('[data-auto]');
      if (auto) { useAutoStock(auto.getAttribute('data-auto')); return; }
      var catEdit = e.target.closest('[data-cat-edit]');
      if (catEdit) { go('categories', catEdit.getAttribute('data-cat-edit')); return; }
      var catDel = e.target.closest('[data-cat-del]');
      if (catDel) { deleteCategory(catDel.getAttribute('data-cat-del')); return; }
      var catView = e.target.closest('[data-cat-view]');
      if (catView) { productFilters = { q: '', cat: catView.getAttribute('data-cat-view'), status: '', stock: '', sort: 'newest', page: 1 }; go('products'); return; }
      var cEdit = e.target.closest('[data-coupon-edit]');
      if (cEdit) { go('coupons', cEdit.getAttribute('data-coupon-edit')); return; }
      var cToggle = e.target.closest('[data-coupon-toggle]');
      if (cToggle) { toggleCoupon(cToggle.getAttribute('data-coupon-toggle')); return; }
      var cDel = e.target.closest('[data-coupon-del]');
      if (cDel) { deleteCoupon(cDel.getAttribute('data-coupon-del')); return; }
      var tabBtn = e.target.closest('[data-open-tab]');
      if (tabBtn) { openStoreTab(tabBtn.getAttribute('data-open-tab')); return; }
    });
    $('#kadBurger').addEventListener('click', function () {
      $('#kadSide').classList.add('on');
      $('#kadScrim').classList.add('on');
    });
    $('#kadScrim').addEventListener('click', closeSideOnMobile);
    $('#kadDrawerClose').addEventListener('click', closeDrawer);
    $('#kadOverlay').addEventListener('click', closeDrawer);
    $('#kadViewSite').addEventListener('click', function () { location.hash = ''; closeConsole(); });
    $('#kadLockNow').addEventListener('click', function () { lock('manual'); });
    var search = $('#kadGlobalSearch');
    search.addEventListener('input', debounce(function () { globalSearch(search.value); }, 220));
    search.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { search.value = ''; globalSearch(''); }
    });
    document.addEventListener('click', function (e) {
      var box = $('#kadSResults');
      if (!box || !box.classList.contains('on')) return;
      if (e.target.closest && (e.target.closest('#kadSResults') || e.target.closest('#kadGlobalSearch'))) return;
      box.classList.remove('on');
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        if ($('#kadModal').classList.contains('on')) { var c = $('#kadModalCancel'); if (c) c.click(); return; }
        if ($('#kadDrawer').classList.contains('on')) { closeDrawer(); return; }
        var box = $('#kadSResults'); if (box && box.classList.contains('on')) { box.classList.remove('on'); return; }
        closeSideOnMobile();
      }
      if (e.key === 'Tab' && $('#kadDrawer').classList.contains('on')) {
        var layer = $('#kadDrawer');
        var focusables = $$('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])', layer)
          .filter(function (el) { return el.offsetParent !== null; });
        if (!focusables.length) return;
        var first = focusables[0], last = focusables[focusables.length - 1];
        if (e.shiftKey && (document.activeElement === first || !layer.contains(document.activeElement))) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && (document.activeElement === last || !layer.contains(document.activeElement))) { e.preventDefault(); first.focus(); }
      }
    });
    var lastTouch = 0;
    ['click', 'keydown'].forEach(function (evt) {
      document.addEventListener(evt, function () {
        if (!sessionActive()) return;
        var now = Date.now();
        if (now - lastTouch > 20000) { lastTouch = now; sessionTouch(); }
      }, true);
    });
    window.setInterval(function () {
      var root = $('#kadRoot');
      if (!root || !root.classList.contains('on')) return;
      if (!sessionActive()) lock('idle');
    }, 20000);
  }

  /* search-dropdown styles live in assets/kinetic-admin-dash.css */
  var EXTRA_CSS = '';

  /* ------------------------------------------------------------ product helpers */
  function duplicateProduct(id) {
    var source = productList().filter(function (p) { return String(p.id) === String(id); })[0];
    if (!source) return;
    if (!editable()) { toast('The store manager is not loaded — nothing saved.', 'err'); return; }
    var copy = clone(source);
    var nextId = productList().reduce(function (m, p) { return Math.max(m, int(p.id, 0)); }, -1) + 1;
    copy.id = nextId;
    copy.name = source.name + ' (copy)';
    copy.sku = '';
    copy.status = 'draft';
    copy.featured = false;
    var s = state();
    s.products = (s.products || []).concat([copy]);
    s.products.forEach(function (p, i) { p.ord = i; });
    commit('Product duplicated — ' + copy.name + ' (saved as a draft)');
    refreshNavMetrics();
    render();
  }
  function deleteProduct(id) {
    var p = productList().filter(function (x) { return String(x.id) === String(id); })[0];
    if (!p) return;
    confirmDialog({
      title: 'Delete ' + p.name + '?',
      body: 'The product disappears from the shop, the quick-view window and its product page. You can still undo by discarding the draft in Settings before publishing.',
      ok: 'Delete product', danger: true
    }).then(function (yes) {
      if (!yes) return;
      if (!editable()) { toast('The store manager is not loaded — nothing saved.', 'err'); return; }
      var s = state();
      s.products = (s.products || []).filter(function (x) { return String(x.id) !== String(id); });
      s.products.forEach(function (x, i) { x.ord = i; });
      commit('Product deleted — ' + p.name);
      refreshNavMetrics();
      render();
    });
  }
  function useAutoStock(id) {
    var p = productList().filter(function (x) { return String(x.id) === String(id); })[0];
    if (!p) return;
    confirmDialog({
      title: 'Stop managing stock for ' + p.name + '?',
      body: 'The per-size numbers you set are cleared and the product returns to the demo stock levels.',
      ok: 'Use automatic stock'
    }).then(function (yes) {
      if (!yes) return;
      var s = state();
      var row = (s.products || []).filter(function (x) { return String(x.id) === String(id); })[0];
      if (!row) return;
      delete row.stock;
      commit('Stock mode set to automatic — ' + p.name);
      refreshNavMetrics();
      render();
    });
  }
  function toggleCoupon(code) {
    var c = couponList().filter(function (x) { return x.code === String(code).toUpperCase(); })[0];
    if (!c) return;
    if (!editable()) { toast('The store manager is not loaded — nothing saved.', 'err'); return; }
    var s = state();
    var row = (s.coupons || []).filter(function (x) { return String(x.code || '').toUpperCase() === c.code; })[0];
    if (!row) return;
    row.status = c.status === 'active' ? 'disabled' : 'active';
    commit('Coupon ' + c.code + (row.status === 'active' ? ' enabled' : ' disabled'));
    render();
  }
  function deleteCoupon(code) {
    var c = couponList().filter(function (x) { return x.code === String(code).toUpperCase(); })[0];
    if (!c) return;
    confirmDialog({
      title: 'Delete coupon ' + c.code + '?',
      body: 'The code stops working at checkout immediately' + (c.used ? '. It has been used on ' + c.used + ' order(s) already, which keeps its discount.' : '.'),
      ok: 'Delete coupon', danger: true
    }).then(function (yes) {
      if (!yes) return;
      if (!editable()) { toast('The store manager is not loaded — nothing saved.', 'err'); return; }
      var s = state();
      s.coupons = couponList().filter(function (x) { return x.code !== c.code; }).map(function (x) {
        return { code: x.code, type: x.type, value: x.value, minSubtotalCents: x.minSubtotalCents, expiresAt: x.expiresAt, usageLimit: x.usageLimit, status: x.status, note: x.note };
      });
      commit('Coupon deleted — ' + c.code);
      render();
    });
  }
  function openStoreTab(tab) {
    var bridge = adminBridge();
    if (!bridge || typeof bridge.openTab !== 'function') { toast('The store manager script is not loaded.', 'err'); return; }
    closeDrawer();
    try { bridge.openTab(tab); } catch (e) { toast('Could not open that editor.', 'err'); }
  }

  function openConsole() {
    buildConsole();
    var root = $('#kadRoot');
    root.classList.add('on');
    if ($('#kadLock')) $('#kadLock').classList.remove('on');
    render();
  }
  function closeConsole() {
    var root = $('#kadRoot');
    if (root) root.classList.remove('on');
    closeDrawer();
  }
  function closeAll() {
    closeConsole();
    if ($('#kadLock')) $('#kadLock').classList.remove('on');
  }
  function closeSideOnMobile() {
    var side = $('#kadSide'), scrim = $('#kadScrim');
    if (side) side.classList.remove('on');
    if (scrim) scrim.classList.remove('on');
  }
  function closeDialogs() {
    var modal = $('#kadModal');
    if (modal && modal.classList.contains('on')) { modal.classList.remove('on'); modal.setAttribute('aria-hidden', 'true'); }
    var sres = $('#kadSResults');
    if (sres && sres.classList.contains('on')) sres.classList.remove('on');
  }
  function lock(reason) {
    sessionClear();
    closeDrawer();
    var modal = $('#kadModal');
    if (modal) { modal.classList.remove('on'); modal.setAttribute('aria-hidden', 'true'); }
    var root = $('#kadRoot');
    if (root && root.parentNode) root.parentNode.removeChild(root);
    var style = $('#kadStyle');
    if (style && style.parentNode) style.parentNode.removeChild(style);
    var box = $('#kadSResults');
    if (box && box.parentNode) box.parentNode.removeChild(box);
    document.documentElement.style.overflow = '';
    if (isAdminRoute()) buildLock();
    if (reason === 'idle') toast('Console locked after a period of inactivity.', 'warn');
    if (reason === 'manual') toast('Console locked.', 'ok');
    return true;
  }

  /* =========================================================================  boot */
  function isAdminRoute() { return /^#admin(\/|$)/i.test(location.hash || ''); }

  function boot() {
    if (isAdminRoute()) {
      if (sessionActive()) openConsole(); else buildLock();
    }
    window.addEventListener('hashchange', function () {
      if (!isAdminRoute()) { closeAll(); closeDrawer(); return; }
      if (sessionActive()) openConsole(); else buildLock();
    });
    window.addEventListener('kinetic:admin-unlocked', function () {
      /* the PIN was typed into the older panel's gate — adopt that unlock here too */
      sessionTouch();
      var lock = $('#kadLock');
      if (lock) lock.classList.remove('on');
      if (isAdminRoute()) openConsole();
    });
    window.addEventListener('kinetic:content-changed', function () {
      var root = $('#kadRoot');
      if (sessionActive() && root && root.classList.contains('on')) render();
    });
  }

  /* =========================================================================  public API (guarded) */
  window.KINETIC_ADMIN_DASH = {
    version: BUILD,
    open: function () { if (sessionActive()) openConsole(); else { location.hash = '#admin'; buildLock(); } return true; },
    close: function () { closeConsole(); return true; },
    lock: function () { return lock('manual'); },
    isUnlocked: function () { return sessionActive(); },
    route: function () { return currentPage; },
    go: function (name, arg) { if (!sessionActive()) return false; go(name, arg); return true; },
    data: function () {
      if (!sessionActive()) return null;
      return { products: productList(), orders: orderList(), customers: customerList(), categories: categoryList(), coupons: couponList(), metrics: metrics() };
    },
    refresh: function () { if (sessionActive()) render(); return true; },
    /* internal helpers are only handed out to an unlocked session, so a customer
       poking at the console in devtools never gets working admin functions */
    _internal: (function () {
      var all = {
        metrics: metrics, orderList: orderList, productList: productList, customerList: customerList,
        couponList: couponList, categoryList: categoryList, updateOrder: updateOrder, stockRows: stockRows, settings: settings
      };
      var guarded = {};
      Object.keys(all).forEach(function (k) {
        guarded[k] = function () { return sessionActive() ? all[k].apply(null, arguments) : null; };
      });
      return guarded;
    })()
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();

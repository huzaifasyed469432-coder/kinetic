# KINETIC® — Current Release Package

**Release:** Task #36 final release audit, 2026-11-18 (local release candidate).
**What this is:** the complete current KINETIC demo storefront — 82 deployment files
plus this README and the mobile-UX note (`MOBILE.md`). No admin panel, no backend,
no real payment processing.

## Contents

- `index.html`, `content.json`, `robots.txt`, `sitemap.xml` — the site root files.
- `assets/` — 14 JavaScript files, 7 CSS files, GSAP 3.12.5 + ScrollTrigger
  (`gsap.min.js`, `ScrollTrigger.min.js`).
- `assets/images/` — **57 hand-authored SVG artworks**: 19 full-size illustrations
  (1100 px wide) + 38 responsive variants (`assets/images/m/`, `-480` / `-900`).
  There are **no JPG files** in this package. All image references in the code
  point to `.svg` files.

Total: **82 deployment files, 1,282,418 bytes (~1.22 MB)**.

## The shop (demo data — fictional brand)

8 products, catalogue total $1,825:

| Product | Price |
|---|---|
| Voltage Pro Carbon | $260 |
| Apex 01 Racer | $285 |
| Monolith High | $195 |
| Strike Court Lo | $175 |
| Inferno Tilt Carbon | $320 |
| Nebula Runner | $210 |
| Shadow Knit | $160 |
| Retro 85 Carbon | $220 |

Commerce rules: free shipping on orders of $180 or more ($12 flat below);
promo code `KINETIC20` = 20% off. Cart, checkout, accounts and orders are
**demo only** — everything is stored in the browser's localStorage. No payment
is ever taken, no email is ever sent, and no order leaves the visitor's browser.
Demo order numbers look like `KNT-2611-XXXXXX`.

## How to run it

Any static host works (Vercel, Netlify, GitHub Pages, or a local folder):

```bash
unzip <this-file>.zip
cd <unzipped-folder>
python3 -m http.server 8000
# open http://127.0.0.1:8000/
```

No build step, no dependencies to install, no environment variables, no server
code. The site works fully offline of any backend: the two `/api/*` probes the
code makes (`/api/health`, `/api/products`) return 404 by design and the shop
falls back to the local `content.json` data.

## What is NOT in this package

- **No admin panel.** The former owner console (`kinetic-admin.js`,
  `kinetic-admin-dash.js/css`, `kinetic-gh-config.js`, `admin.html`) was removed
  from the release. There is no login, no PIN, and no `#admin` route.
- **No backend.** There is no server, database, payment gateway, or email service.
  Do not present the demo checkout as real payment processing.
- **No original photos.** The October 2026 photo set (including the Nike-style
  lookbook photos and stock portraits) was replaced by hand-authored SVG artwork.
  The 16 generation-original files under `assets/images/originals/` are **not**
  part of this package and must never be deployed.
- **No buyer handover documents.** The five handover documents (Buyer Overview,
  Technical Specification, Setup & Deployment Guide, Ownership Transfer Checklist,
  Asset Licence Audit) are sent separately by the seller; they are not inside
  this archive.

## What changed vs the October 2026 archives

The three October archives (`KINETIC-ecommerce-update.zip`,
`KINETIC-ecommerce-update (1).zip`, `deploy.zip`) contained the old JPG photos and
the removed admin panel code, including a default admin PIN printed in
documentation. This package replaces them: all 57 images are hand-authored SVGs,
the admin code and its documentation are gone, and the two known backend-probe
404s are the only failed requests (cosmetic, documented in the Technical
Specification).

## Notes for the buyer

- The brand, products, prices, reviews and lookbook content are **fictional
  demo content** — replace them with real content before selling.
- GSAP 3.12.5 + ScrollTrigger are bundled under the GSAP Standard "No Charge"
  licence (commercial use on a website is permitted; see the Asset Licence Audit
  in the handover documents).
- Fonts (Space Grotesk, Anton) are referenced, not distributed — they load from
  Google Fonts when the visitor is online.
- `MOBILE.md` (included) documents the mobile UX layer and the SVG responsive-
  image pipeline.

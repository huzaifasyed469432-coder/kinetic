# KINETIC® — E-commerce update

What was asked: keep the existing site exactly as it is and make the shopping
experience real — cart, quantities, checkout page, order summary, customer form,
shipping + payment selection, order numbers, order confirmation, and a cart that
survives a refresh.

Everything below was built **on top of** your current site. The homepage sections,
styling, typography, colours and animations are untouched.

---

## 1. Files

| File | Status | What changed |
|---|---|---|
| `index.html` | **modified** | 1 stylesheet link + 1 script tag + checkout/order containers + 3 small copy fixes (see §2) |
| `assets/kinetic-app.js` | **modified** | cart persistence, hand-over to checkout, small public API (see §3) |
| `assets/kinetic-checkout.js` | **new** | the checkout + order system (2 200 lines) |
| `assets/kinetic-checkout.css` | **new** | checkout/order styling in your existing design tokens |
| `assets/kinetic-admin.js` | **unchanged** | the store manager from the previous step (included for convenience) |
| `assets/kinetic-product.js` | **new** | the product detail page for every product (see §7) |
| `assets/kinetic-product.css` | **new** | product page styling in the same design tokens |

Nothing else was touched — no other file, no image, no CSS rule of the original design.

---

## 2. index.html — the complete diff against your live file

```diff
  <link rel="stylesheet" href="assets/kinetic.css">
+ <link rel="stylesheet" href="assets/kinetic-checkout.css">      <!-- checkout styling -->

+ <script src="assets/kinetic-checkout.js"></script>              <!-- checkout system -->

  <!-- inside the bag drawer -->
- Name for Tap checkout          →  Name for your order
- Email for payment receipt      →  Email for your receipt
- Continue to Tap payment        →  Secure checkout

+ <!-- CHECKOUT VIEW  (route #checkout) -->
+ <!-- ORDER CONFIRMATION VIEW  (route #order/<number>) -->
+ <!-- toast area for checkout messages -->

- <script async src="/.netlify/scripts/hud…">   (leftover Netlify tag, removed: it 404s
                                                 on GitHub Pages and was logging a
                                                 console error)
```

---

## 3. kinetic-app.js — what was added (no existing code rewritten)

1. **`persistCart()` / `restoreCart()`** — the bag is written to
   `localStorage['kinetic-cart-v1']` after every change and rebuilt on load, with
   repair rules (unknown product → dropped, missing size → dropped, colour that is
   not a real colourway → replaced, quantity clamped to 1–9, duplicate lines merged).
2. **Cross-page sync** — a `kinetic:cart-changed` event keeps the drawer and the
   checkout page in step in both directions.
3. **`startCheckout()`** now hands over to the new checkout page. If you ever connect
   a real payment provider, the previous hosted-checkout path is still there as a
   fallback.
4. **`window.KINETIC_APP`** — a small public API (products, colourways, money,
   commerce settings, open/close bag, toast, confetti) so the checkout page never has
   to duplicate your storefront logic.
5. Empty bag → the bag's **Secure checkout** button is disabled.

---

## 4. What a customer can now do

**Bag (your drawer, unchanged look)** — add to bag from the product modal, quantity
− / +, remove a line, subtotal / discount / shipping / total, promo code with error
messages, free-shipping progress bar, empty-bag state with a *Shop the collection*
button. Everything is recalculated automatically and saved instantly.

**Checkout page (route `#checkout`)** — opened by *Secure checkout*, or a direct link,
and it survives a refresh mid-way (the form is remembered per device):

1. **Your details** — Full name, Email, Phone, Address, City, Country. Live validation
   with real messages ("That email address is not valid"), red field states, shake
   animation, first-invalid field focused, `aria-invalid` + `role="alert"` for screen
   readers, Enter key advances the step.
2. **Delivery speed** — Standard (free over your $180 threshold) / Express / Priority.
   Prices and the total update live in the order summary. Shipping address is echoed
   with an *Edit details* link.
3. **Payment** — Card, Apple Pay, Google Pay, Cash on delivery, Bank transfer, with a
   card preview panel. The page states clearly that card details are never entered on
   the site and that no money is taken yet (there is no payment provider connected).
4. **Place order** — loading state, then the confirmation page.

**Order summary** — always visible beside the form on desktop (sticky) and a
tap-to-open bar on mobile. Each line shows the photo, size, colourway, quantity ×
unit price and its own subtotal, plus promo, shipping and the grand total. Quantities
and removals can be edited straight from the summary.

**Order confirmation (route `#order/<number>`)** — unique order number
(`KNT-2610-XXXXXX`, checked against previous orders, crypto-random when available),
status stamp, placed date, delivery window, payment method, shipping address, full
receipt with per-line totals, a "what happens next" timeline, and working
**Copy order number**, **Download receipt** (.txt) and **Print** buttons. Refreshing
the page keeps you on the same order; a link to an order that is not on this device
shows a friendly "not found" state.

**Also** — focus is trapped inside the open layer (Tab never escapes into the page
behind), Escape closes, the order-confirmation view closes back to the shop, body
scroll locks while a layer is open, `prefers-reduced-motion` is respected, and the
whole flow has loading skeletons and a loading state for the first step.

---

## 5. Testing that was done before delivery

Real Chromium (Puppeteer) + jsdom, on the actual files:

| Area | Result |
|---|---|
| Add to cart (real UI, through the product modal) | PASS |
| Quantity − / + (drawer **and** summary) | PASS |
| Remove line (drawer) / remove from summary | PASS |
| Subtotal, discount, shipping, total — automatic recalculation | PASS |
| Promo code valid / invalid / cleared | PASS |
| Empty-bag state + Continue shopping + disabled checkout | PASS |
| Checkout: 3 steps, all 6 fields, real validation messages | PASS (51 assertions) |
| Shipping + payment selection, totals update, place order | PASS |
| Order number generated / stored / shown, receipt download, copy | PASS |
| Refresh: cart survives, order page survives, checkout draft survives | PASS |
| Mobile 390 px and 360 px: no horizontal overflow on any view | PASS |
| Desktop 1440 px: summary beside the form, no overflow | PASS |
| Console: 0 uncaught errors, 0 `console.error`, 0 failed requests (404s) | PASS |
| Broken/hostile cart data (junk JSON, deleted product, bad colour, qty 9999) | PASS — repaired, no crash |
| localStorage blocked (restricted preview) | PASS — falls back to memory |
| Store manager (`#admin`) still works alongside all of this | PASS |

Bugs found during testing and fixed: the site's toast was swallowing taps on the bag's
checkout button on phones (toasts are now click-through and move to the top on mobile),
the floating "back to top" button sat on top of checkout (hidden while a layer is open),
Enter did not submit the details step, and an emptied bag could be re-filled from stale
storage.

---

## 6. Still your choice (deliberately not faked)

* **Payment** — no provider is connected, so placing an order records the order and
  tells the customer a payment link is coming. To take money for real you need a
  provider (Tap, Stripe, PayTabs…). The old hosted-checkout hook
  (`KINETIC_CONFIG.checkout.endpoint`) is still wired — give me the endpoint and the
  flow switches to real payment.
* **Order records** are kept on the customer's device (up to 40). A server/Sheets
  endpoint would let you see all orders in one place — say the word and I will add it.
* **Emails** — nothing is sent yet; the confirmation says a receipt is on its way.

---

## 7. Product detail pages (added after this update)

Every product now has its own full product page — **`#product/<id>`** (e.g. `#product/0`).
Reach it from the gold `↗` on any product card, or from **“View full details →”** in the
quick-view modal. Same black + gold design, nothing restyled.

**Two new files:** `assets/kinetic-product.js` + `assets/kinetic-product.css`.
**Two edited files:** `index.html` (2 tags + 1 container + the modal's details link) and
`assets/kinetic-app.js` (card corner became a real link, one helper API). `assets/kinetic-checkout.js`
gained one line so the product page can read your shipping rules.

The page covers everything asked for: gallery with thumbnails, hover zoom and a full-screen
zoom viewer; name, price, struck-through sale price, description, rating, review count;
sizes with EU conversions and real stock (sold-out sizes crossed out and blocked); colour
swatch selection; stock chip; quantity selector clamped to real stock; Add to Cart; Buy Now;
wishlist; live SKU; shipping and returns; an 11-row specification table; a review section
with a working “write a review” form; related products; and recently viewed.

**The cart connection is real.** Choosing US 9.5 + Warm Cream + quantity 2 puts exactly that
into the bag, the header count updates, the drawer shows “US 9.5 · Colour: Warm Cream · 2”,
and Buy Now opens the existing checkout with the same selection and totals. Nothing on the
product page is a mock-up.

Full documentation, the 26-point checklist and the test results: **`PDP.md`**.

---

## 8. Test results for this build

* **Desktop suite 100 / 100**, **mobile + all-products suite 52 / 52**, **0 page errors, 0 console
  errors, 0 failed requests** (verified with headless Chrome on 1440 px, 390 px and 360 px, real
  mouse and touch input).
* Regression kept green: quick-view modal, card colour swatches, filters, search, cart drawer
  quantities, checkout steps, order confirmation, admin panel.
* Screenshots: `/home/user/shots-pdp/` (desktop gallery, buy box, accordions, reviews, related,
  viewer, size guide; mobile top, buy box, sticky bar, reviews).
* Note: the site's own content loader asks the GitHub **API** for `content.json` first and falls
  back to `raw.githubusercontent.com`. From the test sandbox the API answers 403 (anonymous rate
  limit) and the fallback loads the content — that behaviour is your site's, unchanged by this work.

---

## 9. Admin dashboard (added after the product pages)

The owner console is now a complete management system behind `#admin` — dashboard with
real totals, product CRUD, orders, customers, inventory, categories, coupons, settings —
with PIN protection, throttling and an idle auto-lock.

* **Two new files** (`assets/kinetic-admin-dash.css`, `assets/kinetic-admin-dash.js`) and
  **two lines** in `index.html`. Nothing is rendered for a customer: the console builds no
  DOM unless the `#admin` route is open and the PIN is correct.
* **Four small additive edits** carry the new data through the existing pipeline:
  `kinetic-admin.js` (bridge + routing), `kinetic-content.js` (categories, coupons,
  settings and the new product fields survive the content file), `kinetic-app.js`
  (draft products hidden, featured sorting, live category filter bar, `reloadContent()`),
  `kinetic-checkout.js` (coupons validated for real, order history cap raised to 300,
  optional order-sync endpoint).
* **No fake statistics.** Sales, orders, customers, best sellers and coupon usage are all
  computed from real orders; stock comes from the same rule the product page uses. Where a
  number cannot be complete locally (orders live in each customer's browser), the UI says
  so and Settings offers an order-sync endpoint.
* **Tests: 189 / 189 passing, 0 page errors** (auth, product CRUD, order management,
  inventory, categories, coupons at checkout, responsive layouts, plus a full
  customer-facing regression). Details and screenshots: `DASHBOARD.md`,
  `/home/user/shots-dash/`.
* Install guide (steps 2c and 2d) and a Roman-Urdu summary are in `INSTALL.md`.

---

## 10. Collection search, filters & sorting (new)

The collection page now has a real-time search and filtering system — same design, same
fonts, same gold/black language; only the collection section gained three anchors
(`#kfltBar` toolbar, `#kfltRail` sidebar, `#kfltLayout` wrapper) around the untouched
`#productGrid`.

* **Search** — live (debounced) over product **name, SKU, category, colourway names,
  keywords and description text**; SKU works with or without the prefix (`KNT-002`, `002`).
  The header search overlay now shows highlighted suggestions with image, price, rating and
  SKU, **recent searches**, browse tags, a featured strip, and a no-results state with
  keyword shortcuts (`under $200`, `sale`, `new`, `popular`).
* **Filters** — category · price (dual-range, live) · size (US with EU twin, sold-out sizes
  hidden) · colour (real swatches) · availability (in stock / low stock / sold out) ·
  rating (4.5+, 4+, 3.5+) · on sale · featured. Counts next to each option are computed with
  the other filters still applied, so they are always honest.
* **Desktop sidebar, mobile drawer** — sticky scrollable rail on ≥1024 px (collapsible,
  remembered), full drawer with scrim, focus trap, live "N products match" and *Show results*
  on phones.
* **Chips** — one per active facet, each removable on its own, plus *Clear all*; the toolbar
  button shows how many filters are on.
* **Count + sorting** — `#resultCount` reads `8 Products` / `1 / 8 Products` live, `Sorted by …`
  follows the mode: **featured, newest, price low→high, price high→low, best rated,
  most popular** (real units sold).
* **Shareable URLs** — `?category=running&color=black&size=42&max=200&sort=low`; every change
  is written to the URL (Back works) and read back on load, so a refresh keeps the view.
  EU size numbers are converted with the shop's own US→EU table.
* **Fast & smooth** — ~120 ms re-render with a loading sweep and entrance animation,
  `prefers-reduced-motion` respected; nothing is hard-coded, so products, prices, colours,
  categories, sizes and stock the owner edits in the dashboard appear here immediately.
* **Tests:** `sf1.js` — **98 checks, 0 failures, 0 page errors** (search, multi-facet, chips,
  six sorts, price/size/availability/sale, URL persistence + Back/Forward, loading state,
  rail toggle, mobile drawer, no-results). Dashboard suites re-run afterwards:
  **189 + 7 checks, 0 failures**. Docs: `SEARCH.md`, screenshots `/home/user/shots-filters/`.

---

## 11. Mobile UX optimization (new)

Every page was audited and then optimised at **320 / 375 / 390 / 430 / 768 / 1440**:
homepage, product page, cart, checkout and the collection. All of it lives in
`assets/kinetic-mobile.css` + `assets/kinetic-mobile.js` (scoped to ≤1023px), so the
desktop design is unchanged.

* **Header** — logo, search, wishlist, bag and menu are all 44px+ and never overlap; the
  bag shows an icon + count on phones ("Bag 0" from 431px); **new wishlist button** with a
  slide-in panel (real items, *Choose size →*, remove, scrim/Escape/focus handling).
* **Menu** — links 52px, plus a *Search · Wishlist · Bag* quick-action row.
* **Touch targets** — ~28 undersized controls (from 16px ticker links to 28px cart ± buttons)
  brought to **≥44px**; dots and colour swatches keep their exact look via invisible hit areas.
* **Forms** — every input/select is **16px / 48px** on phones, so iOS no longer zooms on focus.
* **Layout** — no horizontal scroll at any width, clipped trust row fixed, filter toolbar
  re-ordered for phones (search → Filters/Copy link → Clear all → status → chips → sort),
  `[hidden]` respected again, safe-area padding for notched phones.
* **Images** — 480w/900w variants (`assets/images/m/`, 38 files) via `srcset`; the first grid
  row loads eagerly, the rest lazily. ≈30% less image weight on a phone.
* **Performance** — `content-visibility` on below-the-fold sections, cheaper blur on small
  screens, hover-only effects replaced with `:active` feedback, animations disabled under
  `prefers-reduced-motion`.
* **Tests** — `sm1.js`: **67 checks, 0 failures, 0 page errors**. Re-ran the filter suite
  (**98/0**) and the dashboard + customer suites (**189 + 7, 0 failures**) afterwards.
  Docs: `MOBILE.md`, screenshots `/home/user/shots-mobile/`.

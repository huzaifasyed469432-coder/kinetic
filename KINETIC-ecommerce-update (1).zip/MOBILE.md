# KINETIC® — mobile UX optimization

Everything below is live on the site. **Desktop is untouched**: every rule lives in
`assets/kinetic-mobile.css`, scoped to `max-width: 1023px` (with refinements at
`430px` and `360px`), loaded after all other stylesheets. Nothing is hidden — things
are sized, spaced and made touchable.

```
assets/kinetic-mobile.css   ← mobile + tablet layer
assets/kinetic-mobile.js    ← wishlist button/panel, menu quick actions, responsive images
assets/images/m/*.jpg       ← 480w + 900w variants of every photo (38 files)
```

`index.html` gained one stylesheet line and one script line; `kinetic-app.js` and
`kinetic-product.js` gained responsive-image attributes on their templates.

---

## 1. What the audit found (and what was fixed)

Measured with headless Chrome at **320 / 375 / 390 / 430 / 768 / 1440** across the
homepage, product page, cart, checkout and the collection:

| Finding | Fix |
|---|---|
| Header: the KINETIC® wordmark's glyphs spilled over the search/wishlist/bag icons at 390px (the logo box was being squeezed) | logo gets its own scale (22–26px), can't overflow, and the icon row was given its own 44px rules |
| The bag button showed a **lone “0” box** on phones (the “Bag” label was `hidden sm:inline`) | a bag icon + count on phones, “Bag 0” from 431px up |
| ~28 controls under the 44px touch minimum (header icons 40px, ticker 16px, menu links 40px, media arrows 42px, colour swatches 30px, cart ±28px, promo/checkout buttons 41px, footer links) | every one of them brought to **≥44px** (dots/swatches keep their look via invisible 44px hit areas) |
| 26 inputs rendered **11–12px** on phones → Safari auto-zooms on focus | all form controls are **16px** on phones (≤767px), 48px tall |
| “Free returns • 2-year warranty • Ships today” clipped to a broken next line at 320px | the trust row wraps properly |
| `.marquee`, ticker, drawer scrim etc. measured right of the viewport (clipped containers) | `overflow-x: clip` safety net + `overflow-wrap` on text |
| Filter toolbar order: search → filters → sort, with chips squeezed under | mobile order is now **search / Filters / Copy link → Clear all → status → chips → quick categories → sort**, and “Clear all” only appears when filters are on |
| `[hidden]` was being overridden by button display rules, so “Clear all” and the facet counter were always visible | `[hidden]` now wins |
| Images: phone pulled the full 1100px JPEG (up to 291KB each) | **srcset with 480w/900w/1100w variants**, lazy loading kept, first grid row eager |
| No wishlist entry point outside the quick-view | **wishlist button in the header** (phones/tablets) + slide-in panel + quick actions in the menu |

## 2. Per-panel detail

**Header** — logo, search, wishlist, bag and menu are all 44px+; the bag keeps its
count chip; the row never overlaps from 320px to tablet; the desktop header keeps its
original five icons plus cart (no wishlist icon, no visual change).

**Mobile menu** — full-screen sheet as before, links now 52px tall, and a
**Search · Wishlist · Bag** quick-action row above the footer so the three most-used
destinations are one tap away.

**Wishlist (new)** — header button with a live count, slide-in panel with real product
rows (image, name, category, price, sale price), *Choose size →* jumps into the
quick-view for a proper size/colour add, ✕ removes, scrim + Escape + focus handling,
`aria-hidden` / `inert` when closed. It reads the shop's own wishlist store and stays in
sync with the ♡ buttons on cards and product pages.

**Homepage** — section padding tightened for phones (80px → 58px of air), card padding
and the collection toolbar re-spaced, technology/review stepper dots and the lookbook
CTA made tappable, footer links 44px.

**Product page** — gallery arrows 46px, thumbnails 58px, size chips and colour swatches
44px+ (swatch dots keep their 30px look with a 44px hit area), Add to bag / Buy now
untouched at 59px, breadcrumb + rating links 44px, **sticky buy bar** verified while
scrolling (with `safe-area-inset` padding for the home indicator).

**Cart** — ± controls rebuilt to 44×44, remove button has a 44px hit area, promo row
wraps instead of squeezing, checkout button 48px+, drawer bottom padding respects the
home indicator.

**Checkout** — inputs 16px/48px (no iOS zoom), every button ≥44px, summary rows wrap,
safe-area padding on the fixed bar.

**Collection** — filter drawer: rows 46px, panel headers 48px, swatches 44px, close
button 44px, apply button full-width; grid, sorting and the whole filter system keep
working exactly as before.

**Performance** — 480w/900w image variants (≈30% smaller payload on phones),
`content-visibility: auto` on below-the-fold sections, blur cost reduced on small
screens, marquee/ticker animations disabled under `prefers-reduced-motion`, hover-only
effects replaced with `:active` feedback on touch devices.

**Accessibility** — 44px targets everywhere, focus moves into the wishlist panel and
returns on close, `aria-expanded` on the new button, all new controls labelled.

## 3. Tests

`/home/user/.tests/puppeteer_mobile/sm1.js` — **67 checks, 0 failures**, 0 page/console
errors (the only console noise is the site's own GitHub-API content call being rate-limited
inside the sandbox):

| Block | Covers |
|---|---|
| 1 | no horizontal scroll at 320/375/390/430/768/1440 on home + PDP + checkout |
| 2 | every control ≥44px on the homepage and in the cart drawer at 320px and 390px |
| 3 | no input below 16px on home / cart / checkout / collection (iOS zoom guard) |
| 4 | header: logo 44px+, icons 44px+, wishlist present on mobile, absent on desktop |
| 5 | mobile menu: opens, links 44px+, quick actions, scroll lock, closes |
| 6 | wishlist: save → badge, panel, item row, scrim + focus, remove, close, scroll release |
| 7 | product page: gallery, Add to bag/Buy now, size + colour chips, sticky bar + sticky button |
| 8 | responsive images: srcset + sizes present, hero priority, mobile variant actually chosen |
| 9 | collection: drawer opens, rows/swatches/close ≥44px, filter applies, no overflow |
| 10 | cart + checkout: 44×44 quantity, remove hit area, checkout button, + works, inputs 16px, buttons 44px+ |

Run:

```bash
cd /home/user/kinetic && python3 -m http.server 8100 --bind 0.0.0.0 &
cd /tmp/t && node sm1.js      # 67 pass / 0 fail
```

**Regressions re-run after this work:** collection filters `sf1.js` **98/0**,
dashboard + customer suites `s3–s9` + `final.js` **189 + 7, 0 failures, 0 page errors**.

## 4. Screenshots

`/home/user/shots-mobile/` — `M1` hero · `M2` collection toolbar · `M3` menu ·
`M4` wishlist · `M5` cart · `M6` filter drawer · `M7` product page · `M8` sticky buy bar ·
`M9` checkout · `M10` 320px collection · `M11`/`M12` 430px · `M13` tablet.

## 5. Adding the image variants (what an owner needs to know)

The 480w/900w files live in `assets/images/m/` and are referenced by `srcset`. If the
folder is missing the browser simply falls back to the full-size image — nothing breaks.
To make variants for a newly uploaded photo, resize it to 480px and 900px wide with the
same filename inside `assets/images/m/` (`<name>-480.jpg`, `<name>-900.jpg`).

# KINETIC® Store Manager — Install & User Guide

**What this is:** a control panel that lets you add, edit and delete everything on your
KINETIC site yourself — products, prices, photos, headings, numbers, shipping — from the
browser. No developer, no code, no waiting.

Your website's design is **untouched**. The only change to your site is one extra line in
`index.html` that loads the panel.

---

## 1. Your two links

| Who | Link | What they see |
|---|---|---|
| **Customers** | `https://huzaifasyed469432-coder.github.io/kinetic/` | your normal shop — no panel, no login button, nothing extra |
| **You (owner)** | `https://huzaifasyed469432-coder.github.io/kinetic/#admin` | a PIN screen, then the control panel |

The PIN screen never shows the code — not even a hint.
**Default PIN: `1234`** — change it any time in the panel (*Publish & links → Your PIN*).

---

## 2. Installing on your site (2 files, 2 minutes)

The files are already prepared for you — just upload them to your GitHub repository
`huzaifasyed469432-coder/kinetic` on the `main` branch:

1. **`assets/kinetic-admin.js`** → new file. On GitHub: *Add file → Upload files*, drop it in,
   commit. (If it asks, put it inside the `assets` folder.)
2. **`index.html`** → replace the existing one with the copy in this folder.
2b. **The product page files** (also already uploaded if you used the latest package):
   `assets/kinetic-product.js` and `assets/kinetic-product.css` — both new, drop them into
   `assets/`. They power the full details page for every product (`#product/0`, `#product/1`, …),
   which opens from the gold `↗` on a product card or from **View full details** in the
   quick-view window. `assets/kinetic-app.js` and `assets/kinetic-checkout.js` in this folder
   are the matching versions — replace yours with them at the same time.
   The only difference from your current file is **one line**:
   ```html
   <script src="assets/kinetic-admin.js"></script>
   ```
   placed just before `<script src="assets/kinetic-content.js"></script>`.

2c. **The admin dashboard files** (new): `assets/kinetic-admin-dash.css` and
   `assets/kinetic-admin-dash.js` — drop both into `assets/`. This is the full management
   console that opens on your `#admin` link: dashboard with real sales, orders, products,
   inventory, customers, categories, coupons, page content and settings. `index.html` in
   this folder already links both files (one stylesheet line, one script line) — nothing
   else in your markup changed.
2d. **Content loader** — `assets/kinetic-content.js` in this folder carries the extra data
   the console produces (categories, coupons, settings, product draft/featured/stock/sizes).
   Replace yours with it so nothing the dashboard saves is lost when the content file loads.
2e. **The collection search & filter files** (new): `assets/kinetic-shop-filters.css` and
   `assets/kinetic-shop-filters.js` — drop both into `assets/`. This adds the search box,
   the filter sidebar (desktop) / filter drawer (phone), the active-filter chips, the
   matching-product count and the six sorting modes to the collection page, and makes any
   filtered view shareable through the link. `index.html` in this folder already links both
   files (one stylesheet line, one script line) — nothing else in your markup changed.

2f. **Mobile optimisation files** (new): `assets/kinetic-mobile.css` and
   `assets/kinetic-mobile.js`, plus the folder `assets/images/m/` (smaller 480px/900px
   versions of your photos). Drop all three in place — the CSS and JS next to the other
   assets, and the `m` folder inside `assets/images/`. This makes every page comfortable
   on phones (bigger tap targets, 16px inputs so iPhones don't zoom, a wishlist button in
   the header, a tidier filter toolbar, smaller images) without touching the desktop
   design. `index.html` in this folder already links both files. Full detail: `MOBILE.md`.

GitHub Pages rebuilds in about a minute. Open your admin link — you are in business.

> **Already done for you:** the `index.html` in this folder is your real site file with that
> one line added and nothing else changed.

---

## 3. Connecting publishing (one time)

To push your changes to the live site from the panel you need one GitHub key:

1. GitHub → your picture → **Settings → Developer settings → Personal access tokens →
   Fine-grained tokens → Generate new token**.
2. Repository access: **Only select repositories → kinetic**.
3. Permissions → Repository permissions → **Contents: Read and write**.
4. Generate, copy the token, then in your panel open **Publish & links**, paste it into
   *GitHub token* and press **Save token** (and **Test** to be sure).

It is stored only in your own browser on that device. Anyone else — including visitors —
never sees it. You only do this once per device.

**No token?** No problem: press **Download content.json** and upload that file to the root of
your repository on GitHub. Same result, one extra drag-and-drop.

---

## 4. Using the panel

### Products tab
- **Edit** — change name, category, badge/tag, price, old price, rating, review count,
  description, colours and photo.
- **Add product** — makes a new one. Fill the fields and press *Add product*.
- **Duplicate** — copies a product (handy for colour variants).
- **Delete** — removes a product (asks you to confirm first).
- **↑ ↓** — reorder how products appear in your shop.
- **Photo** — press *Upload image* and choose a picture from your phone or computer.
  Big photos are shrunk automatically so your site stays fast. You can also paste an image
  address instead.
- **Colourways** — each colour can have a name (shown to customers) and a swatch colour.

### Numbers tab
Every figure on the site: runners, members, average rating, reviews, energy return %,
field-test kilometres, athletes tested, lab years, drop height and more.

### Shop settings tab
Free-shipping threshold, shipping cost, promo code and discount %.

### Page text tab
Every heading, paragraph, button label and ticker line on the site — grouped by section
(Header, Hero, Tech, Lookbook, Stories, Club, Footer…). Type and it changes.

### Publish & links tab
- **Publish live** — writes your changes to the site (about 1 minute to appear).
- **Publish with images** — any photo you uploaded is committed to your repo as well.
- **Turn preview off / on** — while preview is on, *only your device* sees your edits;
  visitors still see the old version until you publish.
- **Test** — checks the GitHub connection.
- **Forget token** — removes the token from this device.
- **Download content.json** — the manual fallback.
- **Download full backup (.json)** / **Restore from backup** — keeps a safe copy of
  everything; use it to move your content to another computer.
- **Reset to original site content** — back to the day-one catalog.
- **Your PIN** — change the admin PIN.

### Good to know
- **Everything saves as you type.** Nothing is lost if you close the browser.
- **Publishing is a separate, deliberate click** — so you can never change the live shop by
  accident while experimenting.
- Press **Esc** to close the panel, **Ctrl + Shift + A** to reopen it.
- Preview mode means: your edits show on your device only. Customers keep seeing the live
  version until you press *Publish live*.

---

## 5. Quick checklist after installing

1. Open `#admin`, enter `1234`. You land on the new **Dashboard**. Go to
   **Settings → Security** and change the PIN (the old one stops working immediately).
2. Paste the GitHub token and press **Test**.
3. **Products → + Add product**: name, price, category, sizes, stock, a photo → **Save**.
   The product is live in the shop at once (Draft status keeps it hidden).
4. Place a small test order in the shop as a customer, then open **Orders** — the order,
   its customer, its items and its total are all there. Change its status; the customer's
   order page shows the new status.
5. **Publish live** (top bar of the console), wait a minute, refresh the customer link.
6. On a phone, open the customer link: no panel, no PIN, nothing extra.
7. Open the site on a phone and tap through: the header icons, the menu, a product page
   (sticky *Buy now* bar appears as you scroll), the bag (± buttons), and the **♡ wishlist**
   button in the header. Everything should feel thumb-sized, with no sideways scrolling.
8. On the collection page, type in the search box (try a product name or a SKU), tick a few
   filters and pick a sort — the grid updates as you go. Copy the link in the address bar
   and open it in a new tab: the same filtered view comes back. On a phone the filters open
   from the **Filters** button as a drawer.

---

## 6. Roman Urdu — chhota khulasa

- **Customer link** wohi purana link hai, us par koi panel nahi aata.
- **Admin link**: aap ka link `#admin` ke saath — PIN `1234` (badal sakte hain).
- Panel se aap **products, price, tasveerein, headings, numbers, shipping** — sab kuch khud
  change kar sakte hain. Design bilkul waisa hi rahega.
- **Sab kuch khud-ba-khud save** hota hai; live site par bhejne ke liye *Publish live* dabaiye.
- **Naya Admin Dashboard** — `#admin` kholte hi PIN ke baad poora console milta hai:
  *Dashboard* (total sales, orders, customers, products, pending/completed, low-stock,
  ready chart, best sellers, naye orders — **sab asli orders se**, koi banaya hua number nahi),
  *Orders* (search, filter, status badalna, receipt print, CSV export/import),
  *Products* (add/edit/delete, tasveer upload, price, sale price, SKU, category, sizes,
  colours, stock, Live/Draft, Featured), *Inventory* (per-size stock, low-stock warning,
  sold out, foran update), *Customers* (order count, kharch, pehla order),
  *Categories*, *Coupons* (percent ya fixed, minimum spend, expiry, usage limit,
  on/off — code checkout par **asli** kaam karta hai), *Page content*
  (purana text editor, PIN dobara nahi maangta) aur *Settings* (PIN badalna, low-stock
  limit, backup/export).
- Customer ke liye kuch nahi badla: na panel, na PIN, na koi extra cheez — site bilkul waisi hai.
- Ek haqeeqat jo console khud screen par likhta hai: order customer ke browser mein save hota
  hai, is liye aapke dashboard par wohi orders dikhte hain jo us device par hue. Sab customers
  ke orders ek jagah laane ke liye **Settings → Orders sync** mein apna endpoint URL daal
  dein — har naya order wahan bhi chala jayega.
- GitHub token ek dafa panel mein paste karna hai (Contents: Read and write) — iske baghair
  *Download content.json* wala tareeqa istemal karein.
- **Collection page par naya search + filter system**: search box se **naam, SKU, category
  ya keyword** likh kar foran products filter ho jate hain. Sidebar (computer) / drawer
  (mobile) mein category, price range, size (US + EU), colour, availability, rating, sale
  aur featured — sab filters. Active filters chips mein dikhte hain, har chip alag se
  hataiye ya *Clear all* dabaiye. Product count upar live update hota hai (`1 / 8 Products`)
  aur sorting 6 tarah ki: featured, newest, price low→high, price high→low, best rated,
  most popular. **Link share karne par wohi filtered view khulti hai** — page refresh karne
  par bhi filters barqarar rehte hain (`?category=running&color=black&size=42` jaisa link).
- **Mobile par poori site optimize ho gayi hai** — har button/icon ka touch area 44px,
  form inputs 16px (iPhone zoom nahi karega), header mein **♡ wishlist** button aa gaya
  hai, collection ka filter toolbar mobile par tarteeb se lagta hai, aur tasveerein mobile
  ke liye chhoti (480px/900px) ban gayi hain — is liye site tez khulti hai. Desktop design
  bilkul waisa hi hai.
- Install ke liye files: `assets/kinetic-admin.js`, `assets/kinetic-product.js` (nayi),
  `assets/kinetic-product.css` (nayi), `assets/kinetic-admin-dash.js` (nayi),
  `assets/kinetic-admin-dash.css` (nayi), `assets/kinetic-shop-filters.js` (nayi),
  `assets/kinetic-shop-filters.css` (nayi), `assets/kinetic-mobile.css` (nayi),
  `assets/kinetic-mobile.js` (nayi), `assets/images/m/` (mobile tasveerein),
  `assets/kinetic-content.js`,
  `assets/kinetic-app.js`, `assets/kinetic-checkout.js` aur `index.html`.
- **Har product ka apna detail page** ban gaya hai (`#product/0` jaise link). Customer product
  card par sunehri `↗` dabaye ya quick-view window mein *View full details* — poora page khulta
  hai: badi gallery + thumbnails + zoom, price aur sale price, size (US 7–12, EU ke sath),
  colour swatches, stock, quantity, *Add to bag*, *Buy now*, wishlist, SKU, shipping aur returns,
  specifications, reviews (review likhne ka form bhi), related products aur recently viewed.
  Jo size/colour/quantity aap chunte hain, bilkul wohi bag mein jata hai — sab asli hai.
